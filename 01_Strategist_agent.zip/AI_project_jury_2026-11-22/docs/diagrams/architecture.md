# Архитектура: два рабочих контура

Оба контура работают без ключей и внешних API. Необязательный API-раннер в этой версии не реализован и на схеме не заявляется.

```mermaid
flowchart TB
    U["Руководитель продукта<br/>/start /resume /options /strategy /update"]

    subgraph C1["Контур 1. IDE-оркестратор и субагенты (без ключей)"]
        R["Правила: CLAUDE.md, .cursor/rules<br/>собираются из prompts_src/"]
        A["Субагенты: reader, red-team, synth-resp"]
        T["Учёт токенов: ide_exact (Claude Code),<br/>ide_estimated (Cursor)"]
    end

    subgraph C2["Контур 2. Локальные скрипты CLI/MCP (0 токенов)"]
        CLI["tools/cli.py и mcp_server.py<br/>init, ingest, register-claim,<br/>register-option, validate-step, resume"]
        ST["state.json + validation_hash<br/>(обнаружение ручных правок)"]
        DB["evidence_db.json, options.json,<br/>sources.json, cost_ledger.json"]
    end

    KB[("knowledge_base/<br/>frameworks, templates")]
    OUT["deliverables/ 01..05"]

    U --> C1
    C1 -- обязательный вызов --> CLI
    CLI --> ST
    CLI --> DB
    CLI --> OUT
    KB --> OUT
    KB --> C1
```

Данные разделены по слоям: постоянные правила (`prompts_src/`), методика (`knowledge_base/`), материалы проекта (`raw_materials/`), состояние задачи (`state.json`).
