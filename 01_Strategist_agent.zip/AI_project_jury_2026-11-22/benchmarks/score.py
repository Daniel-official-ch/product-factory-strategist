#!/usr/bin/env python3
"""Бенчмарк C-042 п.3: одна механика для ответа обычного чата и ответа агента.

python3 benchmarks/score.py <файл.md> --sources <папка со снимками> [--evidence <evidence_db.json>]

Для каждой строки с числом: все её числа найдены в тексте источников (number_in_sources) и строка ссылается
на источник (сноска [^SRC-..], CLM-..., слово «источник» или SRC). Скрипт не зависит от кода продукта: это
внешняя линейка, а не самопроверка агента.

Правила разбора (одинаковы для обоих ответов):
- числа нормализуются: пробелы, неразрывные и узкие пробелы в разрядах убираются, запятая в дроби = точка, знак % отбрасывается;
- не считаются числами: ID вида SRC-03, CLM-012, OPT-01, DEC-02, GAP-001, RQ-001, CALC-01; номер пункта нумерованного
  списка и номер раздела в начале заголовка; даты в заголовках;
- не разбираются: HTML-комментарии, блоки кода, строки-определения сносок «[^SRC-01]: ...» (это описание источника);
- --evidence: числа из результатов расчётов (calculations.json рядом с evidence_db.json) по CALCULATION-утверждениям,
  на которые ссылается строка, считаются найденными; это отдельные поля *_with_calc, основные поля не меняются.
"""
import argparse
import json
import re
import sys
from decimal import Decimal
from pathlib import Path

ID = re.compile(r"\b[A-Z]{2,5}-\d+\b")
FOOTNOTE = re.compile(r"\[\^[^\]]*\]")
NUMBER = re.compile(r"(?<![\w.,])\d{1,3}(?:[   ]\d{3})+(?:[.,]\d+)?(?![\w])|(?<![\w.,])\d+(?:[.,]\d+)?")
DATE = re.compile(r"\b\d{1,2}\.\d{1,2}\.\d{2,4}\b|\b\d{4}-\d{2}-\d{2}\b")
LIST_NUM = re.compile(r"^\s*\d+[.)]\s+")
HEAD_NUM = re.compile(r"^(#+\s*)\d+(?:\.\d+)*\.?\s+")
REF = re.compile(r"\[\^SRC-[^\]]+\]|\bCLM-\d+\b|источник|\bSRC\b|\bSRC-\d+", re.I)
SOURCE_EXT = {".txt", ".md", ".csv"}
MAX_LIST = 50


def norm(raw):
    """«1 000» = «1000», «36,2» = «36.2» = «36.20», «007» = «7»."""
    return format(Decimal(re.sub(r"[ \u00a0\u202f]", "", raw).replace(",", ".")).normalize(), "f")


def numbers(line):
    """Числа строки после удаления ID, сносок, номеров пунктов и разделов, дат в заголовках."""
    s = FOOTNOTE.sub(" ", line)
    s = ID.sub(" ", s)
    s = LIST_NUM.sub(" ", s)
    if s.lstrip().startswith("#"):
        s = DATE.sub(" ", HEAD_NUM.sub(r"\1", s.lstrip()))
    return [norm(m.group(0)) for m in NUMBER.finditer(s)]


def lines_of(text):
    text = re.sub(r"<!--.*?-->", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    fence = False
    for n, line in enumerate(text.splitlines(), 1):
        if line.strip().startswith(("```", "~~~")):
            fence = not fence
            continue
        if fence or not line.strip() or line.lstrip().startswith("[^"):
            continue
        yield n, line


def source_numbers(folder):
    found = set()
    for p in sorted(Path(folder).rglob("*")):
        if p.is_file() and p.suffix.lower() in SOURCE_EXT:
            text = ID.sub(" ", p.read_text(encoding="utf-8", errors="replace"))
            found |= {norm(m.group(0)) for m in NUMBER.finditer(text)}
            # в CSV запятая — разделитель ячеек: «299,1000» это два числа, а не дробь
            found |= {norm(m.group(0)) for m in re.finditer(r"(?<![\w.])\d+(?:\.\d+)?", text)}
    return found


def calc_numbers(evidence):
    """CLM-ID -> числа результатов расчётов (с округлением до 0–3 знаков)."""
    path = Path(evidence)
    claims = json.loads(path.read_text(encoding="utf-8")).get("claims", [])
    calcs_path = path.with_name("calculations.json")
    calcs = {c["id"]: c for c in json.loads(calcs_path.read_text(encoding="utf-8")).get("calculations", [])} \
        if calcs_path.is_file() else {}
    out = {}
    for c in claims:
        calc = calcs.get(c.get("calc_id"))
        if c.get("status") == "active" and calc and isinstance(calc.get("result"), (int, float)):
            out[c["id"]] = {norm(f"{round(calc['result'], d):.{d}f}") for d in range(4)}
    return out


def score(md, sources, evidence=None):
    known = source_numbers(sources)
    by_claim = calc_numbers(evidence) if evidence else None
    total = in_src = ref = both = in_calc = both_calc = 0
    unconfirmed = []
    for n, line in lines_of(Path(md).read_text(encoding="utf-8")):
        nums = numbers(line)
        if not nums:
            continue
        total += 1
        missing = [x for x in dict.fromkeys(nums) if x not in known]
        has_ref = bool(REF.search(line))
        in_src += not missing
        ref += has_ref
        both += has_ref and not missing
        if by_claim is not None:
            extra = set().union(*(by_claim.get(c, set()) for c in re.findall(r"\bCLM-\d+\b", line)))
            left = [x for x in missing if x not in extra]
            in_calc += not left
            both_calc += has_ref and not left
        if (missing or not has_ref) and len(unconfirmed) < MAX_LIST:
            unconfirmed.append({"line": n, "text": line.strip()[:200], "numbers_not_in_sources": missing,
                                "source_ref": has_ref})
    out = {"file": str(md), "numeric_lines": total, "with_number_in_sources": in_src, "with_source_ref": ref,
           "both": both, "share_both": round(both / total, 4) if total else 0.0,
           "unconfirmed_total": total - both, "unconfirmed": unconfirmed}
    if by_claim is not None:
        out.update(with_number_in_sources_with_calc=in_calc, both_with_calc=both_calc,
                   share_both_with_calc=round(both_calc / total, 4) if total else 0.0)
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("md")
    p.add_argument("--sources", required=True)
    p.add_argument("--evidence")
    a = p.parse_args(argv)
    for path, what in ((a.md, "файл ответа"), (a.sources, "папка источников"), (a.evidence, "evidence_db.json")):
        if path and not Path(path).exists():
            print(json.dumps({"error": f"Не найден {what}: {path}", "hint": "python3 benchmarks/score.py <файл.md> "
                              "--sources <папка> [--evidence <evidence_db.json>]"}, ensure_ascii=False), file=sys.stderr)
            return 1
    print(json.dumps(score(a.md, a.sources, a.evidence), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
