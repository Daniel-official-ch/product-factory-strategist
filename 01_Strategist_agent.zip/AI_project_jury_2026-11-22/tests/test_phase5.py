"""Приёмка волны 5 (T-511): контракты C-040, C-043, C-044, C-045, C-046, C-047.

Тесты пишутся по контракту, не по коду. Всё идёт во временных папках, репозиторий разработки не меняется.
Пока бэкенд не закончил T-501…T-505, часть тестов красная из-за отсутствия команд (package.py, export-pdf,
redact-source, --redact-terms): это ожидаемо.

Имена инфраструктуры команды собраны по частям: в чистой копии их быть не должно (C-040 п.6),
а эта проверка читает и сам файл с тестами.
"""
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import zipfile
import zlib
from pathlib import Path

import pytest

from conftest import FIX, MARKET_QUOTE, REPO, TEAM_INFRA, Cli, needs_team_infra

PACKAGE = REPO / "tools" / "package.py"
T, D, S = "te" + "am", "do" + "cs", "claude-" + "setup"
FORBIDDEN = ["tools/" + T, D + "/" + T, S, "README_" + T.upper(), "ga" + "te.py",
             "CLAUDE_CODE_EXPERIMENTAL_AGENT_" + T.upper()]
TEAM_AGENTS = ["tripolsky-pm", "debussy-backend", "makelele-qa", "vandamme-ux", "monet-deliverables"]
WHITELIST_TOP = {"README.md", "CLAUDE.md", "AGENTS.md", "requirements.txt", "prompts_src", ".claude", ".cursor",
                 "config", "knowledge_base", "skills", "tools", "tests", "demo", "docs", "benchmarks"}
BEGIN = "<!-- BEGIN product-rules (generated) -->"
END = "<!-- END product-rules -->"
SK_BAD = "sk-" + "A1b2C3d4E5" * 3  # 30 символов после префикса
SK_OK19 = "sk-" + "Z" * 19  # на границе: 19 символов ключом не считается


def _all(x):
    return json.dumps(x, ensure_ascii=False)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def tree_hash(root):
    """Побайтовый слепок дерева без кэшей: «репозиторий не изменился»."""
    h = hashlib.sha256()
    for p in sorted(root.rglob("*")):
        if "__pycache__" in p.parts or ".pytest_cache" in p.parts or ".git" in p.parts:
            continue
        if p.is_file() and not p.is_symlink():
            h.update(str(p.relative_to(root)).encode() + b"\0" + p.read_bytes())
    return h.hexdigest()


def files_of(root):
    return {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}


def tree(c: Cli):
    return {str(p.relative_to(c.ws)): p.read_bytes() for p in sorted(c.ws.rglob("*")) if p.is_file()}


def run_py(args, cwd, env_extra=None):
    env = {k: v for k, v in os.environ.items() if k != "STRATEGIST_WORKSPACE"}
    env.update(env_extra or {})
    return subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True, cwd=cwd, env=env,
                          timeout=170)


def parse(cp):
    lines = [l for l in cp.stdout.strip().splitlines() if l.strip()]
    return json.loads(lines[-1]) if lines else None


def parse_err(cp):
    assert "Traceback" not in cp.stderr, cp.stderr
    lines = [l for l in cp.stderr.strip().splitlines() if l.strip()]
    return json.loads(lines[-1])


# =====================================================================
# C-040. tools/package.py: чистая копия для жюри
# =====================================================================

pkg_only = pytest.mark.skipif(not TEAM_INFRA, reason="сборка копии проверяется в репозитории разработки")


def copy_repo(dst):
    shutil.copytree(REPO, dst, ignore=shutil.ignore_patterns(".git", "workspace", "__pycache__", ".pytest_cache"))
    return dst


def package(repo, out, *extra, cwd=None):
    return run_py([repo / "tools" / "package.py", "--out", out, *extra], cwd=cwd or repo)


@pytest.fixture(scope="module")
def built(tmp_path_factory):
    base = tmp_path_factory.mktemp("pkg")
    before = tree_hash(REPO)
    out = base / "copy"
    cp = package(REPO, out, "--zip", cwd=base)  # запуск не из корня репозитория
    return {"cp": cp, "out": out, "base": base, "before": before, "after": tree_hash(REPO)}


@pkg_only
def test_c040_build_ok_and_json_shape(built):
    cp = built["cp"]
    assert cp.returncode == 0, (cp.stdout, cp.stderr)
    o = parse(cp)
    assert {"ok", "out", "files", "excluded", "zip"} <= set(o), o
    assert o["ok"] is True and Path(o["out"]).resolve() == built["out"].resolve()
    n = len(o["files"]) if isinstance(o["files"], list) else o["files"]
    assert n == len(files_of(built["out"])) and n > 50


@pkg_only
def test_c040_source_repo_not_modified(built):
    assert built["cp"].returncode == 0, built["cp"].stderr
    assert built["before"] == built["after"], "package.py изменил репозиторий разработки"


@pkg_only
def test_c040_whitelist_only(built):
    out = built["out"]
    assert built["cp"].returncode == 0, built["cp"].stderr
    top = {p.name for p in out.iterdir()}
    assert top <= WHITELIST_TOP, f"лишнее в корне копии: {top - WHITELIST_TOP}"
    for need in ("README.md", "CLAUDE.md", "requirements.txt", "tools", "knowledge_base", "skills", "demo", "tests",
                 "prompts_src", "config"):
        assert need in top, f"нет {need}"
    assert {p.name for p in (out / D).iterdir()} <= {"diagrams", "report"}
    for bad in ("plan.md", "status", T, "qa_log.md", "ux_findings.md", "coverage.md"):
        assert not (out / D / bad).exists(), bad
    assert not (out / S).exists() and not (out / ("README_" + T.upper() + ".md")).exists()
    assert (out / "tools" / "cli.py").is_file() and (out / "tools" / "package.py").is_file()
    assert (out / "demo" / "antispam" / "run").is_dir() and (out / "demo" / "family_safety" / "run").is_dir()


@pkg_only
def test_c040_no_team_infrastructure(built):
    out = built["out"]
    assert built["cp"].returncode == 0, built["cp"].stderr
    assert not (out / "tools" / T).exists()
    for a in TEAM_AGENTS:
        assert not (out / ".claude" / "agents" / f"{a}.md").exists(), a
    assert not (out / ".claude" / "commands" / f"{T}.md").exists()
    for a in ("reader", "red-team", "synth-resp"):
        assert (out / ".claude" / "agents" / f"{a}.md").is_file(), a
    for c in ("start", "resume", "options", "strategy", "update"):
        assert (out / ".claude" / "commands" / f"{c}.md").is_file(), c


@pkg_only
def test_c040_no_forbidden_strings_in_any_text_file(built):
    out = built["out"]
    assert built["cp"].returncode == 0, built["cp"].stderr
    hits = []
    for p in out.rglob("*"):
        if not p.is_file():
            continue
        try:
            t = p.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for f in FORBIDDEN:
            if f in t:
                hits.append((str(p.relative_to(out)), f))
        if re.search(r"(?<![\w./-])/" + T + r"\b", t):
            hits.append((str(p.relative_to(out)), "/" + T))
    assert not hits, hits[:10]


@pkg_only
def test_c040_settings_json_has_no_team_env_and_hooks(built):
    assert built["cp"].returncode == 0, built["cp"].stderr
    cfg = json.loads((built["out"] / ".claude" / "settings.json").read_text(encoding="utf-8"))
    assert "CLAUDE_CODE_EXPERIMENTAL_AGENT_" + T.upper() not in _all(cfg.get("env", {}))
    hooks = cfg.get("hooks", {})
    assert "TaskCompleted" not in hooks and "TeammateIdle" not in hooks
    stop = [h["command"] for g in hooks.get("Stop", []) for h in g.get("hooks", [])]
    assert any("tools/cli.py" in c and "parse-transcript" in c for c in stop), "хук продукта Stop потерян"
    for ev, groups in hooks.items():  # любые оставшиеся хуки — только продукт
        for g in groups:
            for h in g.get("hooks", []):
                assert "tools/cli.py" in h.get("command", ""), (ev, h)


@pkg_only
def test_c040_claude_md_is_only_generated_block_and_build_rules_check_passes(built, tmp_path):
    out = built["out"]
    assert built["cp"].returncode == 0, built["cp"].stderr
    text = (out / "CLAUDE.md").read_text(encoding="utf-8").strip()
    assert text.startswith(BEGIN) and text.endswith(END), "в CLAUDE.md копии есть что-то кроме блока правил продукта"
    assert text.count(BEGIN) == 1 and text.count(END) == 1
    assert "Первый запуск" not in text and "AI project" not in text
    c = Cli(tmp_path / "ws", cli=out / "tools" / "cli.py", cwd=out)
    c.run("build-rules", "--check", project=False).ok()


@pkg_only
def test_c040_never_copied_junk(built):
    out = built["out"]
    assert built["cp"].returncode == 0, built["cp"].stderr
    assert not (out / "workspace").exists()
    for p in out.rglob("*"):
        n = p.name
        assert n not in ("__pycache__", ".pytest_cache", ".DS_Store", ".lock", ".ingest_update_backup"), p
        assert not n.endswith(".pyc"), p
        if n.startswith(".env"):
            assert str(p.relative_to(out)) == "config/.env.example", p
    assert (out / "config" / ".env.example").is_file()
    assert not list((out / "demo").rglob("raw_materials/*.html"))


@pkg_only
def test_c040_zip_has_same_structure(built):
    out = built["out"]
    assert built["cp"].returncode == 0, built["cp"].stderr
    z = Path(str(out) + ".zip")
    assert z.is_file(), "нет <out>.zip рядом с копией"
    assert Path(parse(built["cp"])["zip"]).resolve() == z.resolve()
    with zipfile.ZipFile(z) as zf:
        names = {n for n in zf.namelist() if not n.endswith("/")}
    pref = out.name + "/"
    if all(n.startswith(pref) for n in names):
        names = {n[len(pref):] for n in names}
    assert names == files_of(out)


@pkg_only
def test_c040_nonempty_out_refused_and_untouched(tmp_path):
    out = tmp_path / "busy"
    out.mkdir()
    (out / "keep.txt").write_text("мои данные", encoding="utf-8")
    cp = package(REPO, out)
    assert cp.returncode == 1, (cp.stdout, cp.stderr)
    e = parse_err(cp)
    assert e.get("error") and e.get("hint")
    assert files_of(out) == {"keep.txt"} and (out / "keep.txt").read_text(encoding="utf-8") == "мои данные"
    assert not Path(str(out) + ".zip").exists()


@pkg_only
def test_c040_existing_empty_out_is_fine(tmp_path):
    out = tmp_path / "emptydir"
    out.mkdir()
    cp = package(REPO, out)
    assert cp.returncode == 0, (cp.stdout, cp.stderr)


@pkg_only
def test_c040_planted_secret_fails_and_removes_partial_copy(tmp_path):
    repo = copy_repo(tmp_path / "repo")
    (repo / "knowledge_base" / "zz_note.md").write_text(f"Ключ для проверки: {SK_BAD}\n", encoding="utf-8")
    out = tmp_path / "out"
    cp = package(repo, out, "--zip")
    assert cp.returncode == 1, (cp.stdout, cp.stderr)
    e = parse_err(cp)
    assert isinstance(e.get("violations"), list) and e["violations"], e
    assert "zz_note.md" in _all(e["violations"])
    assert SK_BAD not in cp.stdout + cp.stderr, "ключ напечатан целиком"
    assert not out.exists(), "недособранная копия не удалена"
    assert not Path(str(out) + ".zip").exists()


@pkg_only
@pytest.mark.parametrize("secret", ["api_" + "key=abc123def456", "tok" + "en=ghp_realvalue123", "API_" + "KEY=abc123def456"])
def test_c040_assignment_style_secrets_fail(tmp_path, secret):
    repo = copy_repo(tmp_path / "repo")
    (repo / "skills" / "zz_note.md").write_text(f"Настройка:\n{secret}\n", encoding="utf-8")
    cp = package(repo, tmp_path / "out")
    assert cp.returncode == 1, (cp.stdout, cp.stderr)
    assert "zz_note.md" in _all(parse_err(cp)["violations"])
    assert not (tmp_path / "out").exists()


@pkg_only
def test_c040_secret_boundary_19_chars_passes(tmp_path):
    repo = copy_repo(tmp_path / "repo")
    (repo / "skills" / "zz_ok.md").write_text(f"Короткий префикс {SK_OK19} ключом не считается.\n", encoding="utf-8")
    cp = package(repo, tmp_path / "out")
    assert cp.returncode == 0, (cp.stdout, cp.stderr)


@pkg_only
@pytest.mark.parametrize("text", ["Пример: api_" + "key=\nСледующая строка.\n", "Пример: tok" + "en= \nСледующая строка.\n",
                                  "api_" + "key=\"\"\n"])
def test_c040_empty_assignment_is_not_a_key(tmp_path, text):
    """C-040 п.6: ключом считается присваивание с непустым значением; пустое (и значение на следующей строке) не нарушение."""
    repo = copy_repo(tmp_path / "repo")
    (repo / "skills" / "zz_ok.md").write_text(text, encoding="utf-8")
    cp = package(repo, tmp_path / "out")
    assert cp.returncode == 0, (cp.stdout, cp.stderr)


@pkg_only
def test_c040_env_files_with_keys_are_excluded_not_a_violation(tmp_path):
    repo = copy_repo(tmp_path / "repo")
    (repo / ".env").write_text(f"OPENAI_API_KEY={SK_BAD}\n", encoding="utf-8")
    (repo / ".env.local").write_text("tok" + "en=realtoken123\n", encoding="utf-8")
    (repo / "workspace" / "p").mkdir(parents=True)
    (repo / "workspace" / "p" / "state.json").write_text(SK_BAD, encoding="utf-8")
    (repo / "tools" / "zz.pyc").write_bytes(b"\0\0")
    (repo / "tools" / ".DS_Store").write_bytes(b"x")
    (repo / "demo" / "antispam" / "run" / "current_project" / ".lock").write_text("1", encoding="utf-8")
    bk = repo / "demo" / "antispam" / "run" / "current_project" / ".ingest_update_backup"
    bk.mkdir()
    (bk / "x.json").write_text("{}", encoding="utf-8")
    raw = repo / "demo" / "family_safety" / "run" / "current_project" / "raw_materials"
    (raw / "SRC-99.html").write_text("<html>x</html>", encoding="utf-8")
    out = tmp_path / "out"
    cp = package(repo, out)
    assert cp.returncode == 0, (cp.stdout, cp.stderr)
    got = files_of(out)
    assert not [f for f in got if re.search(r"(^|/)(\.env($|\.)|workspace/|\.lock$|\.ingest_update_backup/|\.DS_Store$)|\.pyc$", f)
                and f != "config/.env.example"], got
    assert "demo/family_safety/run/current_project/raw_materials/SRC-99.html" not in got
    assert SK_BAD not in "".join(p.read_text(encoding="utf-8", errors="ignore") for p in out.rglob("*") if p.is_file())


@pkg_only
@pytest.mark.parametrize("planted", ["tools/" + T, D + "/" + T, S, "README_" + T.upper(),
                                     "ga" + "te.py", "CLAUDE_CODE_EXPERIMENTAL_AGENT_" + T.upper()])
def test_c040_forbidden_string_in_copy_is_violation(tmp_path, planted):
    repo = copy_repo(tmp_path / "repo")
    (repo / "skills" / "zz_note.md").write_text(f"См. также {planted} для деталей.\n", encoding="utf-8")
    cp = package(repo, tmp_path / "out")
    assert cp.returncode == 1, (cp.stdout, cp.stderr)
    assert "zz_note.md" in _all(parse_err(cp)["violations"])
    assert not (tmp_path / "out").exists()


@pkg_only
def test_c040_slash_team_command_is_violation(tmp_path):
    repo = copy_repo(tmp_path / "repo")
    (repo / "skills" / "zz_note.md").write_text(f"Запустите `/{T} задача`.\n", encoding="utf-8")
    cp = package(repo, tmp_path / "out")
    assert cp.returncode == 1, (cp.stdout, cp.stderr)
    assert not (tmp_path / "out").exists()


@pkg_only
@pytest.mark.parametrize("pii", ["почта test.person" + "@" + "example.org здесь", "звоните " + "+7 912 " + "345-67-89"])
def test_c040_pii_outside_fixtures_is_violation_inside_is_fine(tmp_path, pii):
    repo = copy_repo(tmp_path / "repo")
    (repo / "tests" / "fixtures" / "zz_pii.txt").write_text(pii + "\n", encoding="utf-8")
    cp = package(repo, tmp_path / "ok")
    assert cp.returncode == 0, ("в tests/fixtures ПДн разрешены", cp.stdout, cp.stderr)
    (repo / "knowledge_base" / "zz_pii.md").write_text(pii + "\n", encoding="utf-8")
    cp = package(repo, tmp_path / "bad")
    assert cp.returncode == 1, (cp.stdout, cp.stderr)
    assert "zz_pii.md" in _all(parse_err(cp)["violations"])
    assert not (tmp_path / "bad").exists()


@pkg_only
def test_c040_symlink_in_repo_does_not_leak_outside_file(tmp_path):
    """Атака: симлинк внутри белого списка на файл вне репозитория не должен попасть в копию."""
    secret = tmp_path / "outside.txt"
    marker = "ВНЕШНИЙ_" + "МАРКЕР_" + "ЗЗЗ"
    secret.write_text(marker, encoding="utf-8")
    repo = copy_repo(tmp_path / "repo")
    (repo / "skills" / "zz_link.md").symlink_to(secret)
    out = tmp_path / "out"
    cp = package(repo, out)
    if cp.returncode == 0:
        blob = "".join(p.read_text(encoding="utf-8", errors="ignore") for p in out.rglob("*")
                       if p.is_file() and not p.is_symlink())
        assert marker not in blob
        assert not any(p.is_symlink() for p in out.rglob("*")), "симлинк попал в копию"
    else:
        assert cp.returncode == 1 and not out.exists()


@pytest.mark.skipif(TEAM_INFRA, reason="проверка «мы внутри чистой копии»")
def test_c040_in_clean_copy_no_team_infra_present():
    assert not (REPO / "tools" / T).exists() and not (REPO / D / "plan.md").exists()


# =====================================================================
# C-043. export-pdf
# =====================================================================

BRIEF_MD = """# Бриф задачи

Рынок вырос на 14 процентов [FACT] [DEMO-DATA] [^SRC-01].

## Выводы

- Первый пункт списка с кириллицей
- Второй пункт, **жирный текст** и *курсив*
  - вложенный пункт

1. Нумерованный раз
2. Нумерованный два

| Показатель | Значение |
| --- | --- |
| Конверсия | 12 процентов |

Гипотеза о росте [HYPOTHESIS] и прогноз [FORECAST], код `a / b`.

```
строка один
    строка два с отступом
строка три
```

[^SRC-01]: Обзор рынка
"""


def png_bytes():
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    raw = b"\x00\xff\x00\x00"
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def pdf_text(path):
    from pypdf import PdfReader
    return "\n".join((p.extract_text() or "") for p in PdfReader(str(path)).pages)


def squash(s):
    return re.sub(r"\s+", "", s)


@pytest.fixture
def pdfproj(proj_src):
    d = proj_src.pdir / "deliverables"
    d.mkdir(exist_ok=True)
    (d / "01_problem_brief.md").write_text(BRIEF_MD, encoding="utf-8")
    return proj_src


def test_c043_export_makes_pdf_with_cyrillic_and_labels(pdfproj):
    out = pdfproj.run("export-pdf").ok()
    assert out["ok"] is True and isinstance(out["files"], list) and out["files"] and isinstance(out["warnings"], list)
    pdf = pdfproj.pdir / "deliverables" / "pdf" / "01_problem_brief.pdf"
    assert pdf.is_file() and pdf.read_bytes().startswith(b"%PDF")
    text = squash(pdf_text(pdf))
    for needle in ("Бриф задачи", "Рынок вырос на 14 процентов", "[FACT]", "[DEMO-DATA]", "[HYPOTHESIS]", "[FORECAST]",
                   "SRC-01", "Нумерованный", "Конверсия", "12 процентов", "вложенный пункт", "жирный текст"):
        assert squash(needle) in text, f"в PDF нет: {needle}"
    assert "**" not in text and "```" not in text, "разметка Markdown просочилась в PDF"


def test_c043_code_block_keeps_all_lines(pdfproj):
    pdfproj.run("export-pdf").ok()
    raw = pdf_text(pdfproj.pdir / "deliverables" / "pdf" / "01_problem_brief.pdf")
    lines = [l.strip() for l in raw.splitlines()]
    i = lines.index("строка один")
    assert "строка два с отступом" in lines[i + 1] and lines[i + 2] == "строка три", lines[i:i + 4]


def test_c043_registries_and_hash_unchanged_and_verify_run_same(pdfproj):
    before_files = {n: (pdfproj.pdir / n).read_bytes() for n in
                    ("state.json", "evidence_db.json", "sources.json", "options.json", "calculations.json",
                     "decisions.json", "cost_ledger.json")}
    v1 = pdfproj.run("verify-run")
    pdfproj.run("export-pdf").ok()
    for n, b in before_files.items():
        assert (pdfproj.pdir / n).read_bytes() == b, f"{n} изменён экспортом"
    v2 = pdfproj.run("verify-run")
    assert (v1.code, v1.stdout) == (v2.code, v2.stdout)
    pdfproj.run("export-pdf").ok()  # повтор не ломает проект
    assert pdfproj.run("verify-run").stdout == v1.stdout


def test_c043_missing_image_is_warning_not_error(pdfproj):
    d = pdfproj.pdir / "deliverables"
    (d / "02_research_and_gaps.md").write_text("# Заголовок\n\nТекст до.\n\n![Экран онбординга](screens/nope.png)\n\n"
                                               "Текст после картинки.\n", encoding="utf-8")
    out = pdfproj.run("export-pdf").ok()
    assert out["ok"] is True
    assert any("nope.png" in w or "Экран онбординга" in w for w in out["warnings"]), out["warnings"]
    text = squash(pdf_text(d / "pdf" / "02_research_and_gaps.pdf"))
    assert squash("Экран онбординга") in text and squash("будет добавлен") in text
    assert squash("Текст после картинки") in text


def test_c043_existing_png_is_embedded_without_warning(pdfproj):
    d = pdfproj.pdir / "deliverables"
    (d / "pic.png").write_bytes(png_bytes())
    (d / "03_options_and_objections.md").write_text("# Картинка\n\n![Красный пиксель](pic.png)\n", encoding="utf-8")
    out = pdfproj.run("export-pdf").ok()
    assert not [w for w in out["warnings"] if "pic.png" in w], out["warnings"]
    from pypdf import PdfReader
    r = PdfReader(str(d / "pdf" / "03_options_and_objections.pdf"))
    assert sum(len(p.images) for p in r.pages) == 1


def test_c043_empty_deliverables_exit_1(proj):
    (proj.pdir / "deliverables").mkdir(exist_ok=True)
    proj.run("export-pdf").fail(1)


def test_c043_md_and_out_mode(proj, tmp_path):
    src = tmp_path / "doc.md"
    src.write_text("# Описание работы\n\nТекст про кириллицу [FACT] [DEMO-DATA].\n", encoding="utf-8")
    dst = tmp_path / "res" / "doc.pdf"
    before = tree(proj)
    out = proj.run("export-pdf", "--md", src, "--out", dst).ok()
    assert out["ok"] is True and dst.is_file()
    assert "[FACT]" in pdf_text(dst) and squash("Описание работы") in squash(pdf_text(dst))
    assert tree(proj) == before, "экспорт произвольного md трогает проект"


def test_c043_md_missing_file_clean_error(proj, tmp_path):
    proj.run("export-pdf", "--md", tmp_path / "net.md", "--out", tmp_path / "x.pdf").fail(1)


def test_c043_export_demo_deliverables_to_copy_leaves_demo_untouched(tmp_path):
    src = REPO / "demo" / "antispam" / "run"
    dst = tmp_path / "run"
    shutil.copytree(src, dst)
    before = {k: v for k, v in {str(p.relative_to(dst)): p.read_bytes() for p in dst.rglob("*") if p.is_file()}.items()}
    c = Cli(dst, project="current_project")
    out = c.run("export-pdf").ok()
    assert len(out["files"]) >= 4
    for f in (dst / "current_project" / "deliverables" / "pdf").glob("*.pdf"):
        assert len(pdf_text(f)) > 100, f
    after = {str(p.relative_to(dst)): p.read_bytes() for p in dst.rglob("*") if p.is_file() and "pdf" not in p.parts}
    assert all(after[k] == v for k, v in before.items()), "экспорт изменил файлы проекта"
    assert c.run("verify-run").ok()["ok"] is True


# =====================================================================
# C-044. Решение человека на этапах 1 и 4
# =====================================================================

BRIEF = ["set-brief", "--question", "Q", "--goal", "G", "--recipient", "R", "--audience", "A",
         "--constraints", "C", "--data", "D"]


def test_c044_stage1_not_closed_without_brief_decision(proj):
    proj.run(*BRIEF).ok()
    e = proj.run("validate-step", "--stage", 1).fail(1)
    blob = _all(e)
    assert "бриф не подтверждён человеком" in blob.lower()
    assert "record-decision" in blob and "--kind brief" in blob
    assert proj.read("state.json")["stage_status"]["1"] != "done"


def test_c044_stage1_closes_after_brief_decision(proj):
    proj.run(*BRIEF).ok()
    proj.confirm_brief()
    assert proj.run("validate-step", "--stage", 1).ok() == {"stage": 1, "ok": True}


@pytest.mark.parametrize("kind", ["other", "strategy", "option"])
def test_c044_other_kinds_do_not_confirm_brief(proj_src, kind):
    proj_src.run(*BRIEF).ok()
    args = ["record-decision", "--id", "DEC-07", "--kind", kind, "--text", "не бриф"]
    if kind == "option":
        proj_src.three_options(claims=None)
        args += ["--option", "OPT-01", "--owner", "o", "--metric", "m", "--review-if", "r"]
    proj_src.run(*args).ok()
    e = proj_src.run("validate-step", "--stage", 1).fail(1)
    assert "бриф не подтверждён" in _all(e).lower()


def test_c044_brief_decision_before_brief_does_not_help_empty_brief(proj):
    proj.confirm_brief()
    proj.run("validate-step", "--stage", 1).fail(1)


def _stage4_ready(c: Cli):
    c.claim().ok()
    c.three_options(claims="CLM-001")


def test_c044_stage4_not_closed_without_option_decision(proj_src):
    _stage4_ready(proj_src)
    e = proj_src.run("validate-step", "--stage", 4).fail(1)
    blob = _all(e)
    assert "вариант не выбран человеком" in blob.lower()
    assert "record-decision" in blob and "--kind option" in blob and "--option" in blob


@pytest.mark.parametrize("kind", ["brief", "other", "strategy"])
def test_c044_stage4_wrong_kind_does_not_count(proj_src, kind):
    _stage4_ready(proj_src)
    proj_src.run("record-decision", "--id", "DEC-07", "--kind", kind, "--text", "не выбор", "--option", "OPT-01").ok()
    e = proj_src.run("validate-step", "--stage", 4).fail(1)
    assert "вариант не выбран" in _all(e).lower()


def test_c044_stage4_option_decision_for_missing_option_cannot_be_recorded(proj_src):
    _stage4_ready(proj_src)
    proj_src.run("record-decision", "--id", "DEC-07", "--kind", "option", "--option", "OPT-99", "--text", "x",
                 "--owner", "o", "--metric", "m", "--review-if", "r").fail(1)
    proj_src.run("validate-step", "--stage", 4).fail(1)


def test_c044_stage4_closes_after_choice(proj_src):
    _stage4_ready(proj_src)
    proj_src.choose_option("OPT-02")
    assert proj_src.run("validate-step", "--stage", 4).ok() == {"stage": 4, "ok": True}


def test_c044_stage4_structural_checks_still_apply_with_decision(proj_src):
    """Решение не заменяет остальные требования этапа: без keep_as_is этап не закрывается."""
    proj_src.claim().ok()
    proj_src.option("OPT-01", "close_direction", extra=("--claims", "CLM-001")).ok()
    proj_src.option("OPT-02", "custom", extra=("--claims", "CLM-001")).ok()
    proj_src.option("OPT-03", "custom", title="Другой", extra=("--claims", "CLM-001")).ok()
    proj_src.choose_option("OPT-01")
    e = proj_src.run("validate-step", "--stage", 4).fail(1)
    assert "keep_as_is" in _all(e)


@pytest.mark.parametrize("demo", ["antispam", "family_safety"])
def test_c044_demos_still_pass_verify_run(demo):
    out = Cli(REPO / "demo" / demo / "run", project="current_project").run("verify-run").ok()
    assert out["ok"] is True and out["summary"]["stage"] == 6


# =====================================================================
# C-045. Решения, заменённые новыми
# =====================================================================

def dec(c, did, kind, option=None, claims=None, full=None):
    args = ["record-decision", "--id", did, "--kind", kind, "--text", f"Решение {did}"]
    if option:
        args += ["--option", option]
    if claims:
        args += ["--claims", claims]
    if full if full is not None else kind == "option":
        args += ["--owner", "Владелец", "--metric", "Показатель", "--review-if", "Если упадёт"]
    return c.run(*args)


@pytest.fixture
def c45(ws):
    c = Cli(ws)
    c.init()
    c.ingest_market()
    c.claim(text="Рынок вырос").ok()
    c.claim(text="Платёж", quote="Средний платёж пользователя составляет 450 рублей").ok()
    c.option("OPT-01", "keep_as_is", extra=("--claims", "CLM-002")).ok()
    c.option("OPT-02", "close_direction", extra=("--claims", "CLM-002")).ok()
    c.option("OPT-03", "custom", extra=("--claims", "CLM-002")).ok()
    (c.pdir / "deliverables").mkdir(exist_ok=True)
    (c.pdir / "deliverables" / "05_decision_log.md").write_text("# Журнал решений\n\nDEC-01.\n", encoding="utf-8")
    return c


def handoff_review(c):
    c.run("resume").ok()
    text = (c.pdir / "HANDOFF_CONTEXT.md").read_text(encoding="utf-8")
    return text.split("## Требует пересмотра", 1)[1].split("\n## ", 1)[0]


def violations_text(r):
    return _all(r.fail(1))


def test_c045_superseded_stale_decision_gives_no_violation(c45):
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    assert "отозванное основание" in violations_text(c45.run("validate-step", "--stage", 6))
    dec(c45, "DEC-02", "option", "OPT-01", "CLM-002").ok()
    assert c45.run("validate-step", "--stage", 6).ok()["ok"] is True
    assert "DEC-01" not in [d["id"] for d in c45.run("status").ok()["stale_decisions"]]
    v = c45.run("verify-run")
    assert "DEC-01" not in v.stdout + v.stderr, "verify-run ругается на заменённое решение"


def test_c045_status_history_shows_superseded_by(c45):
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    dec(c45, "DEC-02", "option", "OPT-01", "CLM-002").ok()
    st = c45.run("status").ok()
    assert re.search(r'"superseded_by":\s*"DEC-02"', _all(st)), "status не показывает superseded_by: DEC-02"


def test_c045_handoff_does_not_list_superseded(c45):
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    assert "DEC-01" in handoff_review(c45)  # пока не заменено — требует пересмотра
    dec(c45, "DEC-02", "option", "OPT-01", "CLM-002").ok()
    assert "DEC-01" not in handoff_review(c45)


def test_c045_journal_is_not_rewritten(c45):
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    dec(c45, "DEC-02", "option", "OPT-01", "CLM-002").ok()
    ids = [d["id"] for d in c45.read("decisions.json")["decisions"]]
    assert ids == ["DEC-01", "DEC-02"]
    assert not any("superseded" in k for d in c45.read("decisions.json")["decisions"] for k in d), \
        "поле superseded_by вычисляется и в файл не пишется"


def test_c045_other_kind_does_not_supersede(c45):
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    dec(c45, "DEC-02", "other", None, "CLM-002").ok()
    assert "отозванное основание" in violations_text(c45.run("validate-step", "--stage", 6))
    assert "DEC-01" in handoff_review(c45)
    assert "DEC-01" in [d["id"] for d in c45.run("status").ok()["stale_decisions"]]


def test_c045_current_means_last_recorded_not_highest_id(c45):
    """Атака: порядок записи, а не номер. DEC-05 записано раньше DEC-03."""
    dec(c45, "DEC-05", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    dec(c45, "DEC-03", "option", "OPT-01", "CLM-002").ok()
    assert c45.run("validate-step", "--stage", 6).ok()["ok"] is True
    assert "DEC-05" not in handoff_review(c45)


def test_c045_newer_stale_decision_is_still_a_violation(c45):
    """Заменённое чистое решение не прячет текущее устаревшее."""
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-002").ok()
    dec(c45, "DEC-02", "option", "OPT-01", "CLM-001").ok()
    c45.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    assert "DEC-02" in violations_text(c45.run("validate-step", "--stage", 6))
    assert "DEC-02" in handoff_review(c45)
    assert "DEC-02" in [d["id"] for d in c45.run("status").ok()["stale_decisions"]]


def test_c045_current_decision_incomplete_fields_still_checked(c45):
    """Полный предшественник не прикрывает действующее решение без ответственного, метрики и условия пересмотра."""
    dec(c45, "DEC-01", "option", "OPT-01", "CLM-002").ok()
    assert c45.run("validate-step", "--stage", 6).ok()["ok"] is True
    dec(c45, "DEC-02", "option", "OPT-01", "CLM-002", full=False).ok()
    e = c45.run("validate-step", "--stage", 6).fail(1)
    assert "DEC-02" in _all(e) and "owner" in _all(e)


# =====================================================================
# C-046. Имена в источниках
# =====================================================================

NAMES = FIX / "names_ru.txt"


def ingest(c, f, sid="SRC-01", *extra, cmd="ingest-source"):
    return c.run(cmd, "--file", f, "--id", sid, "--title", "Материал", *extra)


def warn_texts(out):
    return " | ".join(f"{w['text']}" for w in out.get("name_warnings", []))


def test_c046_russian_fio_and_initials_warn(proj):
    out = ingest(proj, NAMES).ok()
    ws_ = out.get("name_warnings")
    assert ws_ and all(isinstance(w.get("line"), int) and isinstance(w.get("text"), str) for w in ws_), out
    t = warn_texts(out)
    for needle in ("Ломакин", "Фёдорова", "Орлов"):
        assert needle in t, f"{needle} не пойман: {ws_}"
    lines = {w["line"] for w in ws_}
    assert {2, 3, 4} <= lines or len(lines) >= 3, lines  # строки с ФИО в любом порядке и с инициалами
    assert "redact-terms" in _all(out), "нет hint про --redact-terms"


def test_c046_ingest_still_ok_and_source_stored_unchanged(proj):
    out = ingest(proj, NAMES).ok()
    assert out["id"] == "SRC-01"
    snap = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    assert "Ломакин Ярослав Игоревич" in snap, "предупреждение не должно менять слепок"


def test_c046_review_signatures_warn(proj):
    out = ingest(proj, FIX / "reviews_signed.txt").ok()
    t = warn_texts(out)
    for name in ("Zinovia", "Кашталинский", "Vostrikova"):
        assert name in t, f"подпись {name} под отзывом не поймана: {out.get('name_warnings')}"


def test_c046_testimonial_layout_like_family_safety_src03(proj):
    """Раскладка как в demo/family_safety/.../SRC-03.txt: текст, строка «Имя,», строка «Mom of two»."""
    out = ingest(proj, FIX / "testimonials_signed.txt").ok()
    t = warn_texts(out)
    for name in ("Zinovia", "Lukerya", "Marfa"):
        assert name in t, f"{name} не пойман (фикстура SRC-03): {out.get('name_warnings')}"


def test_c046_clean_text_has_no_warnings(proj):
    out = ingest(proj, FIX / "names_none.txt").ok()
    assert not out.get("name_warnings"), out.get("name_warnings")
    out2 = ingest(proj, FIX / "source_market.md", "SRC-02").ok()
    assert not out2.get("name_warnings"), out2.get("name_warnings")


def test_c046_warnings_capped_at_20(proj):
    out = ingest(proj, FIX / "names_many.txt").ok()
    assert 0 < len(out["name_warnings"]) <= 20


def test_c046_add_user_input_warns(proj):
    out = proj.run("add-user-input", "--id", "SRC-01",
                   "--text", "Звонил Ломакин Ярослав Игоревич, просил перезвонить.").ok()
    assert "Ломакин" in warn_texts(out)


def test_c046_ingest_url_from_file_warns(proj, tmp_path):
    f = tmp_path / "page.html"
    f.write_text("<html><body><p>Контакт: Фёдорова Мирра Эдуардовна, отдел продаж. "
                 + "Описание страницы про рынок подписок и удержание клиентов. " * 3 + "</p></body></html>",
                 encoding="utf-8")
    out = proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-01", "--from-file", f).ok()
    assert "Фёдорова" in warn_texts(out)


def test_c046_ingest_update_warns(proj_src, tmp_path):
    f = tmp_path / "new.md"
    f.write_text(NAMES.read_text(encoding="utf-8"), encoding="utf-8")
    out = proj_src.run("ingest-update", "--file", f, "--id", "SRC-02", "--title", "Новое", "--reason", "обновление",
                       "--replaces", "SRC-01").ok()
    assert "Ломакин" in warn_texts(out)


# ---- --redact-terms ----

def project_blob(c):
    """Все байты рабочей папки: термин не должен остаться нигде, в том числе в журнале состояния."""
    return b"\n".join(p.read_bytes() for p in sorted(c.ws.rglob("*")) if p.is_file()).decode("utf-8", "ignore")


def test_c046_redact_terms_replaces_everywhere_and_stores_no_terms(proj):
    out = ingest(proj, NAMES, "SRC-01", "--redact-terms", "Ломакин;;Фёдорова").ok()
    expected = NAMES.read_text(encoding="utf-8").count("Ломакин") + NAMES.read_text(encoding="utf-8").count("Фёдорова")
    assert out["redacted_terms"] == expected
    snap = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    assert snap.count("[имя скрыто]") == expected
    blob = project_blob(proj)
    assert "Ломакин" not in blob and "Фёдорова" not in blob, "термин остался в файлах проекта"
    assert "Орлов" in snap, "лишнее скрыто"
    assert proj.run("verify-run").ok()["ok"] is True


def test_c046_redact_terms_registers_quote_on_redacted_text(proj):
    ingest(proj, NAMES, "SRC-01", "--redact-terms", "Ломакин;;Фёдорова").ok()
    proj.claim(text="Рынок вырос", quote="Рынок платных подписок вырос на 14 процентов за год").ok()
    proj.run("verify-quotes").ok()
    proj.claim(text="Подпись", quote="Подписал акт Ломакин Ярослав Игоревич", extra=()).fail(1)


def test_c046_redact_terms_case_sensitive_and_whole_word(proj, tmp_path):
    f = tmp_path / "t.md"
    f.write_text("Иван пришёл. иван ушёл. Иванов остался. Ивану сказали. Иван, Иван! Подробностей достаточно для теста.\n",
                 encoding="utf-8")
    out = ingest(proj, f, "SRC-01", "--redact-terms", "Иван").ok()
    snap = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    assert "иван ушёл" in snap, "регистр не учтён"
    assert "Иванов остался" in snap, "термин-подстрока чужого слова заменена"
    assert "Ивану сказали" in snap
    assert out["redacted_terms"] == 3 and snap.count("[имя скрыто]") == 3


@pytest.mark.parametrize("term", [".*", "A.B", "(Анна", "[Анна]", "C++", "\\d+", "Анна|Мария", "^Анна$", "а{2}", "\\"])
def test_c046_redact_terms_regex_specials_are_literal(proj, tmp_path, term):
    f = tmp_path / "t.md"
    body = "AxB остаётся. Анна и Мария пришли. Аа аа. Цена 5 рублей, всего 12 штук. Строка про C++ и (Анна) тоже. Ещё: .* и [Анна] и \\ тут."
    f.write_text(body + "\n", encoding="utf-8")
    cp = ingest(proj, f, "SRC-01", "--redact-terms", term)
    assert cp.code in (0, 1), cp.stderr  # допустим отказ с понятным текстом, но не трейсбек и не exit 2
    if cp.code == 1:
        cp.fail(1)
        return
    snap = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    for keep in ("AxB остаётся", "Цена 5 рублей", "всего 12 штук", "Мария пришли" if term != "Анна|Мария" else "Ещё"):
        assert keep in snap, f"термин {term!r} сработал как регулярное выражение: {snap!r}"


def test_c046_redact_terms_empty_or_blank_terms_are_harmless(proj, tmp_path):
    f = tmp_path / "t.md"
    f.write_text("Обычный текст источника без имён, достаточно длинный для проверки.\n", encoding="utf-8")
    for i, term in enumerate(["", ";;", "Анна;;", ";;Анна", " ", "   ;;  "]):
        cp = ingest(proj, f, f"SRC-{i + 1:02d}", "--redact-terms", term)
        if cp.code != 0:
            cp.fail(1)
            continue
        snap = (proj.pdir / "raw_materials" / f"SRC-{i + 1:02d}.txt").read_text(encoding="utf-8")
        assert "Обычный текст источника без имён" in snap and "[имя скрыто]" not in snap, (term, snap)


def test_c046_redact_terms_html_copy_is_cleaned_too(proj, tmp_path):
    f = tmp_path / "page.html"
    f.write_text("<html><head><title>Страница</title><!-- автор: Ломакин --></head><body>"
                 "<p data-author=\"Ломакин\">Отзыв оставил Ломакин Ярослав, описание рынка подписок и удержания клиентов "
                 "достаточно подробное, чтобы страница не считалась заглушкой." + " Подробности о рынке." * 30 + "</p>"
                 "<script>var a='Ломакин';</script></body></html>", encoding="utf-8")
    out = proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-01", "--from-file", f,
                   "--redact-terms", "Ломакин").ok()
    assert out["redacted_terms"] >= 1
    raw = proj.pdir / "raw_materials"
    assert any(p.suffix == ".html" for p in raw.iterdir()), "копии .html нет, проверка бессмысленна"
    assert "Ломакин" not in project_blob(proj)


def test_c046_redact_terms_in_user_input(proj):
    out = proj.run("add-user-input", "--id", "SRC-01", "--text", "Клиент Ломакин сказал, что цена высока для него.",
                   "--redact-terms", "Ломакин").ok()
    assert out["redacted_terms"] == 1
    assert "Ломакин" not in project_blob(proj)
    assert "[имя скрыто]" in (proj.pdir / "raw_materials" / "user_inputs.md").read_text(encoding="utf-8")


def test_c046_redact_terms_with_zero_matches_reports_zero(proj):
    out = ingest(proj, FIX / "names_none.txt", "SRC-01", "--redact-terms", "Несуществующий").ok()
    assert out["redacted_terms"] == 0


def test_c046_redact_terms_unmatched_binary_source_clean(proj, tmp_path):
    """csv: термин внутри ячейки скрывается так же, как в тексте."""
    f = tmp_path / "t.csv"
    f.write_text("manager,sales\nЛомакин,10\nПетрова,12\n", encoding="utf-8")
    out = ingest(proj, f, "SRC-01", "--redact-terms", "Ломакин").ok()
    assert out["redacted_terms"] == 1 and "Ломакин" not in project_blob(proj)


# ---- redact-source ----

def redact(c, sid="SRC-01", terms="Ломакин;;Фёдорова", reason="обезличивание"):
    return c.run("redact-source", "--id", sid, "--terms", terms, "--reason", reason)


@pytest.fixture
def named(proj):
    ingest(proj, NAMES, "SRC-01").ok()
    proj.claim(text="Рынок вырос", quote="Рынок платных подписок вырос на 14 процентов за год").ok()
    return proj


def test_c046_redact_source_cleans_updates_hash_and_logs(named):
    h_before = named.read("state.json")["validation_hash"]
    src_before = named.read("sources.json")["sources"][0]
    out = redact(named).ok()
    text = NAMES.read_text(encoding="utf-8")
    expected = text.count("Ломакин") + text.count("Фёдорова")
    assert out["ok"] is True and expected in [v for v in out.values() if isinstance(v, int) and not isinstance(v, bool)], out
    snap_p = named.pdir / "raw_materials" / "SRC-01.txt"
    snap = snap_p.read_text(encoding="utf-8")
    assert "Ломакин" not in snap and "Фёдорова" not in snap and snap.count("[имя скрыто]") == expected
    src = named.read("sources.json")["sources"][0]
    assert src["text_sha256"] != src_before["text_sha256"] or src.get("sha256") != src_before.get("sha256")
    assert named.read("state.json")["validation_hash"] != h_before
    st = named.read("state.json")
    ops = [o for o in st["completed_operations_log"] if "redact" in o["op"]]
    assert ops and ops[-1].get("result_id") == "SRC-01", st["completed_operations_log"][-3:]
    assert "Ломакин" not in project_blob(named) and "Фёдорова" not in project_blob(named), "термин сохранён в журнале"


def test_c046_redact_source_then_verify_run_ok_and_commands_work(named):
    redact(named).ok()
    v = named.run("verify-run").ok()
    assert v["ok"] is True and v["checks"]["integrity"] == "ok" and v["checks"]["quotes"] in ("ok", "skip")
    named.run("verify-quotes").ok()
    named.run("status").ok()
    named.claim(text="Ещё один", quote="Рынок платных подписок вырос на 14 процентов за год").ok()


def test_c046_redact_source_idempotent(named):
    redact(named).ok()
    snap1 = (named.pdir / "raw_materials" / "SRC-01.txt").read_bytes()
    srcs1 = (named.pdir / "sources.json").read_bytes()
    out = redact(named).ok()
    assert out["ok"] is True
    ints = [v for v in out.values() if isinstance(v, int) and not isinstance(v, bool)]
    assert 0 in ints, f"не видно числа замен = 0: {out}"
    assert (named.pdir / "raw_materials" / "SRC-01.txt").read_bytes() == snap1
    assert (named.pdir / "sources.json").read_bytes() == srcs1
    assert named.run("verify-run").ok()["ok"] is True


def test_c046_redact_source_refuses_term_in_active_claim_quote(named):
    named.claim(text="Подписание", quote="Подписал акт Ломакин Ярослав Игоревич", extra=()).ok()
    before = tree(named)
    e = redact(named).fail(1)
    assert "CLM-002" in _all(e) or "цитат" in _all(e).lower()
    assert tree(named) == before, "при отказе что-то записано"


def test_c046_redact_source_refuses_term_in_revoked_claim_quote(named):
    named.claim(text="Подписание", quote="Подписал акт Ломакин Ярослав Игоревич", extra=()).ok()
    named.run("revoke-claim", "--id", "CLM-002", "--reason", "устарело").ok()
    before = tree(named)
    redact(named).fail(1)
    assert tree(named) == before


def test_c046_redact_source_term_only_in_other_sources_claim_is_fine(named):
    ingest(named, NAMES, "SRC-02").ok()
    named.claim(text="Подписание", source="SRC-02", quote="Подписал акт Ломакин Ярослав Игоревич").ok()
    out = redact(named, "SRC-01").ok()
    assert out["ok"] is True
    assert "Ломакин" in (named.pdir / "raw_materials" / "SRC-02.txt").read_text(encoding="utf-8"), "чужой источник тронут"
    assert named.run("verify-run").ok()["ok"] is True


def test_c046_redact_source_whole_word_only(named, tmp_path):
    f = tmp_path / "t.md"
    f.write_text("Иван сказал. Иванов ответил. Иванова ушла. Достаточно текста для проверки слепка.\n", encoding="utf-8")
    ingest(named, f, "SRC-02").ok()
    redact(named, "SRC-02", terms="Иван").ok()
    snap = (named.pdir / "raw_materials" / "SRC-02.txt").read_text(encoding="utf-8")
    assert "Иванов ответил" in snap and "Иванова ушла" in snap and "[имя скрыто] сказал" in snap


@pytest.mark.parametrize("terms", ["", ";;", " ", "  ;;  "])
def test_c046_redact_source_empty_terms(named, terms):
    before = tree(named)
    snap0 = (named.pdir / "raw_materials" / "SRC-01.txt").read_bytes()
    r = redact(named, terms=terms)
    if r.code == 0:
        assert (named.pdir / "raw_materials" / "SRC-01.txt").read_bytes() == snap0, "пустой термин что-то заменил"
    else:
        assert r.code in (1, 2) and "Traceback" not in r.stderr
    assert named.run("verify-run").ok()["ok"] is True


@pytest.mark.parametrize("term", [".*", "A.B", "(Анна", "\\d+", "[", "Ломакин|Орлов"])
def test_c046_redact_source_regex_specials_literal(named, term):
    r = redact(named, terms=term)
    assert r.code in (0, 1) and "Traceback" not in r.stderr, r.stderr
    snap = (named.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    assert "Рынок платных подписок вырос на 14 процентов" in snap and "Ломакин Ярослав Игоревич" in snap
    assert named.run("verify-run").ok()["ok"] is True


OVERLAP_TEXT = "Иван Петров пришёл. Потом Иван ушёл, а Петров остался. Достаточно текста для проверки слепка.\n"


@pytest.mark.parametrize("terms", ["Иван;;Иван Петров", "Иван Петров;;Иван"])
def test_c046_redact_source_overlapping_terms_do_not_depend_on_order(proj, tmp_path, terms):
    """Атака: короткий термин — начало длинного. Если он идёт первым, у длинного остаётся фамилия."""
    f = tmp_path / "t.md"
    f.write_text(OVERLAP_TEXT, encoding="utf-8")
    ingest(proj, f, "SRC-01").ok()
    redact(proj, terms=terms).ok()
    snap = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    assert "Иван Петров" not in snap and "[имя скрыто] Петров пришёл" not in snap, f"у длинного термина осталась фамилия: {snap!r}"
    assert "Петров остался" in snap or terms.startswith("Иван;;"), snap  # отдельное «Петров» не термин


@pytest.mark.parametrize("term", ["имя", "скрыто"])
def test_c046_redact_source_term_inside_mask_does_not_corrupt_it(proj, tmp_path, term):
    """Атака: термин совпал со словом внутри маски [имя скрыто]: маска не должна ломаться и вкладываться."""
    f = tmp_path / "t.md"
    f.write_text("Ломакин пришёл. Достаточно текста для проверки слепка. Имя поля и слово скрыто тоже есть.\n", encoding="utf-8")
    ingest(proj, f, "SRC-01").ok()
    redact(proj, terms="Ломакин").ok()
    before = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    redact(proj, terms=term).ok()
    after = (proj.pdir / "raw_materials" / "SRC-01.txt").read_text(encoding="utf-8")
    assert after.count("[имя скрыто]") == before.count("[имя скрыто]") and "[[" not in after, after


def test_c046_redact_source_html_copy_cleaned(proj, tmp_path):
    f = tmp_path / "page.html"
    f.write_text("<html><body><p>Контакт: Ломакин Ярослав, отдел продаж. Описание страницы про рынок подписок и "
                 "удержание клиентов достаточно длинное, чтобы не быть заглушкой." + " Подробности о рынке." * 30 + "</p></body></html>", encoding="utf-8")
    proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-01", "--from-file", f).ok()
    assert "Ломакин" in project_blob(proj)
    redact(proj, terms="Ломакин").ok()
    assert "Ломакин" not in project_blob(proj)
    assert proj.run("verify-run").ok()["ok"] is True


def test_c046_redact_source_unknown_id_and_missing_args(proj):
    redact(proj, "SRC-77").fail(1)
    r = proj.run("redact-source", "--id", "SRC-01", "--terms", "A")  # без --reason
    assert r.code != 0 and "Traceback" not in r.stderr


def test_c046_manual_edit_after_redact_still_detected(named):
    """Слепок после redact-source остаётся под защитой: правка вручную ловится так же, как до обезличивания."""
    redact(named).ok()
    p = named.pdir / "raw_materials" / "SRC-01.txt"
    p.write_text(p.read_text(encoding="utf-8").replace("14 процентов", "40 процентов"), encoding="utf-8")
    named.claim(text="ложь", quote="Рынок платных подписок вырос на 40 процентов").fail(3)
    e = named.run("accept-edit", "--reason", "правка слепка").fail(1)
    assert "SRC-01" in _all(e)
    v = named.run("verify-run")
    assert v.code in (1, 3), (v.code, v.stdout)


def test_c046_manual_state_edit_after_redact_still_detected(named):
    redact(named).ok()
    s = named.read("sources.json")
    s["sources"][0]["title"] = "Подмена"
    named.write("sources.json", s)
    named.run("validate-step", "--stage", 1).fail(3)


def test_c046_redact_source_symlink_snapshot_not_followed(named, tmp_path):
    """Атака: снимок заменён симлинком на файл вне проекта с тем же содержимым. Внешний файл менять нельзя."""
    snap = named.pdir / "raw_materials" / "SRC-01.txt"
    outside = tmp_path / "outside.txt"
    outside.write_bytes(snap.read_bytes())
    snap.unlink()
    snap.symlink_to(outside)
    before = outside.read_bytes()
    r = redact(named)
    assert outside.read_bytes() == before, "redact-source записал через симлинк во внешний файл"
    assert r.code in (1, 3), (r.code, r.stdout, r.stderr)
    assert "Traceback" not in r.stderr


def test_c046_redact_source_symlinked_html_copy_not_followed(proj, tmp_path):
    f = tmp_path / "page.html"
    f.write_text("<html><body><p>Контакт: Ломакин Ярослав, отдел продаж. Описание страницы про рынок подписок и "
                 "удержание клиентов достаточно длинное, чтобы не быть заглушкой." + " Подробности о рынке." * 30 + "</p></body></html>", encoding="utf-8")
    proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-01", "--from-file", f).ok()
    html = proj.pdir / "raw_materials" / "SRC-01.html"
    outside = tmp_path / "outside.html"
    outside.write_bytes(html.read_bytes())
    html.unlink()
    html.symlink_to(outside)
    before = outside.read_bytes()
    r = redact(proj, terms="Ломакин")
    assert outside.read_bytes() == before
    assert "Traceback" not in r.stderr


def test_c046_redact_source_not_in_mcp():
    sys.path.insert(0, str(REPO / "tools"))
    try:
        from modules import mcp_adapter
        names = {t["name"] for t in mcp_adapter.list_tools()}
        for bad in ("redact_source", "redact-source", "redactsource"):
            assert bad not in names
        assert "ingest_source" in names and "accept_edit" not in names
    finally:
        sys.path.remove(str(REPO / "tools"))


def test_c046_redact_source_registered_in_cli_help(proj):
    r = proj.run("redact-source", "--help", project=False, ws=False)
    assert r.code == 0 and "--terms" in r.stdout and "--reason" in r.stdout


# =====================================================================
# C-047. Мелочи бэкенда
# =====================================================================

def calc(c, formula, inputs, cid="CALC-01"):
    return c.run("register-calc", "--id", cid, "--formula", formula, "--inputs", json.dumps(inputs),
                 "--source", "SRC-01", "--unit", "")


@pytest.mark.parametrize("formula,inputs,expected", [
    ("a ** 2", {"a": 3}, 9), ("a ** 10", {"a": 2}, 1024), ("a ** -2", {"a": 2}, 0.25), ("a ** 0", {"a": 7}, 1),
    ("sqrt(a)", {"a": 16}, 4), ("sqrt(a * b)", {"a": 2, "b": 8}, 4), ("sqrt(a) ** 2", {"a": 9}, 9),
    ("2 ** 3 ** 2", {"a": 1}, 512), ("a ** 2 + b ** 2", {"a": 3, "b": 4}, 25),
])
def test_c047_pow_and_sqrt_allowed(proj_src, formula, inputs, expected):
    out = calc(proj_src, formula, inputs).ok()
    assert out["result"] == pytest.approx(expected)
    assert proj_src.read("calculations.json")["calculations"][0]["result"] == pytest.approx(expected)


@pytest.mark.parametrize("formula,inputs", [
    ("a ** 11", {"a": 2}), ("a ** 100", {"a": 2}), ("a ** -11", {"a": 2}), ("a ** b", {"a": 2, "b": 11}),
    ("2 ** 3 ** 3", {"a": 1}), ("9 ** 9 ** 9", {"a": 1}), ("a ** (b + 5)", {"a": 2, "b": 6}),
    ("sqrt(a)", {"a": -4}), ("sqrt(a, b)", {"a": 4, "b": 1}), ("sqrt()", {"a": 4}), ("sqrt", {"a": 4}),
    ("abs(a)", {"a": -4}), ("pow(a, 2)", {"a": 2}), ("log(a)", {"a": 2}), ("__import__('os')", {"a": 1}),
    ("a ** 2.5 ** 9", {"a": 2}), ("a.real", {"a": 2}), ("a ** 'x'", {"a": 2}),
])
def test_c047_pow_sqrt_attacks_exit_1(proj_src, formula, inputs):
    before = (proj_src.pdir / "calculations.json").read_bytes(), (proj_src.pdir / "state.json").read_bytes()
    calc(proj_src, formula, inputs).fail(1)
    assert ((proj_src.pdir / "calculations.json").read_bytes(), (proj_src.pdir / "state.json").read_bytes()) == before


def test_c047_calc_with_pow_is_reproducible_and_tamper_detected(proj_src):
    calc(proj_src, "a ** 2", {"a": 3}).ok()
    proj_src.run("register-claim", "--type", "FACT", "--origin", "CALCULATION", "--source", "SRC-01", "--calc",
                 "CALC-01", "--text", "Квадрат трёх").ok()
    assert proj_src.run("verify-run").ok()["ok"] is True
    c = proj_src.read("calculations.json")
    c["calculations"][0]["result"] = 10
    proj_src.write("calculations.json", c)
    proj_src.run("verify-run").fail(3)


def test_c047_analyze_table_sheet_on_csv_exit_1(proj, tmp_path):
    proj.run("ingest-source", "--file", FIX / "sample.csv", "--id", "SRC-01").ok()
    before = tree(proj)
    e = proj.run("analyze-table", "--source", "SRC-01", "--sheet", "Лист1").fail(1)
    assert "xlsx" in _all(e).lower(), "в hint нет пояснения, что листы бывают только у xlsx"
    assert tree(proj) == before, "отказ оставил следы (например, отчёт в analysis/)"
    proj.run("analyze-table", "--source", "SRC-01").ok()  # без --sheet по-прежнему работает


def test_c047_analyze_table_empty_sheet_name_on_csv_exit_1(proj):
    proj.run("ingest-source", "--file", FIX / "sample.csv", "--id", "SRC-01").ok()
    r = proj.run("analyze-table", "--source", "SRC-01", "--sheet", "")
    assert r.code in (0, 1) and "Traceback" not in r.stderr
