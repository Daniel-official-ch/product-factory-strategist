"""Общие фикстуры QA. Тесты пишутся по контрактам команды, не по коду."""
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]
CLI = REPO / "tools" / "cli.py"
FIX = Path(__file__).resolve().parent / "fixtures"

# C-040 п.7: тесты инфраструктуры команды пропускаются в чистой копии (там этой папки нет).
# Имена собраны по частям: упоминать их буквально в копии нельзя (проверка C-040 п.6).
TEAM_INFRA = (REPO / "tools" / ("te" + "am") / ("ga" + "te.py")).is_file()
needs_team_infra = pytest.mark.skipif(not TEAM_INFRA, reason="инфраструктуры команды нет (чистая копия)")

MARKET_QUOTE = "Рынок платных подписок вырос на 14 процентов"


class Result:
    def __init__(self, cp):
        self.code = cp.returncode
        self.stdout = cp.stdout
        self.stderr = cp.stderr

    @property
    def out(self):
        lines = [l for l in self.stdout.strip().splitlines() if l.strip()]
        assert len(lines) == 1, f"ожидалась одна JSON-строка в stdout, получено: {self.stdout!r} / stderr={self.stderr!r}"
        return json.loads(lines[0])

    @property
    def err(self):
        return json.loads(self.stderr.strip().splitlines()[-1] if self.stderr.strip() else "null")

    def ok(self):
        assert self.code == 0, f"exit {self.code}: stdout={self.stdout!r} stderr={self.stderr!r}"
        return self.out

    def fail(self, code=1):
        assert self.code == code, f"ожидался exit {code}, получен {self.code}: stdout={self.stdout!r} stderr={self.stderr!r}"
        assert "Traceback" not in self.stderr, f"трейсбек показан пользователю: {self.stderr}"
        # exit 1 из-за несуществующей команды не засчитывается как отказ по делу (защита от ложно-зелёных тестов)
        assert "invalid choice" not in self.stderr, f"команда не реализована: {self.stderr}"
        e = self.err
        assert isinstance(e, dict), f"stderr не JSON-объект: {self.stderr!r}"
        assert isinstance(e.get("error"), str) and e["error"].strip(), f"нет error: {e}"
        assert isinstance(e.get("hint"), str) and e["hint"].strip(), f"нет hint: {e}"
        return e


class Cli:
    def __init__(self, ws: Path, project="proj", cli=CLI, cwd=None):
        self.ws, self.project, self.cli, self.cwd = ws, project, cli, cwd

    @property
    def pdir(self) -> Path:
        return self.ws / self.project

    def run(self, *args, project=True, ws=True, env_extra=None):
        cmd = [sys.executable, str(self.cli)]
        if ws:
            cmd += ["--workspace", str(self.ws)]
        if project:
            cmd += ["--project", self.project]
        cmd += [str(a) for a in args]
        env = {k: v for k, v in os.environ.items() if k != "STRATEGIST_WORKSPACE"}
        env.update(env_extra or {})
        cp = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=self.cwd or REPO, timeout=60)
        return Result(cp)

    # --- чтение данных проекта напрямую (проверка артефактов, не логики) ---
    def read(self, name):
        return json.loads((self.pdir / name).read_text(encoding="utf-8"))

    def write(self, name, data):
        (self.pdir / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def snapshot(self):
        return {n: (self.pdir / n).read_bytes() for n in
                ("state.json", "evidence_db.json", "sources.json", "options.json", "calculations.json")}

    # --- сценарные помощники ---
    def init(self):
        return self.run("init", "--name", "Человекочитаемое имя", "--question", "Стоит ли запускать подписку?").ok()

    def ingest_market(self, sid="SRC-01"):
        return self.run("ingest-source", "--file", FIX / "source_market.md", "--id", sid, "--title", "Обзор").ok()

    def claim(self, text="Рынок вырос", quote=MARKET_QUOTE, source="SRC-01", typ="FACT",
              origin="PRIMARY_SOURCE", extra=()):
        args = ["register-claim", "--type", typ, "--origin", origin, "--text", text]
        if source:
            args += ["--source", source]
        if quote:
            args += ["--quote", quote]
        return self.run(*args, *extra)

    def option(self, oid, typ, title=None, objections="Сильное возражение один;;Второе возражение", extra=()):
        return self.run("register-option", "--id", oid, "--type", typ, "--title", title or f"Вариант {oid}",
                        "--summary", f"Суть {oid}", "--objections", objections, *extra)

    def accept_strategy(self, did="DEC-03"):
        """C-027: приёмка стратегии человеком."""
        return self.run("record-decision", "--id", did, "--kind", "strategy", "--text", "Стратегия принята").ok()

    def confirm_brief(self, did="DEC-91"):
        """C-044: подтверждение брифа человеком (ID выбран так, чтобы не пересекаться с ID в самих тестах)."""
        return self.run("record-decision", "--id", did, "--kind", "brief", "--text", "Бриф подтверждён").ok()

    def choose_option(self, oid="OPT-01", did="DEC-92"):
        """C-044: выбор варианта человеком."""
        return self.run("record-decision", "--id", did, "--kind", "option", "--option", oid,
                        "--text", "Выбран вариант").ok()

    def three_options(self, claims=None):
        ex = ("--claims", claims) if claims else ()
        self.option("OPT-01", "keep_as_is", "Оставить как есть", extra=ex).ok()
        self.option("OPT-02", "close_direction", "Закрыть направление", extra=ex).ok()
        self.option("OPT-03", "custom", "Запустить пилот", extra=ex).ok()


@pytest.fixture
def ws(tmp_path):
    return tmp_path / "ws"


@pytest.fixture
def cli(ws):
    return Cli(ws)


@pytest.fixture
def proj(cli):
    """Инициализированный проект."""
    cli.init()
    return cli


@pytest.fixture
def proj_src(proj):
    """Проект с источником SRC-01 (fixtures/source_market.md)."""
    proj.ingest_market()
    return proj
