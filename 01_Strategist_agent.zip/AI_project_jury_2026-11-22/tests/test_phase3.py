"""Приёмка волны 3 (T-311): контракты C-023…C-028 из файла контрактов команды.

Тесты пишутся по контракту, не по коду. Все проверки идут во временных папках.
Единственный пропуск — реальный stdio-тест MCP, которому нужен fastmcp (pytest.importorskip).
"""
import asyncio
import hashlib
import json
import re
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from conftest import FIX, MARKET_QUOTE, REPO, Cli

TOOLS = REPO / "tools"
NO_PROXY = {"NO_PROXY": "*", "no_proxy": "*", "HTTP_PROXY": "", "http_proxy": "", "HTTPS_PROXY": "", "https_proxy": ""}
UA = "Mozilla/5.0 (compatible; StrategistAgent/1.0)"


# ------------------------------- помощники -------------------------------

def _all(e):
    return json.dumps(e, ensure_ascii=False)


def html(text, title=""):
    return f"<html><head><title>{title}</title></head><body><p>{text}</p></body></html>"


def write_html(tmp_path, text, name="page.html", title=""):
    p = tmp_path / name
    p.write_text(html(text, title), encoding="utf-8")
    return p


def article(n=400):
    return ("Подписочный сервис вырос на четырнадцать процентов за квартал. " * 30)[:n]


def source_ids(c):
    return [s["id"] for s in c.read("sources.json")["sources"]]


def raw_listing(c):
    d = c.pdir / "raw_materials"
    return sorted(str(p.relative_to(d)) for p in d.rglob("*") if p.is_file()) if d.exists() else []


def state_of_files(c):
    """Всё, что команда загрузки обязана оставить нетронутым после отказа."""
    return {"raw": raw_listing(c), "sources": (c.pdir / "sources.json").read_bytes(),
            "user_inputs": (c.pdir / "raw_materials" / "user_inputs.md").exists(),
            "evidence": (c.pdir / "evidence_db.json").read_bytes(),
            "state": (c.pdir / "state.json").read_bytes()}


def compress(text):
    import unicodedata
    return re.sub(r"[\s\-()+./\u00a0\u2013\u2014]", "", unicodedata.normalize("NFKC", text))


def leaks(root, needles, outputs=()):
    """Где встречается полное значение: в любом файле под root и в выводе команд (в т.ч. бинарные файлы и копии)."""
    found = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        txt = p.read_bytes().decode("utf-8", errors="ignore")
        for lit, core in needles:
            if lit in txt or (core and core in compress(txt)):
                found.append(str(p.relative_to(root)))
    for out in outputs:
        for lit, core in needles:
            if lit in out or (core and core in compress(out)):
                found.append("<вывод команды>")
    return found


def snapshot_text(c, sid):
    src = next(s for s in c.read("sources.json")["sources"] if s["id"] == sid)
    return (c.pdir / src["text_path"]).read_text(encoding="utf-8")


def rehash(c: Cli):
    """Имитация обхода CLI: правим файлы и пересчитываем validation_hash по формуле C-010 п.1."""
    st = c.read("state.json")
    st.pop("validation_hash", None)
    obj = {"state": st, "evidence_db": c.read("evidence_db.json"), "options": c.read("options.json"),
           "sources": c.read("sources.json"), "calculations": c.read("calculations.json"),
           "decisions": c.read("decisions.json")}
    h = hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
    st = c.read("state.json")
    st["validation_hash"] = h
    c.write("state.json", st)


def violations(r):
    e = r.fail(1)
    assert isinstance(e["violations"], list) and e["violations"]
    for v in e["violations"]:
        assert {"check", "where", "detail"} <= set(v), v
    return e["violations"]


def deliverable(c: Cli, text, name="test_doc.md"):
    (c.pdir / "deliverables" / name).write_text(text, encoding="utf-8")


# ------------------------------- локальный HTTP-сервер -------------------------------

STUB_PAGE = ("<html><head><title>DDoS-Guard</title></head><body><h1>Checking your browser before accessing</h1>"
             "<p>This process is automatic. DDoS-Guard</p></body></html>")


class Srv:
    def __init__(self):
        self.requests = []  # [(path, headers dict)]
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                outer.requests.append((self.path, {k: v for k, v in self.headers.items()}))
                if self.path == "/403":
                    return self._send(403, "<html><body>Forbidden</body></html>")
                if self.path == "/404":
                    return self._send(404, "<html><body>Not found</body></html>")
                if self.path == "/500":
                    return self._send(500, "<html><body>Oops</body></html>")
                if self.path == "/stub":
                    return self._send(200, STUB_PAGE)
                if self.path == "/ok":  # сервер, как у части сайтов, отказывает без правильного User-Agent
                    if self.headers.get("User-Agent") != UA:
                        return self._send(403, "<html><body>bots not allowed</body></html>")
                    return self._send(200, html(article(600), "Статья"))
                self._send(404, "")

            def _send(self, code, body):
                data = body.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        self.t = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.t.start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()


@pytest.fixture
def srv():
    s = Srv()
    yield s
    s.close()


def ingest_url(c, url, sid="SRC-03", *extra):
    return c.run("ingest-url", "--url", url, "--id", sid, *extra, env_extra=NO_PROXY)


# ============================== C-023 ingest-url: User-Agent и коды ответа ==============================

@pytest.mark.parametrize("code", [403, 404, 500])
def test_c023_http_error_code_is_shown_without_exception_name(proj, srv, code):
    before = state_of_files(proj)
    e = ingest_url(proj, f"{srv.url}/{code}").fail(1)
    assert str(code) in e["error"], e
    for bad in ("HTTPError", "RequestException", "requests", "Exception", "Traceback", "urllib"):
        assert bad not in _all(e), (bad, e)
    assert state_of_files(proj) == before and "SRC-03" not in source_ids(proj)


def test_c023_403_hint_points_to_from_file(proj, srv):
    e = ingest_url(proj, f"{srv.url}/403").fail(1)
    assert "--from-file" in e["hint"]


def test_c023_200_ok_and_user_agent_exact(proj, srv):
    """Сервер /ok отдаёт 403 всем, кроме точного User-Agent из контракта: 200 доказывает заголовок."""
    out = ingest_url(proj, f"{srv.url}/ok").ok()
    assert out["id"] == "SRC-03"
    got = [h for p, h in srv.requests if p == "/ok"]
    assert got and got[0].get("User-Agent") == UA
    assert "SRC-03" in source_ids(proj)


def test_c023_no_personal_headers_sent(proj, srv):
    ingest_url(proj, f"{srv.url}/ok").ok()
    h = {k.lower(): v for k, v in next(h for p, h in srv.requests if p == "/ok").items()}
    for k in ("cookie", "authorization", "referer", "x-forwarded-for", "from"):
        assert k not in h, h
    blob = json.dumps(h)
    import getpass, socket
    assert getpass.getuser() not in blob and socket.gethostname() not in blob


def test_c023_default_python_requests_user_agent_is_gone(proj, srv):
    ingest_url(proj, f"{srv.url}/ok").ok()
    ua = next(h for p, h in srv.requests if p == "/ok")["User-Agent"]
    assert "python-requests" not in ua


def test_c023_unreachable_host_is_json_error_not_traceback(proj):
    e = proj.run("ingest-url", "--url", "http://127.0.0.1:9/x", "--id", "SRC-03", env_extra=NO_PROXY).fail(1)
    assert "Traceback" not in _all(e)
    assert "SRC-03" not in source_ids(proj)


# ============================== C-024 заглушки ==============================

def test_c024_ddos_guard_stub_from_file_rejected_nothing_left(proj, tmp_path):
    f = tmp_path / "stub.html"
    f.write_text(STUB_PAGE, encoding="utf-8")
    before = state_of_files(proj)
    e = proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-03", "--from-file", f).fail(1)
    assert "заглушк" in e["error"].lower()
    assert state_of_files(proj) == before
    assert "SRC-03" not in source_ids(proj) and raw_listing(proj) == []


def test_c024_ddos_guard_stub_via_server_rejected_nothing_left(proj, srv):
    before = state_of_files(proj)
    e = ingest_url(proj, f"{srv.url}/stub").fail(1)
    assert "заглушк" in e["error"].lower()
    assert state_of_files(proj) == before and raw_listing(proj) == []


def test_c024_hint_mentions_force_or_from_file(proj, tmp_path):
    f = tmp_path / "stub.html"
    f.write_text(STUB_PAGE, encoding="utf-8")
    e = proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-03", "--from-file", f).fail(1)
    assert "--force" in e["hint"] or "--from-file" in e["hint"]


MARKERS = ["checking your browser", "ddos-guard", "just a moment", "enable javascript and cookies",
           "access denied", "verify you are human", "captcha"]


@pytest.mark.parametrize("marker", MARKERS)
def test_c024_each_marker_with_text_below_1000_is_stub(proj, tmp_path, marker):
    text = (marker + " ") + "а" * 500
    f = write_html(tmp_path, text)
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).fail(1)
    assert raw_listing(proj) == []


@pytest.mark.parametrize("marker", ["Just A Moment", "DDOS-GUARD", "Verify You Are Human", "CAPTCHA"])
def test_c024_marker_is_case_insensitive(proj, tmp_path, marker):
    f = write_html(tmp_path, marker + " " + "б" * 500)
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).fail(1)


def test_c024_marker_boundary_999_stub_1000_page(proj, tmp_path):
    t = "captcha "
    f = write_html(tmp_path, t + "а" * (999 - len(t)))
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).fail(1)
    f = write_html(tmp_path, t + "а" * (1000 - len(t)), "p2.html")
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).ok()


def test_c024_long_real_article_mentioning_captcha_is_not_stub(proj, tmp_path):
    f = write_html(tmp_path, article(1500) + " Капча (captcha) мешает ботам.")
    out = proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).ok()
    assert out["id"] == "SRC-03" and "SRC-03" in source_ids(proj)


def test_c024_short_page_without_marker_is_stub_boundary_199_200(proj, tmp_path):
    f = write_html(tmp_path, "в" * 199)
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).fail(1)
    assert raw_listing(proj) == []
    f = write_html(tmp_path, "в" * 200, "p2.html")
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).ok()


def test_c024_length_counts_cleaned_text_not_html(proj, tmp_path):
    """Тяжёлая разметка, скрипты и стили при коротком тексте не делают страницу «настоящей»."""
    junk = "<script>" + "var a=1;" * 500 + "</script><style>" + ".x{}" * 500 + "</style>"
    f = tmp_path / "heavy.html"
    f.write_text(f"<html><body>{junk}<p>Привет, мир</p></body></html>", encoding="utf-8")
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).fail(1)
    assert raw_listing(proj) == []


def test_c024_force_loads_stub_and_marks_forced(proj, tmp_path):
    f = tmp_path / "stub.html"
    f.write_text(STUB_PAGE, encoding="utf-8")
    out = proj.run("ingest-url", "--url", "https://example.com/p", "--id", "SRC-03", "--from-file", f, "--force").ok()
    assert out.get("forced") is True
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-03")
    assert src.get("forced") is True
    assert raw_listing(proj)


def test_c024_force_via_server(proj, srv):
    out = ingest_url(proj, f"{srv.url}/stub", "SRC-03", "--force").ok()
    assert out.get("forced") is True
    assert next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-03")["forced"] is True


def test_c024_normal_page_is_not_marked_forced(proj):
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", FIX / "page.html").ok()
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-03")
    assert not src.get("forced")


def test_c024_forced_always_present_in_ingest_url_output(proj):
    out = proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", FIX / "page.html").ok()
    assert out["forced"] is False


def test_c024_stub_check_applies_to_from_file_in_a_second_call_after_reject(proj, tmp_path):
    """Отказ не оставляет следов: тот же ID можно сразу занять нормальной страницей."""
    f = tmp_path / "stub.html"
    f.write_text(STUB_PAGE, encoding="utf-8")
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", f).fail(1)
    proj.run("ingest-url", "--url", "https://e.example/p", "--id", "SRC-03", "--from-file", FIX / "page.html").ok()


# ============================== C-025 персональные данные ==============================

PHONES = [
    "+7 912 345-67-05", "8 (912) 345-67-05", "+7(912)3456705", "8-912-345-67-05", "89123456705",
    "79123456705", "+79123456705", "7 912 345 67 05", "8 912 345 67 05", "+7 (912) 345-67-05",
    "+7\u00a0912\u00a0345-67-05", "8\u2013912\u2013345\u201367\u201305", "8\u2014912\u2014345\u201467\u201405",
    "8.912.345.67.05", "8/912/345/67/05", "８９１２３４５６７０５", "+7\u2009912\u2009345 67 05",
]
CORE = "9123456705"
EMAIL = "ivan.petrov@example.com"


def pii_file(tmp_path, body, name="src.md"):
    p = tmp_path / name
    p.write_text(f"# Заметки по рынку\n\nРынок платных подписок вырос на 14 процентов за год.\n\n{body}\n",
                 encoding="utf-8")
    return p


def ingest_file(c, path, sid="SRC-05", *extra):
    return c.run("ingest-source", "--file", path, "--id", sid, "--title", "T", *extra)


@pytest.mark.parametrize("phone", PHONES)
def test_c025_phone_formats_rejected_without_flag_nothing_left(proj, tmp_path, phone):
    f = pii_file(tmp_path, f"Позвоните по номеру {phone} для заказа.")
    before = state_of_files(proj)
    r = ingest_file(proj, f)
    e = r.fail(1)
    assert "--redact-pii" in e["hint"]
    assert state_of_files(proj) == before and "SRC-05" not in source_ids(proj)
    assert leaks(proj.ws, [(phone, CORE)], [r.stdout, r.stderr]) == []


def test_c025_error_counts_by_type_and_violations_are_masked_max5(proj, tmp_path):
    body = "\n".join(f"Тел. {p}" for p in PHONES[:7]) + f"\nПочта {EMAIL}, ещё anna@example.com"
    r = ingest_file(proj, pii_file(tmp_path, body))
    e = r.fail(1)
    assert "7" in e["error"] and "2" in e["error"], e["error"]  # 7 телефонов, 2 почты
    assert "телефон" in e["error"].lower() and "почт" in e["error"].lower()
    vs = e["violations"]
    assert 1 <= len(vs) <= 5
    blob = _all(vs)
    assert "***" in blob and "@example.com" in blob
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None), ("anna@", None)] + [(p, CORE) for p in PHONES],
                 [r.stdout, r.stderr]) == []


def test_c025_email_rejected_and_masked(proj, tmp_path):
    r = ingest_file(proj, pii_file(tmp_path, f"Пишите на {EMAIL}."))
    e = r.fail(1)
    assert "почт" in e["error"].lower()
    assert "i***@example.com" in _all(e["violations"]) or "***@example.com" in _all(e["violations"])
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None)], [r.stdout, r.stderr]) == []
    assert raw_listing(proj) == []


@pytest.mark.parametrize("phone", PHONES)
def test_c025_redact_removes_phone_everywhere(proj, tmp_path, phone):
    f = pii_file(tmp_path, f"Позвоните по номеру {phone} для заказа.")
    r = ingest_file(proj, f, "SRC-05", "--redact-pii")
    out = r.ok()
    assert out["pii_redacted"] == 1
    assert "[телефон скрыт]" in snapshot_text(proj, "SRC-05")
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-05")
    assert src["pii_redacted"] == 1 and src["raw_copy"] is True
    assert leaks(proj.ws, [(phone, CORE)], [r.stdout, r.stderr]) == []


def test_c025_redact_email_and_phone_together(proj, tmp_path):
    f = pii_file(tmp_path, f"Иван {EMAIL}, тел. +7 912 345-67-05; запасной 8 (912) 345-67-05.")
    r = ingest_file(proj, f, "SRC-05", "--redact-pii")
    assert r.ok()["pii_redacted"] == 3
    t = snapshot_text(proj, "SRC-05")
    assert "[почта скрыта]" in t and t.count("[телефон скрыт]") == 2
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None), (PHONES[0], CORE), (PHONES[1], CORE)],
                 [r.stdout, r.stderr]) == []


def test_c025_redacted_text_copy_in_raw_materials_is_also_clean(proj, tmp_path):
    f = pii_file(tmp_path, f"Тел. {PHONES[0]}")
    ingest_file(proj, f, "SRC-05", "--redact-pii").ok()
    copies = [p for p in (proj.pdir / "raw_materials").rglob("*") if p.is_file()]
    assert copies, "raw_copy=true обещает очищенную копию"
    for p in copies:
        assert CORE not in compress(p.read_text(encoding="utf-8", errors="ignore"))


def test_c025_redact_is_idempotent(proj, tmp_path):
    f = pii_file(tmp_path, f"Тел. {PHONES[0]}")
    a = ingest_file(proj, f, "SRC-05", "--redact-pii").ok()
    b = ingest_file(proj, f, "SRC-05", "--redact-pii").ok()
    assert a["id"] == b["id"] and source_ids(proj).count("SRC-05") == 1


def test_c025_redact_flag_on_clean_file_reports_zero(proj, tmp_path):
    out = ingest_file(proj, FIX / "source_market.md", "SRC-05", "--redact-pii").ok()
    assert out.get("pii_redacted", 0) == 0
    assert "[телефон скрыт]" not in snapshot_text(proj, "SRC-05")


# ---- ложные срабатывания ----

FALSE_POSITIVES = [
    "Отчёт от 2024-11-08, обновлён 12.03.2025.",
    "Выручка составила 1 234 567 890 рублей, ARPU 149,50.",
    "Когорта 2024-10: 1200 пользователей, удержание 72%, платёж 450 руб.",
    "2024-10,7,1200,0.72\n2024-11,8,1100,0.70",
    "Идентификатор 791234567055 (12 цифр) и 123456789012345.",
    "ИНН 7707083893, ОГРН 1027700132195.",
    "Номер заказа 9123456705 без кода страны.",
    "Упоминание @username без домена и e-mail как слово.",
    "Версия 7.0.912.345 и диапазон 8-912.",
    "Периоды 7.11.2026 08.11.2026 и 07/11/2026 08/11/2026 в отчёте.",
    "С 7.11.2026 08.11.2026 по график.",
]


@pytest.mark.parametrize("body", FALSE_POSITIVES)
def test_c025_no_false_positives(proj, tmp_path, body):
    r = ingest_file(proj, pii_file(tmp_path, body))
    out = r.ok()
    assert out.get("pii_redacted", 0) == 0
    assert "скрыт" not in snapshot_text(proj, "SRC-05")


def test_c025_digit_boundary_12_digits_inside_is_not_a_phone(proj, tmp_path):
    """Границы: перед и после номера нет цифры, поэтому 11 цифр внутри 12-цифрового числа не телефон."""
    ingest_file(proj, pii_file(tmp_path, "Код 789123456705 и 891234567051.")).ok()


def test_c025_phone_next_to_letters_and_punctuation_is_found(proj, tmp_path):
    for body in (f"тел:{PHONES[0]}.", f"({PHONES[4]})", f"контакт—{PHONES[6]};", f"\"{PHONES[3]}\""):
        ingest_file(proj, pii_file(tmp_path, body), "SRC-05").fail(1)


# ---- другие входы: csv, html, бинарные файлы, add-user-input ----

def test_c025_csv_with_phone_column(proj, tmp_path):
    f = tmp_path / "leads.csv"
    f.write_text("name,phone\nпользователь,+7 912 345-67-05\nдругой,89123456705\n", encoding="utf-8")
    r = ingest_file(proj, f)
    r.fail(1)
    assert raw_listing(proj) == []
    r = ingest_file(proj, f, "SRC-05", "--redact-pii")
    assert r.ok()["pii_redacted"] == 2
    assert leaks(proj.ws, [(PHONES[0], CORE), (PHONES[4], CORE)], [r.stdout, r.stderr]) == []


def _html_pii(tmp_path):
    f = tmp_path / "contacts.html"
    f.write_text(f"<html><head><title>Контакты</title></head><body><p>{article(300)}</p>"
                 f"<p>Звоните {PHONES[0]} или пишите {EMAIL}</p>"
                 f"<a href=\"tel:+79123456705\">позвонить</a></body></html>", encoding="utf-8")
    return f


def test_c025_ingest_url_pii_rejected_without_flag(proj, tmp_path):
    before = state_of_files(proj)
    r = proj.run("ingest-url", "--url", "https://e.example/c", "--id", "SRC-03", "--from-file", _html_pii(tmp_path))
    e = r.fail(1)
    assert "--redact-pii" in e["hint"]
    assert state_of_files(proj) == before and raw_listing(proj) == []
    assert leaks(proj.ws, [(EMAIL, None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []


def test_c025_ingest_url_redact_cleans_html_copy_and_snapshot(proj, tmp_path):
    r = proj.run("ingest-url", "--url", "https://e.example/c", "--id", "SRC-03", "--from-file", _html_pii(tmp_path),
                 "--redact-pii")
    out = r.ok()
    assert out["pii_redacted"] >= 2
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-03")
    assert src["raw_copy"] is True  # C-029 п.6: значение и в тексте, и в разметке
    htmls = list((proj.pdir / "raw_materials").rglob("*.html"))
    assert len(htmls) == 1
    body = htmls[0].read_text(encoding="utf-8")
    assert "<pre>" in body and "[телефон скрыт]" in body and "tel:" not in body
    # весь workspace, включая атрибут href="tel:..." в сохранённом HTML
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []


def test_c025_pii_hidden_in_script_or_comment_passes_without_html_copy(proj, tmp_path):
    """C-029 п.1: отказ только по очищенному тексту; совпадение в сыром HTML: копия не сохраняется."""
    f = tmp_path / "hidden.html"
    f.write_text(f"<html><body><p>{article(400)}</p><script>var p='{PHONES[0]}';</script>"
                 f"<!-- {EMAIL} --></body></html>", encoding="utf-8")
    r = proj.run("ingest-url", "--url", "https://e.example/h", "--id", "SRC-03", "--from-file", f)
    r.ok()
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-03")
    assert src["raw_copy"] is False
    assert not list((proj.pdir / "raw_materials").rglob("*.html"))
    assert leaks(proj.ws, [(EMAIL, None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []


def _docx(tmp_path):
    import docx
    d = docx.Document()
    d.add_paragraph("Рынок платных подписок вырос на 14 процентов за год.")
    d.add_paragraph(f"Контакт: {PHONES[0]}, {EMAIL}")
    p = tmp_path / "contacts.docx"
    d.save(str(p))
    return p


def _xlsx(tmp_path):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["имя", "телефон"])
    ws.append(["лид", PHONES[0]])
    ws.append(["почта", EMAIL])
    p = tmp_path / "leads.xlsx"
    wb.save(str(p))
    return p


@pytest.mark.parametrize("maker", [_docx, _xlsx], ids=["docx", "xlsx"])
def test_c025_binary_with_pii_rejected_without_flag(proj, tmp_path, maker):
    f = maker(tmp_path)
    before = state_of_files(proj)
    r = ingest_file(proj, f)
    r.fail(1)
    assert state_of_files(proj) == before and raw_listing(proj) == []
    assert leaks(proj.ws, [(EMAIL, None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []


@pytest.mark.parametrize("maker,ext", [(_docx, ".docx"), (_xlsx, ".xlsx")], ids=["docx", "xlsx"])
def test_c025_binary_redact_keeps_no_copy_of_original(proj, tmp_path, maker, ext):
    f = maker(tmp_path)
    r = ingest_file(proj, f, "SRC-05", "--redact-pii")
    out = r.ok()
    assert out["pii_redacted"] >= 2
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-05")
    assert src["raw_copy"] is False
    assert not [p for p in (proj.pdir / "raw_materials").rglob("*") if p.is_file() and p.suffix.lower() == ext]
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []
    t = snapshot_text(proj, "SRC-05")
    assert "[телефон скрыт]" in t and "[почта скрыта]" in t


def test_c025_pdf_with_pii_redact_has_no_copy(proj, tmp_path):
    from reportlab.pdfgen import canvas
    p = tmp_path / "c.pdf"
    c = canvas.Canvas(str(p))
    c.drawString(72, 720, "Contact phone +7 912 345-67-05 and mail " + EMAIL)
    c.drawString(72, 700, "Subscription market grew by fourteen percent over the year")
    c.save()
    ingest_file(proj, p).fail(1)
    assert raw_listing(proj) == []
    r = ingest_file(proj, p, "SRC-05", "--redact-pii")
    r.ok()
    src = next(s for s in proj.read("sources.json")["sources"] if s["id"] == "SRC-05")
    assert src["raw_copy"] is False and not [x for x in raw_listing(proj) if x.endswith(".pdf")]
    assert "SRC-05.txt" in raw_listing(proj)
    assert leaks(proj.ws, [(EMAIL, None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []


def test_c025_add_user_input_rejects_and_redacts(proj):
    text = f"Клиент сказал: звоните {PHONES[0]}, почта {EMAIL}; цена 450 рублей."
    before = state_of_files(proj)
    r = proj.run("add-user-input", "--id", "SRC-05", "--text", text)
    e = r.fail(1)
    assert "--redact-pii" in e["hint"]
    assert state_of_files(proj) == before and not (proj.pdir / "raw_materials" / "user_inputs.md").exists()
    assert leaks(proj.ws, [(EMAIL, None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []
    r = proj.run("add-user-input", "--id", "SRC-05", "--text", text, "--redact-pii")
    assert r.ok()["pii_redacted"] == 2
    assert (proj.pdir / "raw_materials" / "user_inputs.md").is_file()
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None), (PHONES[0], CORE)], [r.stdout, r.stderr]) == []


def test_c025_user_input_second_entry_does_not_resurrect_first(proj):
    proj.run("add-user-input", "--id", "SRC-05", "--text", f"тел {PHONES[1]}", "--redact-pii").ok()
    proj.run("add-user-input", "--id", "SRC-06", "--text", "Просто текст про рынок и цены.").ok()
    assert leaks(proj.ws, [(PHONES[1], CORE)]) == []


# ---- цитаты по очищенному слепку ----

def test_c025_quote_is_checked_against_redacted_snapshot(proj, tmp_path):
    f = pii_file(tmp_path, f"Для заказа звоните {PHONES[0]} в рабочие часы.")
    ingest_file(proj, f, "SRC-05", "--redact-pii").ok()
    ok = proj.run("register-claim", "--type", "FACT", "--origin", "PRIMARY_SOURCE", "--source", "SRC-05",
                  "--quote", "Для заказа звоните [телефон скрыт] в рабочие часы", "--text", "Есть телефон заказа")
    ok.ok()
    bad = proj.run("register-claim", "--type", "FACT", "--origin", "PRIMARY_SOURCE", "--source", "SRC-05",
                   "--quote", f"Для заказа звоните {PHONES[0]} в рабочие часы", "--text", "Полный номер")
    bad.fail(1)
    assert PHONES[0] not in json.dumps(proj.read("evidence_db.json"), ensure_ascii=False)


def test_c025_verify_quotes_ok_after_redaction(proj, tmp_path):
    f = pii_file(tmp_path, f"Для заказа звоните {PHONES[0]} в рабочие часы.")
    ingest_file(proj, f, "SRC-05", "--redact-pii").ok()
    proj.run("register-claim", "--type", "FACT", "--origin", "PRIMARY_SOURCE", "--source", "SRC-05",
             "--quote", "Рынок платных подписок вырос на 14 процентов", "--text", "Рост").ok()
    proj.run("verify-quotes").ok()


# ============================== C-026 [ОТОЗВАНО] ==============================

Q2 = "Средний платёж пользователя составляет 450 рублей"


@pytest.fixture
def rc(proj_src):
    """CLM-001 FACT, CLM-002 HYPOTHESIS, CLM-003 FACT."""
    c = proj_src
    assert c.claim(text="Рынок вырос").ok()["id"] == "CLM-001"
    assert c.claim(typ="HYPOTHESIS", origin="AGENT_INFERENCE", source=None, quote=None, text="Вырастет").ok()["id"] == "CLM-002"
    assert c.claim(text="Платёж", quote=Q2).ok()["id"] == "CLM-003"
    return c


def _revoke(c, cid="CLM-001"):
    c.run("revoke-claim", "--id", cid, "--reason", "устарело").ok()


def test_c026_revoked_ref_with_label_passes_and_is_not_a_fact_line(rc):
    deliverable(rc, "- [ОТОЗВАНО] Рынок вырос на 14% (CLM-001)\n")
    _revoke(rc)
    out = rc.run("verify-run").ok()
    s = out["summary"]
    assert s["fact_lines_total"] == 0 and s["fact_lines_verified"] == 0 and s["fact_lines_demo_data"] == 0


def test_c026_label_with_fact_tag_on_same_line_is_not_counted(rc):
    deliverable(rc, "- [ОТОЗВАНО] [FACT] Рынок вырос на 14% (CLM-001)\n- [FACT] Платёж (CLM-003)\n")
    _revoke(rc)
    s = rc.run("verify-run").ok()["summary"]
    assert s["fact_lines_total"] == 1 and s["fact_lines_verified"] == 1 and s["verified_share"] == 1


def test_c026_without_label_is_violation_as_before(rc):
    deliverable(rc, "- Рынок вырос на 14% (CLM-001)\n")
    _revoke(rc)
    vs = violations(rc.run("verify-run"))
    assert any("CLM-001" in v["detail"] and v["check"] == "deliverables" for v in vs)


def test_c026_fact_line_with_revoked_ref_without_label_is_violation(rc):
    deliverable(rc, "- [FACT] Рынок вырос на 14% (CLM-001)\n")
    _revoke(rc)
    violations(rc.run("verify-run"))


@pytest.mark.parametrize("label", ["[отозвано]", "[Отозвано]", "[ОТОЗВАНО ]", "[ ОТОЗВАНО ]", "[ОТО​ЗВАНО]",
                                   "［ОТОЗВАНО］", "[ОТОЗВАНО]".replace("[", "[ ")])
def test_c026_label_variants_normalized_like_other_labels(rc, label):
    deliverable(rc, f"- {label} Рынок вырос на 14% (CLM-001)\n")
    _revoke(rc)
    rc.run("verify-run").ok()


def test_c026_label_in_another_unit_does_not_excuse(rc):
    deliverable(rc, "- [ОТОЗВАНО] Рынок вырос (CLM-001)\n\n- А здесь снова ссылка (CLM-001)\n")
    _revoke(rc)
    vs = violations(rc.run("verify-run"))
    assert len(vs) == 1 and vs[0]["where"].endswith(":3"), vs


def test_c026_label_in_html_comment_is_invisible_and_does_not_excuse(rc):
    deliverable(rc, "- <!-- [ОТОЗВАНО] --> Рынок вырос (CLM-001)\n")
    _revoke(rc)
    violations(rc.run("verify-run"))


def test_c026_label_does_not_excuse_nonexistent_claim(rc):
    deliverable(rc, "- [ОТОЗВАНО] Выдуманное (CLM-777)\n")
    vs = violations(rc.run("verify-run"))
    assert any("CLM-777" in v["detail"] for v in vs)


def test_c026_label_does_not_excuse_other_defects_in_unit_unknown_footnote(rc):
    deliverable(rc, "- [ОТОЗВАНО] Рынок вырос (CLM-001)[^SRC-99]\n")
    _revoke(rc)
    vs = violations(rc.run("verify-run"))
    assert any("SRC-99" in v["detail"] for v in vs)


def test_c026_label_on_table_row_and_multiline_item(rc):
    deliverable(rc, "| [ОТОЗВАНО] | Рынок вырос (CLM-001) |\n\n- [ОТОЗВАНО] Прежний вывод\n  продолжение (CLM-001)\n")
    _revoke(rc)
    s = rc.run("verify-run").ok()["summary"]
    assert s["fact_lines_total"] == 0


def test_c029_p5_label_without_revoked_ref_gets_ordinary_rules_fact_without_clm(rc):
    deliverable(rc, "- [ОТОЗВАНО] [FACT] Выдуманная выручка 1 млрд\n")
    vs = violations(rc.run("verify-run"))
    assert any("[FACT] без ссылки" in v["detail"] for v in vs)


def test_c029_p5_label_with_active_ref_is_counted_as_ordinary_fact(rc):
    deliverable(rc, "- [ОТОЗВАНО] [FACT] Рынок (CLM-001)\n")
    s = rc.run("verify-run").ok()["summary"]
    assert s["fact_lines_total"] == 1 and s["fact_lines_verified"] == 1


def test_c029_p5_label_with_hypothesis_ref_still_hypothesis_as_fact(rc):
    deliverable(rc, "- [ОТОЗВАНО] [FACT] Вырастет (CLM-002)\n")
    assert any("гипотеза выдана за факт" in v["detail"] for v in violations(rc.run("verify-run")))


def test_c029_p5_label_without_any_ref_and_without_fact_is_harmless(rc):
    deliverable(rc, "- [ОТОЗВАНО] Прежний вывод снят\n")
    assert rc.run("verify-run").ok()["summary"]["fact_lines_total"] == 0


# ============================== C-027 приёмка стратегии ==============================

H3 = {
    "Продуктовая стратегия": ["Аудитория и её задача", "Альтернативы", "Выбранное направление", "Осознанные отказы",
                              "Польза, затраты и доходы"],
    "Коммуникационная стратегия": ["Аудитория и ситуация", "Барьер понимания или выбора",
                                   "Ключевое сообщение и его подтверждение", "Роль каналов",
                                   "Обещания соответствуют продукту"],
    "План проверки": ["Ожидаемое изменение", "С чем сравниваем", "Срок наблюдения", "Нежелательные последствия",
                      "Kill-criteria"],
}


def _strategy_md():
    out = []
    for h2, hs in H3.items():
        out.append(f"## {h2}\n")
        for h in hs:
            out.append(f"### {h}\n- [HYPOTHESIS] Содержательный текст раздела {h} (CLM-002)\n")
    return "\n".join(out)


def _to_stage5(c):
    c.run("set-brief", "--question", "Q", "--goal", "G", "--recipient", "R", "--audience", "A",
          "--constraints", "C", "--data", "D").ok()
    c.run("log-cost", "--stage", 1, "--tokens-in", 10, "--tokens-out", 5, "--source", "ide_estimated").ok()
    c.claim().ok()
    c.claim(typ="HYPOTHESIS", origin="AGENT_INFERENCE", source=None, quote=None, text="Вырастет").ok()
    c.confirm_brief()  # C-044
    for st in (1, 2):
        c.run("validate-step", "--stage", st).ok()
    c.run("add-question", "--text", "Вопрос", "--why", "меняет решение").ok()
    c.run("add-gap", "--text", "Пробел", "--why", "почему").ok()
    c.run("validate-step", "--stage", 3).ok()
    c.three_options(claims="CLM-001")
    c.choose_option()  # C-044
    c.run("validate-step", "--stage", 4).ok()
    deliverable(c, _strategy_md(), "04_product_and_comm_strategy.md")


def test_c027_stage5_not_closed_without_strategy_decision(proj_src):
    _to_stage5(proj_src)
    e = proj_src.run("validate-step", "--stage", 5).fail(1)
    assert "не принята" in _all(e)
    st = proj_src.read("state.json")
    assert st["stage_status"].get("5") != "done" and st["stage"] != 6
    assert 5 not in proj_src.run("status").ok()["done"]


@pytest.mark.parametrize("kind", ["brief", "option", "other"])
def test_c027_other_decision_kinds_do_not_replace_strategy(proj_src, kind):
    _to_stage5(proj_src)
    extra = ("--option", "OPT-01", "--owner", "О", "--metric", "М", "--review-if", "Если") if kind == "option" else ()
    proj_src.run("record-decision", "--id", "DEC-01", "--kind", kind, "--text", "решение", *extra).ok()
    proj_src.run("validate-step", "--stage", 5).fail(1)


def test_c027_strategy_decision_closes_stage5(proj_src):
    _to_stage5(proj_src)
    proj_src.run("validate-step", "--stage", 5).fail(1)
    proj_src.accept_strategy()
    assert proj_src.run("validate-step", "--stage", 5).ok()["ok"] is True
    st = proj_src.read("state.json")
    assert st["stage_status"]["5"] == "done" and st["stage"] == 6


def test_c027_decision_alone_without_document_does_not_close(proj_src):
    _to_stage5(proj_src)
    (proj_src.pdir / "deliverables" / "04_product_and_comm_strategy.md").unlink()
    proj_src.accept_strategy()
    proj_src.run("validate-step", "--stage", 5).fail(1)


def test_c027_verify_run_catches_closed_stage5_without_acceptance(proj_src):
    _to_stage5(proj_src)
    proj_src.accept_strategy()
    proj_src.run("validate-step", "--stage", 5).ok()
    proj_src.run("verify-run").ok()
    # человек (или агент в обход CLI) убрал решение и пересчитал хеш
    d = proj_src.read("decisions.json")
    d["decisions"] = [x for x in d["decisions"] if x["kind"] != "strategy"]
    proj_src.write("decisions.json", d)
    rehash(proj_src)
    vs = violations(proj_src.run("verify-run"))
    assert any(v["check"] == "stages" and "не принята" in v["detail"] for v in vs), vs


def test_c027_forged_stage_status_without_decision_is_caught_by_verify_run(proj_src):
    _to_stage5(proj_src)
    st = proj_src.read("state.json")
    st["stage_status"]["5"] = "done"
    st["stage"] = 6
    proj_src.write("state.json", st)
    rehash(proj_src)
    vs = violations(proj_src.run("verify-run"))
    assert any(v["check"] == "stages" and "не принята" in v["detail"] for v in vs), vs


def test_c027_verify_run_does_not_demand_acceptance_before_stage5_is_closed(proj_src):
    _to_stage5(proj_src)
    out = proj_src.run("verify-run").ok()
    assert out["checks"]["stages"] in ("ok", "skip")


# ============================== C-028 MCP ==============================

DRIVER = r'''
import json, os, subprocess, sys
mode = sys.argv[1]
if mode == "nospawn":
    def _boom(*a, **k):
        raise AssertionError("подпроцесс запущен")
    subprocess.run = subprocess.Popen = subprocess.call = subprocess.check_output = subprocess.check_call = _boom
    os.system = _boom
sys.path.insert(0, sys.argv[2])
from modules import mcp_adapter
cmd = sys.argv[3]
if cmd == "list":
    print(json.dumps(mcp_adapter.list_tools(), ensure_ascii=False))
else:
    print(json.dumps(mcp_adapter.call_tool(sys.argv[4], json.loads(sys.argv[5])), ensure_ascii=False))
'''


@pytest.fixture
def mcp(tmp_path):
    driver = tmp_path / "driver_dir" / "driver.py"
    driver.parent.mkdir()
    driver.write_text(DRIVER, encoding="utf-8")
    ws = tmp_path / "mcp_ws"

    class M:
        pass

    m = M()
    m.ws, m.tmp = ws, tmp_path

    def raw(mode, *args, env=None):
        return subprocess.run([sys.executable, "-I", str(driver), mode, str(TOOLS), *args], capture_output=True,
                              text=True, env=env, cwd=str(tmp_path), timeout=90)

    def run(mode, *args, env=None):
        import os
        e = {k: v for k, v in os.environ.items() if k != "STRATEGIST_PROJECT"}
        e["STRATEGIST_WORKSPACE"] = str(ws)
        e.update(NO_PROXY)
        e.update(env or {})
        cp = raw(mode, *args, env=e)
        assert cp.returncode == 0, f"адаптер упал (должен вернуть результат): {cp.stderr}"
        return json.loads(cp.stdout.strip().splitlines()[-1])

    m.raw_env = lambda: {**{k: v for k, v in __import__('os').environ.items() if k != 'STRATEGIST_PROJECT'}, 'STRATEGIST_WORKSPACE': str(ws), **NO_PROXY}
    m.raw = raw
    m.list = lambda: run("normal", "list")
    m.call = lambda name, args=None, mode="normal": run(mode, "call", name, json.dumps(args or {}, ensure_ascii=False))
    m.cli = Cli(ws, "proj")
    return m


def parser_commands():
    sys.path.insert(0, str(TOOLS))
    try:
        import importlib
        cli_mod = importlib.import_module("cli")
        p = cli_mod.build_parser()
        sub = next(a for a in p._actions if a.__class__.__name__ == "_SubParsersAction")
        return {name: sp for name, sp in sub.choices.items()}
    finally:
        sys.path.remove(str(TOOLS))


EXCLUDED = {"accept-edit", "build-rules", "parse-transcript", "redact-source"}  # C-046: обезличивание только у человека


def test_c028_list_tools_built_from_parser_without_service_commands(mcp):
    tools = mcp.list()
    names = {t["name"] for t in tools}
    expected = {n.replace("-", "_") for n in parser_commands() if n not in EXCLUDED}
    assert names == expected, (names ^ expected)
    for bad in ("accept_edit", "build_rules", "parse_transcript", "accept-edit", "build-rules", "parse-transcript",
                "redact_source", "redact-source"):
        assert bad not in names
    assert {"register_claim", "verify_run", "ingest_url", "init", "validate_step", "record_decision"} <= names


def test_c028_tool_shape_and_project_param(mcp):
    for t in mcp.list():
        assert {"name", "description", "parameters"} <= set(t), t
        assert isinstance(t["description"], str) and t["description"].strip(), t["name"]
        sch = t["parameters"]
        assert sch["type"] == "object" and isinstance(sch.get("properties"), dict)
        assert "project" in sch["properties"], t["name"]
        assert "project" not in sch.get("required", []), t["name"]
        assert "workspace" not in sch["properties"], f"{t['name']}: корень данных задаётся окружением, не вызовом"


def test_c028_parameters_follow_parser(mcp):
    tools = {t["name"]: t for t in mcp.list()}
    for cmd, sp in parser_commands().items():
        if cmd in EXCLUDED:
            continue
        sch = tools[cmd.replace("-", "_")]["parameters"]
        props, req = set(sch["properties"]), set(sch.get("required", []))
        assert not [k for k in props | req if "-" in k], (cmd, props)
        for act in sp._actions:
            flags = [o for o in act.option_strings if o.startswith("--")]
            if not flags or flags[0] in ("--help", "--workspace", "--project"):
                continue
            nm = flags[0][2:].replace("-", "_")
            assert nm in props, (cmd, nm)
            if act.required:
                assert nm in req, (cmd, nm)
            else:
                assert nm not in req, (cmd, nm)
    ty = lambda tool, p: tools[tool]["parameters"]["properties"][p]["type"]
    assert ty("validate_step", "stage") == "integer"
    assert ty("log_cost", "tokens_in") == "integer"
    assert ty("verify_run", "project") == "string"


def test_c028_call_tool_ok_result_shape_and_data_location(mcp):
    r = mcp.call("init", {"project": "proj", "name": "Тест", "question": "Стоит ли?"})
    assert r["ok"] is True and r["exit_code"] == 0 and isinstance(r["data"], dict), r
    assert (mcp.ws / "proj" / "state.json").is_file()
    assert not (REPO / "workspace" / "proj").exists()
    st = mcp.call("status", {"project": "proj"})
    assert st["ok"] is True and st["exit_code"] == 0 and "stage" in json.dumps(st["data"])


def test_c028_validation_error_is_a_result_exit_code_1(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    r = mcp.call("register_claim", {"project": "proj", "type": "FACT", "origin": "AGENT_INFERENCE", "text": "x"})
    assert r["ok"] is False and r["exit_code"] == 1
    assert r["error"].strip() and r.get("hint", "").strip()
    assert "Traceback" not in json.dumps(r)


def test_c028_manual_edit_is_exit_code_3_result(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    st = mcp.cli.read("state.json")
    st["stage"] = 4
    mcp.cli.write("state.json", st)
    r = mcp.call("verify_run", {"project": "proj"})
    assert r["ok"] is False and r["exit_code"] == 3, r
    assert r["error"].strip()


def test_c028_accept_edit_not_available_even_by_direct_call_and_does_not_spawn(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    st = mcp.cli.read("state.json")
    st["stage"] = 4
    mcp.cli.write("state.json", st)
    for name in ("accept_edit", "accept-edit", "build_rules", "parse_transcript"):
        r = mcp.call(name, {"project": "proj", "reason": "агент решил сам"}, mode="nospawn")
        assert r["ok"] is False and r["exit_code"] == 1 and r["error"].strip(), (name, r)
    assert mcp.call("verify_run", {"project": "proj"})["exit_code"] == 3, "защита хеша обойдена через MCP"


def test_c028_unknown_tool_and_param_do_not_spawn_subprocess(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    r = mcp.call("no_such_tool", {}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1
    r = mcp.call("status", {"project": "proj", "bogus": 1}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1 and "bogus" in json.dumps(r, ensure_ascii=False)
    r = mcp.call("status", {"project": "proj", "workspace": "/tmp/evil"}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1


def test_c028_trap_really_fires_on_a_real_call(mcp):
    """Контроль ловушки (OBJ-tripolsky-pm-024): существующий проект, настоящий вызов status в режиме nospawn
    обязан упасть на ловушке. Если адаптер перестанет запускать подпроцесс, status вернул бы ok:true из кэша,
    а тест выше ничего не доказывал бы."""
    mcp.call("init", {"project": "proj", "name": "Тест"})
    assert mcp.call("status", {"project": "proj"})["ok"] is True  # без ловушки вызов успешен
    cp = mcp.raw("nospawn", "call", "status", json.dumps({"project": "proj"}), env=mcp.raw_env())
    if cp.returncode == 0:
        res = json.loads(cp.stdout.strip().splitlines()[-1])
        assert res["ok"] is False, "ловушка не сработала: настоящий вызов обошёлся без подпроцесса"
    else:
        assert "подпроцесс запущен" in cp.stderr


def test_c028_verify_run_result_carries_violations_list(mcp):
    """OBJ-tripolsky-pm-025: нарушения приходят в результате инструмента структурно."""
    mcp.call("init", {"project": "proj", "name": "Тест"})
    (mcp.ws / "proj" / "deliverables" / "x.md").write_text("- [FACT] Выдумка без ссылки\n", encoding="utf-8")
    r = mcp.call("verify_run", {"project": "proj"})
    assert r["ok"] is False and r["exit_code"] == 1
    assert isinstance(r["violations"], list) and r["violations"]
    for v in r["violations"]:
        assert {"check", "where", "detail"} <= set(v), v
    assert any(v["check"] == "deliverables" for v in r["violations"])


def test_c028_missing_required_and_bad_type_are_results(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    r = mcp.call("register_claim", {"project": "proj", "type": "FACT"})
    assert r["ok"] is False and r["exit_code"] == 1
    r = mcp.call("validate_step", {"project": "proj", "stage": "abc"})
    assert r["ok"] is False and r["exit_code"] == 1


def test_c028_shell_metacharacters_are_data(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    c1, c2, c3 = (mcp.tmp / f"PWNED{i}" for i in (1, 2, 3))
    text = f"цена 450; rm -rf {mcp.tmp}/victim && touch {c1} $(touch {c2}) `touch {c3}` | cat > /dev/null"
    victim = mcp.tmp / "victim"
    victim.mkdir()
    (victim / "keep.txt").write_text("keep")
    r = mcp.call("add_user_input", {"project": "proj", "id": "SRC-01", "text": text})
    assert r["ok"] is True, r
    assert not c1.exists() and not c2.exists() and not c3.exists()
    assert (victim / "keep.txt").exists()
    assert text in (mcp.ws / "proj" / "raw_materials" / "user_inputs.md").read_text(encoding="utf-8")


@pytest.mark.parametrize("text", ["-5% выручки за квартал", "--help", "--project=evil", "-x"])
def test_c028_values_starting_with_dash_are_data_not_flags(mcp, text):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    r = mcp.call("add_user_input", {"project": "proj", "id": "SRC-01", "text": text})
    assert r["ok"] is True, r
    assert text in (mcp.ws / "proj" / "raw_materials" / "user_inputs.md").read_text(encoding="utf-8")
    assert not (mcp.ws / "evil").exists()


def test_c028_project_param_selects_project_and_default_is_current_project(mcp):
    assert mcp.call("init", {"project": "alpha", "name": "A"})["ok"] is True
    assert mcp.call("init", {"project": "beta", "name": "B"})["ok"] is True
    assert (mcp.ws / "alpha").is_dir() and (mcp.ws / "beta").is_dir()
    mcp.call("add_user_input", {"project": "beta", "id": "SRC-01", "text": "только в бете"})
    assert "только в бете" in (mcp.ws / "beta" / "raw_materials" / "user_inputs.md").read_text(encoding="utf-8")
    assert not (mcp.ws / "alpha" / "raw_materials" / "user_inputs.md").exists()
    assert mcp.call("init", {"name": "Без проекта"})["ok"] is True
    assert (mcp.ws / "current_project" / "state.json").is_file()


def test_c028_project_path_traversal_cannot_leave_workspace(mcp):
    r = mcp.call("init", {"project": "../escape", "name": "X"})
    assert not (mcp.ws.parent / "escape").exists() and not (mcp.tmp / "escape").exists()
    assert r["ok"] in (True, False)


def test_c028_ingest_pii_flag_passes_through(mcp):
    mcp.call("init", {"project": "proj", "name": "Тест"})
    r = mcp.call("add_user_input", {"project": "proj", "id": "SRC-01", "text": f"звоните {PHONES[0]}"})
    assert r["ok"] is False and r["exit_code"] == 1
    flag = [k for k in next(t for t in mcp.list() if t["name"] == "add_user_input")["parameters"]["properties"]
            if k == "redact_pii"]
    assert flag, "параметр redact_pii доступен через MCP"
    r = mcp.call("add_user_input", {"project": "proj", "id": "SRC-01", "text": f"звоните {PHONES[0]}", flag[0]: True})
    assert r["ok"] is True and r["data"]["pii_redacted"] == 1


def test_c028_adapter_does_not_import_fastmcp(tmp_path):
    fake = tmp_path / "fake"
    fake.mkdir()
    (fake / "fastmcp.py").write_text("raise ImportError('fastmcp запрещён в mcp_adapter')\n", encoding="utf-8")
    code = ("import sys; sys.path.insert(0, %r); from modules import mcp_adapter; "
            "assert 'fastmcp' not in sys.modules; print(len(mcp_adapter.list_tools()))") % str(TOOLS)
    cp = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=60,
                        env={"PYTHONPATH": str(fake), "PATH": "/usr/bin:/bin"})
    assert cp.returncode == 0, cp.stderr
    src = (TOOLS / "modules" / "mcp_adapter.py").read_text(encoding="utf-8")
    assert not re.search(r"^\s*(import|from)\s+fastmcp", src, re.M)


def test_c028_adapter_source_has_no_shell(mcp):
    src = (TOOLS / "modules" / "mcp_adapter.py").read_text(encoding="utf-8")
    assert "shell=True" not in src and "os.system" not in src


def test_c028_server_without_fastmcp_prints_install_hint(tmp_path):
    fake = tmp_path / "fake"
    fake.mkdir()
    (fake / "fastmcp.py").write_text("raise ImportError('нет fastmcp')\n", encoding="utf-8")
    cp = subprocess.run([sys.executable, str(TOOLS / "mcp_server.py")], capture_output=True, text=True, timeout=30,
                        env={"PYTHONPATH": str(fake), "PATH": "/usr/bin:/bin"}, stdin=subprocess.DEVNULL)
    assert cp.returncode != 0
    assert "pip install fastmcp" in cp.stderr + cp.stdout
    assert "Traceback" not in cp.stderr


def test_c028_example_config_exists_and_no_active_config():
    cfg = REPO / "config" / "mcp.example.json"
    assert cfg.is_file()
    data = json.loads(cfg.read_text(encoding="utf-8"))
    blob = json.dumps(data)
    assert "mcp_server.py" in blob and "mcpServers" in blob
    for secret in ("api_key", "token", "password", "sk-"):
        assert secret not in blob.lower()
    assert not (REPO / "config" / "mcp.json").exists() and not (REPO / ".mcp.json").exists()


def test_c028_real_stdio_client(tmp_path):
    fastmcp = pytest.importorskip("fastmcp")
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    ws = tmp_path / "ws"
    tr = StdioTransport(command=sys.executable, args=[str(TOOLS / "mcp_server.py")],
                        env={"STRATEGIST_WORKSPACE": str(ws), "PATH": "/usr/bin:/bin"})

    def payload(res):
        sc = getattr(res, "structured_content", None) or getattr(res, "data", None)
        if isinstance(sc, dict) and "ok" in sc:
            return sc
        return json.loads(res.content[0].text)

    async def go():
        async with Client(tr) as c:
            names = {t.name for t in await c.list_tools()}
            assert "register_claim" in names and "accept_edit" not in names
            ok = payload(await c.call_tool("init", {"project": "p", "name": "T"}))
            assert ok["ok"] is True and ok["exit_code"] == 0
            res = await c.call_tool("register_claim", {"project": "p", "type": "FACT", "origin": "AGENT_INFERENCE",
                                                      "text": "x"})
            assert not res.is_error, "ошибка проверки должна быть результатом, не исключением"
            bad = payload(res)
            assert bad["ok"] is False and bad["exit_code"] == 1

    asyncio.run(go())
    assert (ws / "p" / "state.json").is_file()


# ============================== C-030 ПДн в url/title, MCP: границы путей ==============================

def _long_page(tmp_path):
    return write_html(tmp_path, article(500), "long.html")


def test_c030_url_with_pii_rejected_and_redacted(proj, tmp_path):
    url = "https://e.example/u?mail=ivan.petrov@example.com&tel=89123456705"
    f = _long_page(tmp_path)
    before = state_of_files(proj)
    r = proj.run("ingest-url", "--url", url, "--id", "SRC-03", "--from-file", f)
    e = r.fail(1)
    assert "--redact-pii" in e["hint"] and state_of_files(proj) == before
    assert leaks(proj.ws, [("ivan.petrov", None), ("89123456705", CORE)], [r.stdout, r.stderr]) == []
    r = proj.run("ingest-url", "--url", url, "--id", "SRC-03", "--from-file", f, "--redact-pii")
    assert r.ok()["pii_redacted"] >= 2
    assert leaks(proj.ws, [("ivan.petrov", None), ("89123456705", CORE)], [r.stdout, r.stderr]) == []


def test_c030_title_with_pii_rejected_and_redacted_ingest_url(proj, tmp_path):
    f = _long_page(tmp_path)
    args = ("ingest-url", "--url", "https://e.example/t", "--id", "SRC-03", "--from-file", f,
            "--title", f"Контакт {PHONES[0]}")
    before = state_of_files(proj)
    r = proj.run(*args)
    r.fail(1)
    assert state_of_files(proj) == before
    assert leaks(proj.ws, [(PHONES[0], CORE)], [r.stdout, r.stderr]) == []
    r = proj.run(*args, "--redact-pii")
    r.ok()
    assert leaks(proj.ws, [(PHONES[0], CORE)], [r.stdout, r.stderr]) == []


def test_c030_title_with_pii_ingest_source(proj):
    args = ("ingest-source", "--file", FIX / "source_market.md", "--id", "SRC-01", "--title", f"Почта {EMAIL}")
    before = state_of_files(proj)
    r = proj.run(*args)
    r.fail(1)
    assert state_of_files(proj) == before
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None)], [r.stdout, r.stderr]) == []
    r = proj.run(*args, "--redact-pii")
    r.ok()
    assert leaks(proj.ws, [(EMAIL, None), ("ivan.petrov", None)], [r.stdout, r.stderr]) == []


def test_c030_many_emails_violations_capped_at_5(proj, tmp_path):
    """OBJ-debussy-backend-014: срез до 5 примеров виден только при числе находок больше 5."""
    body = "\n".join(f"user{i}@example.com" for i in range(9))
    r = ingest_file(proj, pii_file(tmp_path, body))
    e = r.fail(1)
    assert len(e["violations"]) == 5
    assert "9" in e["error"]
    assert leaks(proj.ws, [(f"user{i}@example.com", None) for i in range(9)], [r.stdout, r.stderr]) == []


def test_c030_many_phones_violations_capped_at_5(proj, tmp_path):
    body = "\n".join(f"Тел. 8 912 345 67 {i:02d}" for i in range(10, 18))
    e = ingest_file(proj, pii_file(tmp_path, body)).fail(1)
    assert len(e["violations"]) == 5


def test_c030_revoked_label_line_does_not_break_closed_stage5(proj_src):
    """OBJ-debussy-backend-013: закрытый этап 5 и verify-run терпят строку [ОТОЗВАНО] с отозванным CLM в документе 04."""
    c = proj_src
    _to_stage5(c)
    assert c.claim(text="Платёж", quote=Q2).ok()["id"] == "CLM-003"
    doc = c.pdir / "deliverables" / "04_product_and_comm_strategy.md"
    doc.write_text(doc.read_text(encoding="utf-8") + "\n- [ОТОЗВАНО] Прежний вывод про платёж (CLM-003)\n",
                   encoding="utf-8")
    c.run("revoke-claim", "--id", "CLM-003", "--reason", "устарело").ok()
    c.accept_strategy()
    c.run("validate-step", "--stage", 5).ok()
    c.run("verify-run").ok()
    # без метки та же ссылка запрещена
    doc.write_text(doc.read_text(encoding="utf-8").replace("[ОТОЗВАНО] ", ""), encoding="utf-8")
    violations(c.run("verify-run"))


# ---- MCP: границы путей ----

def test_c030_mcp_file_outside_root_denied_without_spawn(mcp):
    mcp.call("init", {"project": "proj", "name": "Т"})
    outside = mcp.tmp / "outside.md"
    outside.write_text("Секрет вне корня репозитория, который нельзя загружать.\n", encoding="utf-8")
    r = mcp.call("ingest_source", {"project": "proj", "file": str(outside), "id": "SRC-01"}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1 and r["error"].strip()
    r = mcp.call("ingest_source", {"project": "proj", "file": "../../../../etc/hosts", "id": "SRC-02"}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1
    r = mcp.call("ingest_url", {"project": "proj", "url": "https://e.example/x", "id": "SRC-03",
                                "from_file": str(outside)}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1
    assert source_ids(mcp.cli) == []


def test_c030_mcp_file_inside_repo_allowed(mcp):
    mcp.call("init", {"project": "proj", "name": "Т"})
    r = mcp.call("ingest_source", {"project": "proj", "file": str(FIX / "source_market.md"), "id": "SRC-01"})
    assert r["ok"] is True, r


def test_c030_mcp_allowed_dir_env_and_symlink_escape(mcp):
    mcp.call("init", {"project": "proj", "name": "Т"})
    allowed = mcp.tmp / "allowed"
    allowed.mkdir()
    good = allowed / "good.md"
    good.write_text("Рынок платных подписок вырос на 14 процентов за год.\n", encoding="utf-8")
    outside = mcp.tmp / "outside.md"
    outside.write_text("Вне разрешённой папки лежит этот материал для проверки.\n", encoding="utf-8")
    link = allowed / "link.md"
    link.symlink_to(outside)
    import os
    # без переменной файл из tmp запрещён
    r = mcp.call("ingest_source", {"project": "proj", "file": str(good), "id": "SRC-01"}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1
    old = os.environ.get("STRATEGIST_ALLOWED_DIR")
    os.environ["STRATEGIST_ALLOWED_DIR"] = str(allowed)
    try:
        r = mcp.call("ingest_source", {"project": "proj", "file": str(good), "id": "SRC-01"})
        assert r["ok"] is True, r
        r = mcp.call("ingest_source", {"project": "proj", "file": str(link), "id": "SRC-02"}, mode="nospawn")
        assert r["ok"] is False and r["exit_code"] == 1, "симлинк наружу должен быть запрещён"
        r = mcp.call("ingest_source", {"project": "proj", "file": str(outside), "id": "SRC-03"}, mode="nospawn")
        assert r["ok"] is False and r["exit_code"] == 1
    finally:
        if old is None:
            os.environ.pop("STRATEGIST_ALLOWED_DIR", None)
        else:
            os.environ["STRATEGIST_ALLOWED_DIR"] = old
    assert source_ids(mcp.cli) == ["SRC-01"]


def test_c030_mcp_symlink_inside_repo_pointing_outside_denied(mcp):
    """Симлинк на файл вне корня запрещён."""
    mcp.call("init", {"project": "proj", "name": "Т"})
    outside = mcp.tmp / "o2.md"
    outside.write_text("Материал за пределами корня, доступный только по ссылке.\n", encoding="utf-8")
    d = mcp.tmp / "root2"
    d.mkdir()
    (d / "l.md").symlink_to(outside)
    r = mcp.call("ingest_source", {"project": "proj", "file": str(d / "l.md"), "id": "SRC-01"}, mode="nospawn")
    assert r["ok"] is False and r["exit_code"] == 1


def test_c030_mcp_empty_project_is_error(mcp):
    for val in ("", "   "):
        r = mcp.call("init", {"project": val, "name": "Т"}, mode="nospawn")
        assert r["ok"] is False and r["exit_code"] == 1
    assert not (mcp.ws / "current_project").exists()


def test_c030_cli_keeps_unrestricted_file_paths(proj, tmp_path):
    """CLI эти ограничения не получает: файл указывает человек."""
    f = tmp_path / "x.md"
    f.write_text("Обычный материал человека лежит вне репозитория.\n", encoding="utf-8")
    proj.run("ingest-source", "--file", f, "--id", "SRC-01").ok()


def test_c030_p4_dates_not_phone_but_dotted_and_slashed_phones_still_are(proj, tmp_path):
    ok = ingest_file(proj, pii_file(tmp_path, "Сроки 7.11.2026 08.11.2026 и 07/11/2026 08/11/2026."), "SRC-05").ok()
    assert ok.get("pii_redacted", 0) == 0
    for i, ph in enumerate(("8.912.345.67.05", "8/912/345/67/05"), 6):
        ingest_file(proj, pii_file(tmp_path, f"Тел {ph}"), f"SRC-0{i}").fail(1)


# ============================== C-031 пометка решений при отзыве ==============================

def _c031_project(c):
    """CLM-001 FACT (корень), CLM-002 FACT (независимое), CLM-003 HYPOTHESIS depends_on CLM-001."""
    assert c.claim(text="Рынок вырос").ok()["id"] == "CLM-001"
    assert c.claim(text="Платёж", quote=Q2).ok()["id"] == "CLM-002"
    assert c.claim(typ="HYPOTHESIS", origin="AGENT_INFERENCE", source=None, quote=None, text="Вырастет",
                   extra=("--depends-on", "CLM-001")).ok()["id"] == "CLM-003"
    c.option("OPT-01", "keep_as_is", extra=("--claims", "CLM-002")).ok()
    c.option("OPT-02", "close_direction", extra=("--claims", "CLM-002")).ok()
    c.option("OPT-03", "custom", extra=("--claims", "CLM-003")).ok()  # опора транзитивная


def _dec(c, did, kind, option=None, claims=None):
    args = ["record-decision", "--id", did, "--kind", kind, "--text", f"Решение {did}"]
    if option:
        args += ["--option", option]
    if claims:
        args += ["--claims", claims]
    if kind == "option":
        args += ["--owner", "Владелец", "--metric", "Показатель", "--review-if", "Если упадёт"]
    return c.run(*args).ok()


@pytest.fixture
def c31(proj_src):
    c = proj_src
    _c031_project(c)
    _dec(c, "DEC-01", "option", "OPT-02", "CLM-001")   # прямая опора
    _dec(c, "DEC-02", "other", None, "CLM-003")        # транзитивная опора через depends_on
    # C-045: разные виды, иначе более позднее решение того же вида заменяет раннее и оно выпадает из «устаревших»
    _dec(c, "DEC-03", "strategy", "OPT-03", "CLM-002")  # через вариант с needs_revision
    _dec(c, "DEC-04", "brief", "OPT-01", "CLM-002")     # не затронуто
    return c


def _decisions(c):
    return {d["id"]: d for d in c.read("decisions.json")["decisions"]}


def test_c031_revoke_marks_decisions_directly_transitively_and_via_option(c31):
    r = c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    assert {"DEC-01", "DEC-02", "DEC-03"} <= set(r["affected"]) and "DEC-04" not in r["affected"], r
    d = _decisions(c31)
    for did in ("DEC-01", "DEC-02", "DEC-03"):
        assert d[did]["needs_revision"] is True, did
    assert not d["DEC-04"].get("needs_revision")
    assert d["DEC-01"]["stale_claims"] == ["CLM-001"]
    assert d["DEC-02"]["stale_claims"] and set(d["DEC-02"]["stale_claims"]) <= {"CLM-001", "CLM-003"}


def test_c031_unrelated_revoke_marks_no_decisions(c31):
    r = c31.run("revoke-claim", "--id", "CLM-002", "--reason", "устарело").ok()
    assert "DEC-02" not in r["affected"], "DEC-02 опирается только на CLM-001/CLM-003"
    # DEC-03/DEC-04 опираются на CLM-002 прямо, DEC-01 через вариант OPT-02
    assert {"DEC-01", "DEC-03", "DEC-04"} <= set(r["affected"])


def test_c031_status_and_resume_expose_stale_decisions(c31):
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    for cmd in ("status", "resume"):
        out = c31.run(cmd).ok()
        assert {"DEC-01", "DEC-02", "DEC-03"} <= set(out["needs_revision"]), (cmd, out["needs_revision"])
        assert "DEC-04" not in out["needs_revision"]
        stale = {x["id"]: x["stale_claims"] for x in out["stale_decisions"]}
        assert set(stale) >= {"DEC-01", "DEC-02", "DEC-03"} and "DEC-04" not in stale
        assert stale["DEC-01"] == ["CLM-001"]


def test_c031_handoff_names_stale_decisions(c31):
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    c31.run("resume").ok()
    text = (c31.pdir / "HANDOFF_CONTEXT.md").read_text(encoding="utf-8")
    section = text.split("## Требует пересмотра", 1)[1].split("\n## ", 1)[0]
    for did in ("DEC-01", "DEC-02", "DEC-03"):
        assert did in section
    assert "DEC-04" not in section


def test_c031_journal_is_not_rewritten(c31):
    before = _decisions(c31)
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    after = _decisions(c31)
    assert list(before) == list(after)
    for did, b in before.items():
        for k in ("id", "kind", "text", "option", "claims", "owner", "metric", "review_if", "created_at"):
            assert after[did][k] == b[k], (did, k)
    # повторное решение тем же ID с другим текстом по-прежнему запрещено
    c31.run("record-decision", "--id", "DEC-01", "--kind", "option", "--text", "подмена", "--option", "OPT-02",
            "--claims", "CLM-001", "--owner", "О", "--metric", "М", "--review-if", "Е").fail(1)


def _doc05(c):
    (c.pdir / "deliverables" / "05_decision_log.md").write_text("# 05. Журнал решений\n\nРешение DEC-01.\n",
                                                                encoding="utf-8")


def test_c031_stage6_and_verify_run_look_at_last_option_decision(c31):
    _doc05(c31)
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    e = c31.run("validate-step", "--stage", 6).fail(1)
    assert "отозванное основание" in _all(e) and "DEC-01" in _all(e)


def test_c031_verify_run_stages_catches_closed_stage6_after_revoke(c31):
    _doc05(c31)
    c31.run("validate-step", "--stage", 6).ok()
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    vs = violations(c31.run("verify-run"))
    assert any(v["check"] == "stages" and "опирается на отозванное основание" in v["detail"] for v in vs), vs


def test_c031_new_option_decision_clears_the_violation(c31):
    _doc05(c31)
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    c31.run("validate-step", "--stage", 6).fail(1)
    _dec(c31, "DEC-05", "option", "OPT-01", "CLM-002")
    # DEC-01 остаётся в журнале с пометкой, но последнее решение kind=option — чистое
    assert _decisions(c31)["DEC-01"]["needs_revision"] is True
    c31.run("validate-step", "--stage", 6).ok()
    vs = c31.run("verify-run")
    if vs.code != 0:
        assert not any("опирается на отозванное основание" in v["detail"] for v in violations(vs))


def test_c031_flagged_non_option_or_earlier_decision_is_not_a_violation(c31):
    """Нарушение даёт только последнее решение kind=option."""
    _dec(c31, "DEC-05", "option", "OPT-01", "CLM-002")   # последнее kind=option — чистое
    _doc05(c31)
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    c31.run("validate-step", "--stage", 6).ok()
    vs = c31.run("verify-run")
    if vs.code != 0:
        assert not any("опирается на отозванное основание" in v["detail"] for v in violations(vs))


# ---- ПДн в имени файла (C-031 п.4) ----

@pytest.mark.parametrize("fname", ["89123456705_отчёт.md", "ivan.petrov@example.com.md", "контакт +7 912 345-67-05.md"])
def test_c031_pii_in_file_name_rejected_and_redacted(proj, tmp_path, fname):
    f = tmp_path / fname
    f.write_text("Рынок платных подписок вырос на 14 процентов за год.\n", encoding="utf-8")
    needles = [("ivan.petrov", None), ("9123456705", CORE), ("345-67-05", None)]
    before = state_of_files(proj)
    r = proj.run("ingest-source", "--file", f, "--id", "SRC-05", "--title", "Т")
    e = r.fail(1)
    assert "--redact-pii" in e["hint"] and state_of_files(proj) == before
    assert leaks(proj.ws, needles, [r.stdout, r.stderr]) == []
    r = proj.run("ingest-source", "--file", f, "--id", "SRC-05", "--title", "Т", "--redact-pii")
    r.ok()
    src = next(x for x in proj.read("sources.json")["sources"] if x["id"] == "SRC-05")
    assert src.get("origin_path") and ("скрыт" in src["origin_path"])
    assert leaks(proj.ws, needles, [r.stdout, r.stderr]) == []


def test_c031_new_decision_on_already_revoked_claim_is_not_accepted_silently(c31):
    """OBJ-makelele-qa-018: record-decision с --claims на уже отозванное утверждение не даёт чистого решения."""
    _doc05(c31)
    c31.run("revoke-claim", "--id", "CLM-001", "--reason", "устарело").ok()
    r = c31.run("record-decision", "--id", "DEC-05", "--kind", "option", "--text", "опора на отозванное",
                "--option", "OPT-01", "--claims", "CLM-001", "--owner", "О", "--metric", "М", "--review-if", "Е")
    if r.code == 0:  # принято: тогда решение помечено и этап 6 не закрывается
        assert _decisions(c31)["DEC-05"].get("needs_revision") is True
        c31.run("validate-step", "--stage", 6).fail(1)
    else:
        r.fail(1)
