"""Запуск CLI с обрывом процесса (os._exit) перед N-й записью JSON-файла проекта. Только для тестов обрыва."""
import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "tools"))
stop, count = int(os.environ.get("CRASH_AT", "0")), {"n": 0}
after = os.environ.get("CRASH_AFTER", "")  # обрыв сразу после записи файла, имя которого оканчивается на это

from modules import common  # noqa: E402

orig = common.write_json


def write_json(path, data, *a, **k):
    count["n"] += 1
    if count["n"] == stop:
        os._exit(137)
    return orig(path, data, *a, **k)


import importlib  # noqa: E402
import pkgutil  # noqa: E402
import modules  # noqa: E402

orig_bytes = common.write_bytes


def write_bytes(path, data, *a, **k):
    r = orig_bytes(path, data, *a, **k)
    if after and str(path).endswith(after):
        os._exit(137)
    return r


common.write_json = write_json
common.write_bytes = write_bytes
for m in pkgutil.iter_modules(modules.__path__):
    mod = importlib.import_module(f"modules.{m.name}")
    if getattr(mod, "write_json", None) is orig:
        mod.write_json = write_json
    if getattr(mod, "write_bytes", None) is orig_bytes:
        mod.write_bytes = write_bytes

import cli  # noqa: E402

sys.exit(cli.main(sys.argv[1:]))
