"""Инжест источников (C-003): слепки в raw_materials/ в обёртке <untrusted_source>."""
import csv
import io
import re
from html import escape
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import pii
from .common import CliError, check_id, now_iso, sha256_bytes, sha256_text, split_list, write_bytes

TEXT_EXT = {".md", ".txt"}
TABLE_EXT = {".csv", ".xlsx"}
DOC_EXT = {".pdf", ".docx"}  # C-017
USER_INPUTS = "raw_materials/user_inputs.md"
DROP_TAGS = ["script", "style", "nav", "noscript", "template", "iframe", "svg"]
USER_AGENT = "Mozilla/5.0 (compatible; StrategistAgent/1.0)"  # C-023
STUB_MARKERS = ("checking your browser", "ddos-guard", "just a moment", "enable javascript and cookies",
                "access denied", "verify you are human", "captcha")  # C-024


def neutralize(text):
    """C-010 п.9: в слепке ровно одна открывающая и одна закрывающая обёртка."""
    text = re.sub(r"</untrusted_source\s*>", "&lt;/untrusted_source&gt;", text, flags=re.I)
    text = re.sub(r"</untrusted_source", "&lt;/untrusted_source", text, flags=re.I)
    return re.sub(r"<untrusted_source", "&lt;untrusted_source", text, flags=re.I)


def wrap(src_id, text):
    return f'<untrusted_source id="{src_id}">\n{neutralize(text).strip()}\n</untrusted_source>\n'


def is_synthetic(text):
    """C-021 п.1: первая непустая строка начинается с «# SYNTHETIC» — демо-данные.
    C-038 п.6: слепок xlsx начинается с «# Лист:», для него это первая непустая ячейка первого листа."""
    first = next((ln.strip() for ln in text.splitlines() if ln.strip()), "")
    if first.startswith("# Лист:"):
        try:
            rows = csv.reader(io.StringIO(text.split(first, 1)[1]))
            first = next((c.strip() for row in rows for c in row
                          if c.strip() and not re.fullmatch(r"Unnamed: \d+", c.strip())), "")
        except csv.Error:
            return False
    return first.startswith("# SYNTHETIC")


def check_field(value, redact_pii, retry):
    """C-038 п.7: ПДн в служебном поле (--reason) -> отказ или замена, как у текста источника."""
    phones, emails = pii.find(value or "")
    if (phones or emails) and not redact_pii:
        raise CliError(f"В --reason персональные данные: телефонов — {len(phones)}, адресов почты — {len(emails)}. Ничего не записано.",
                       f"Уберите их из --reason или повторите с автоматическим скрытием: {retry} --redact-pii",
                       violations=pii.masks(phones, emails))
    return pii.redact(value) if phones or emails else value


def get(proj, src_id):
    return next((s for s in proj.load("sources.json")["sources"] if s.get("id") == src_id), None)


def refuse_superseded(src):
    """C-038 п.2: только для новых записей, прежние записи на этом источнике законны."""
    if src and src.get("superseded_by"):
        raise CliError(f"Источник {src['id']} заменён на {src['superseded_by']}",
                       f"Укажите новый источник: --source {src['superseded_by']}")


def snapshot_text(proj, src):
    """Текст слепка без строк обёртки. Подмена файла слепка -> exit 3 (C-011 п.5)."""
    path = proj.path(src["text_path"])
    try:
        raw = path.read_bytes().decode("utf-8")  # C-039 п.1: те же байты, что записаны; read_text превратил бы \r\n в \n
    except (OSError, UnicodeDecodeError):
        raise CliError(f"Слепок источника {src['id']} не читается: {src['text_path']}",
                       "Загрузите источник заново под новым ID: python3 tools/cli.py ingest-source --file ... --id SRC-XX",
                       code=3)
    if src.get("text_sha256") and sha256_text(raw) != src["text_sha256"]:
        raise CliError(f"Слепок {src['text_path']} изменён после загрузки (SHA-256 не совпадает)",
                       "Загрузите источник заново под новым ID: python3 tools/cli.py ingest-source --file ... --id SRC-XX",
                       code=3)
    lines = raw.strip("\n").split("\n")
    return "\n".join(lines[1:-1])


def _decode(data):
    for enc in ("utf-8-sig", "cp1251"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    raise CliError("Не удалось прочитать файл как текст (ожидается UTF-8 или Windows-1251)",
                   "Сохраните файл в UTF-8 и повторите: python3 tools/cli.py ingest-source --file <путь> --id SRC-XX")


def _table_text(path, data, ext):
    if ext == ".csv":
        return _decode(data)
    import pandas as pd  # тяжёлый импорт только для таблиц
    try:
        sheets = pd.read_excel(path, sheet_name=None, dtype=object)
    except Exception:  # битый xlsx — ошибка ввода, не падение
        raise CliError(f"Не удалось прочитать таблицу {path.name}: файл повреждён или это не XLSX", "Пересохраните таблицу в Excel или как CSV и повторите: python3 tools/cli.py ingest-source --file <путь> --id SRC-XX")
    return "\n".join(f"# Лист: {name}\n{df.to_csv(index=False)}" for name, df in sheets.items())


def _doc_text(path, ext):
    """C-017: pdf постранично с «# Страница N», docx — абзацы и таблицы по порядку, ячейки через « | »."""
    hint_txt = f"python3 tools/cli.py ingest-source --file <файл.txt> --id SRC-XX (сохраните {path.name} как текст)"
    if ext == ".pdf":
        import logging
        from pypdf import PdfReader  # лениво: без pip install остальные команды работают
        logging.getLogger("pypdf").setLevel(logging.CRITICAL)  # stderr — только JSON-ошибка (C-000)
        try:
            pages = [(p.extract_text() or "").strip() for p in PdfReader(path).pages]
        except Exception:  # битый или зашифрованный PDF — ошибка ввода
            raise CliError(f"Не удалось прочитать {path.name}: файл повреждён, защищён паролем или это не PDF", hint_txt)
        if not any(pages):
            raise CliError("В PDF нет текстового слоя (похоже на скан)",
                           "Распознайте текст (OCR), сохраните как .txt и загрузите: " + hint_txt)
        return "\n\n".join(f"# Страница {i}\n{t}" for i, t in enumerate(pages, 1))
    import docx
    from docx.table import Table
    try:
        doc = docx.Document(str(path))
    except Exception:
        raise CliError(f"Не удалось прочитать {path.name}: файл повреждён или это не DOCX (старый .doc сохраните как .docx)", hint_txt)
    parts = []
    for block in doc.iter_inner_content():
        if isinstance(block, Table):
            parts += [" | ".join(cell.text.strip() for cell in row.cells) for row in block.rows]
        elif block.text.strip():
            parts.append(block.text.strip())
    if not parts:
        raise CliError(f"В {path.name} нет текста", hint_txt)
    return "\n".join(parts)


def _existing(proj, src_id, sha, what):
    src = get(proj, src_id)
    if src is None:
        return None
    if src.get("sha256") != sha:
        raise CliError(f"ID {src_id} уже занят другим источником ({what} отличается)",
                       "Выберите свободный ID: python3 tools/cli.py status")
    return src


def _out(src, text):
    out = {"id": src["id"], "kind": src["kind"], "text_path": src["text_path"], "synthetic": bool(src.get("synthetic")),
           "forced": bool(src.get("forced")), "pii_redacted": src.get("pii_redacted", 0)}
    return {**out, **names_report(src["id"], text, src.get("terms_redacted", 0))}


def names_report(src_id, text, redacted):
    """C-046 п.1–2: предупреждение о возможных именах (не отказ) и число замен --redact-terms.
    Номера строк — в файле слепка: первая строка файла — обёртка."""
    warnings = pii.find_names(text, first_line=2)
    out = {"name_warnings": warnings, "redacted_terms": redacted}
    if warnings:
        out["hint"] = (f"В {src_id} похоже на имена людей (строки {', '.join(str(w['line']) for w in warnings)}). "
                       f'Если это ПДн, обезличьте: python3 tools/cli.py redact-source --id {src_id} --terms "Имя1;;Имя2" '
                       '--reason "..." (или при загрузке --redact-terms "Имя1;;Имя2")')
    return out


def _terms(text, terms):
    return pii.redact_terms(text, split_list(terms, ";;")) if terms else (text, 0)


def _guard_pii(text, redact_pii, retry, extras=()):
    """C-025, C-029 п.1, C-030 п.1: вызывать до записи любых файлов; решают текст слепка и extras (адрес, --title).
    Отказ называет число и маски. -> (число находок, функция очистки строк источника)."""
    phones, emails = pii.find("\n".join([text, *extras]))  # перенос строки не разделитель: значения не склеятся
    found = len(phones) + len(emails)
    if found and not redact_pii:
        raise CliError(f"В материале персональные данные: телефонов — {len(phones)}, адресов почты — {len(emails)}. "
                       "Источник не создан.",
                       f"Обезличьте материал или повторите с автоматическим скрытием: {retry} --redact-pii",
                       violations=pii.masks(phones, emails))
    return found, pii.redact if found else (lambda s: s)


def _safe_url(url):
    """Адрес для sources.json и сообщений: с ПДн, в том числе в %-кодировке, отдаётся с заменой."""
    decoded = unquote(url)
    return pii.redact(decoded) if any(pii.find(decoded)) else url


def _is_stub(text):
    """C-024: страница проверки браузера или почти пустой ответ."""
    low = text.lower()
    return len(text) < 200 or (len(text) < 1000 and any(m in low for m in STUB_MARKERS))


def _plan(src, text, op, args, writes=()):
    """Все проверки пройдены, на диске ещё ничего нет: ingest-update (C-034) пишет источник и реестры одной транзакцией."""
    rel = f"raw_materials/{src['id']}.txt"
    snapshot = wrap(src["id"], text)
    src.update(text_path=rel, text_sha256=sha256_text(snapshot), retrieved_at=now_iso(), synthetic=is_synthetic(text))
    return {"new": True, "src": src, "text": neutralize(text).strip(), "op": op, "args": args,
            "writes": [*writes, (rel, snapshot.encode("utf-8"))]}


def _known(src):
    return {"new": False, "src": src}


def store(proj, plan):
    """Файлы и запись реестра без commit; уже загруженный источник не трогает."""
    if plan["new"]:
        for rel, data in plan["writes"]:
            write_bytes(proj.path(rel), data)
        data = proj.load("sources.json")
        data["sources"].append(plan["src"])
        proj.save("sources.json", data)


def plan_snapshot(proj, plan):
    return plan["text"] if plan["new"] else snapshot_text(proj, plan["src"])


def _ingest(proj, plan):
    store(proj, plan)
    if plan["new"]:
        proj.commit(plan["op"], plan["args"], plan["src"]["id"])
    return _out(plan["src"], plan_snapshot(proj, plan))


def ingest_source(proj, file, id, title=None, redact_pii=False, redact_terms=None):
    return _ingest(proj, plan_file(proj, file, id, title, redact_pii, redact_terms))


def ingest_url(proj, url, id, title=None, from_file=None, force=False, redact_pii=False, redact_terms=None):
    return _ingest(proj, plan_url(proj, url, id, title, from_file, force, redact_pii, redact_terms))


def add_user_input(proj, id, text, redact_pii=False, redact_terms=None):
    return _ingest(proj, plan_text(proj, id, text, redact_pii=redact_pii, redact_terms=redact_terms))


def plan_file(proj, file, id, title=None, redact_pii=False, redact_terms=None):
    check_id(id, "SRC")
    path = Path(file)
    if not path.is_file():
        raise CliError(f"Файл не найден: {file}", "Проверьте путь: python3 tools/cli.py ingest-source --file <путь> --id SRC-01")
    ext = path.suffix.lower()
    if ext not in TEXT_EXT | TABLE_EXT | DOC_EXT:
        raise CliError(f"Формат {ext or 'без расширения'} не поддерживается: нужны .md, .txt, .csv, .xlsx, .pdf, .docx",
                       "Сохраните как .md, .txt, .csv или .xlsx и повторите: python3 tools/cli.py ingest-source --file <путь> --id SRC-XX")
    data = path.read_bytes()
    sha = sha256_bytes(data)
    src = _existing(proj, id, sha, "содержимое файла")
    if src:
        return _known(src)
    text = _decode(data) if ext in TEXT_EXT else _doc_text(path, ext) if ext in DOC_EXT else _table_text(path, data, ext)
    name = title or path.stem
    found, clean = _guard_pii(text, redact_pii, f"python3 tools/cli.py ingest-source --file <путь> --id {id}", [title or "", path.name])  # C-031 п.4
    text, named = _terms(clean(text), redact_terms)  # C-046 п.2: до записи любых файлов
    dirty = found or named
    src = {"id": id, "kind": "file", "title": _terms(clean(name), redact_terms)[0], "origin_path": clean(path.name),
           "sha256": sha, "pii_redacted": found, "raw_copy": not (dirty and ext in DOC_EXT | {".xlsx"})}
    if named:
        src["terms_redacted"] = named
    writes = []
    if src["raw_copy"]:  # C-025: двоичный файл не очистить, поэтому при находках копии нет
        # C-010 п.8: копия SRC-XX.<ext>; у .txt это имя занято слепком, поэтому SRC-XX.orig.txt
        src["copy_path"] = f"raw_materials/{id}{'.orig' if ext == '.txt' else ''}{ext}"
        writes.append((src["copy_path"], text.encode("utf-8") if dirty else data))
    return _plan(src, text, "ingest-source", {"file": path.name, "id": id, "title": title, "sha256": sha}, writes)


def plan_url(proj, url, id, title=None, from_file=None, force=False, redact_pii=False, redact_terms=None):
    check_id(id, "SRC")
    shown = _safe_url(url)  # полный адрес нужен только для запроса
    if urlparse(url).scheme not in ("http", "https") or not urlparse(url).netloc:
        raise CliError(f"Неверный адрес «{shown}»: нужен http:// или https://",
                       'python3 tools/cli.py ingest-url --url "https://..." --id SRC-02')
    old = get(proj, id)
    if old and old.get("url") != shown:
        raise CliError(f"ID {id} уже занят другим источником", "Выберите свободный ID: python3 tools/cli.py status")
    if old and from_file is None:
        return _known(old)  # повтор без --from-file не ходит в сеть второй раз
    retry = f"python3 tools/cli.py ingest-url --url <адрес> --id {id}" + (" --from-file <page.html>" if from_file else "")
    extras = [unquote(url), title or ""]
    _guard_pii("", redact_pii, retry, extras)  # до запроса: ПДн из адреса не должны уходить в сеть без согласия
    html = _read_local(from_file, shown) if from_file else _fetch(url, id, shown)
    sha = sha256_bytes(html)
    src = _existing(proj, id, sha, "содержимое страницы")
    if src:
        return _known(src)
    from bs4 import BeautifulSoup
    # Сначала строгий UTF-8: автоопределение портит однообразную кириллицу, и слепок выходит кракозябрами
    soup = BeautifulSoup(html, "html.parser", from_encoding="utf-8" if _is_utf8(html) else None)
    markup = str(soup)  # до чистки: атрибуты, скрипты и комментарии в слепок не попадут, но есть в копии HTML
    for tag in soup(DROP_TAGS):
        tag.decompose()
    page_title = soup.title.get_text(strip=True) if soup.title else ""
    lines = (re.sub(r"\s+", " ", ln).strip() for ln in soup.get_text("\n").splitlines())
    text = "\n".join(ln for ln in lines if ln)
    if not force and _is_stub(text):
        raise CliError("Похоже на заглушку вместо страницы (проверка браузера или почти пустой ответ). Источник не создан.",
                       f'Сохраните страницу в браузере и выполните: python3 tools/cli.py ingest-url --url "{shown}" --id {id} '
                       "--from-file page.html; если это настоящая страница, добавьте --force")
    found, clean = _guard_pii(text, redact_pii, retry, extras)
    raw_copy = not pii.has_new_values(markup, text)  # C-029 п.1
    text, named = _terms(clean(text), redact_terms)
    dirty = found or named or _terms(markup, redact_terms)[1]  # термин в атрибутах тоже не оставляем в копии
    src = {"id": id, "kind": "url", "title": _terms(clean(title or page_title or shown), redact_terms)[0], "url": shown,
           "sha256": sha, "pii_redacted": found, "raw_copy": raw_copy}
    if named:
        src["terms_redacted"] = named
    writes = []
    if raw_copy:
        src["html_path"] = f"raw_materials/{id}.html"
        # При находках HTML заменяется очищенным текстом: регулярка по разметке пропустит значения, разорванные тегами
        writes.append((src["html_path"], f"<pre>{escape(text)}</pre>\n".encode("utf-8") if dirty else html))
    if force:
        src["forced"] = True
    return _plan(src, text, "ingest-url", {"url": url, "id": id, "title": title, "sha256": sha}, writes)


def _is_utf8(data):
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def _read_local(from_file, url=""):
    p = Path(from_file)
    if not p.is_file():
        raise CliError(f"Файл не найден: {from_file}", f'Проверьте путь: python3 tools/cli.py ingest-url --url "{url}" --id SRC-XX --from-file <page.html>')
    return p.read_bytes()


def _fetch(url, src_id, shown):
    import requests
    hint = (f'Сохраните страницу в браузере и выполните: python3 tools/cli.py ingest-url '
            f'--url "{shown}" --id {src_id} --from-file page.html')
    try:
        resp = requests.get(url, timeout=30, headers={"User-Agent": USER_AGENT})
    except requests.RequestException:
        raise CliError(f"Не удалось скачать страницу {shown}: нет ответа от сервера или нет сети", hint)
    if resp.status_code >= 400:
        raise CliError(f"Сервер ответил {resp.status_code} на запрос {shown}", hint)
    return resp.content


def plan_text(proj, id, text, title=None, redact_pii=False, redact_terms=None):
    check_id(id, "SRC")
    if not text.strip():
        raise CliError("Пустой ввод пользователя", 'python3 tools/cli.py add-user-input --id SRC-05 --text "..."')
    sha = sha256_text(text)
    src = _existing(proj, id, sha, "текст")
    if src:
        return _known(src)
    found, clean = _guard_pii(text, redact_pii, f'python3 tools/cli.py add-user-input --id {id} --text "..."', [title or ""])
    text, named = _terms(clean(text), redact_terms)
    path = proj.path(USER_INPUTS)
    prev = path.read_text(encoding="utf-8") if path.exists() else "# Ввод пользователя\n"
    src = {"id": id, "kind": "user_input", "title": _terms(clean(title), redact_terms)[0] if title else f"Ввод пользователя {id}",
           "origin_path": "user_inputs.md", "sha256": sha, "pii_redacted": found, "raw_copy": True}
    if named:
        src["terms_redacted"] = named
    writes = [(USER_INPUTS, f"{prev.rstrip()}\n\n## {id}\n\n{text.strip()}\n".encode("utf-8"))]
    return _plan(src, text, "add-user-input", {"id": id, "text": text}, writes)


def all_violations(proj):
    """C-015: каждый слепок совпадает с text_sha256 из sources.json; C-039 п.4: копия книги xlsx — с sha256."""
    out = []
    for src in proj.load("sources.json")["sources"]:
        copy = src.get("copy_path") or ""
        if copy.lower().endswith(".xlsx"):
            path = proj.path(copy)
            if not path.is_file() or sha256_bytes(path.read_bytes()) != src.get("sha256"):
                out.append(f"{src.get('id')}: копия книги {copy} изменена или удалена после загрузки (SHA-256 не совпадает)")
        try:
            if src.get("text_path") and is_synthetic(snapshot_text(proj, src)) != bool(src.get("synthetic")):
                out.append(f"{src.get('id')}: флаг synthetic не совпадает с пометкой «# SYNTHETIC» в слепке (C-021)")
        except CliError as e:
            out.append(f"{src.get('id')}: {e.error}")
    return out


def _section(text, src_id, fn):
    """Применить fn только к разделу «## SRC-XX» файла user_inputs.md: остальные источники не трогаем."""
    m = re.search(rf"(?m)^## {re.escape(src_id)}\n(.*?)(?=^## |\Z)", text, flags=re.S)
    if not m:
        return text, 0
    body, n = fn(m.group(1))
    return text[:m.start(1)] + body + text[m.end(1):], n


def redact_source(proj, id, terms, reason):
    """C-046 п.3: обезличить уже загруженный источник. Отказ, если термин есть в цитате утверждения: смысл фактов не меняется."""
    src = get(proj, id)
    if src is None:
        raise CliError(f"Источник {id} не найден", "Список источников: python3 tools/cli.py status")
    words = split_list(terms, ";;")
    retry = f'python3 tools/cli.py redact-source --id {id} --terms "Имя1;;Имя2" --reason "..."'
    if not words:
        raise CliError("Не задан ни один термин для скрытия", retry)
    if not reason.strip():
        raise CliError("Нужна причина обезличивания", retry)
    check_field(reason, False, retry)
    if pii.redact_terms(reason, words)[1]:
        raise CliError("Причина содержит скрываемый термин: термины не сохраняются нигде", retry)
    quoted = sorted(c.get("id") for c in proj.load("evidence_db.json")["claims"]
                    if (c.get("source_id") == id or id in (c.get("confirmed_by") or []))
                    and pii.redact_terms(c.get("verbatim_quote") or "", words)[1])
    if quoted:
        raise CliError(f"Термин встречается в цитате утверждений {', '.join(quoted)} по {id}: обезличивание изменило бы факт. "
                       "Ничего не изменено.", "Уберите этот термин из --terms; если утверждение больше не нужно, "
                       "отзовите его (revoke-claim) и зарегистрируйте заново с цитатой без имени")
    files = [src.get(k) for k in ("text_path", "html_path", "copy_path")] + ([USER_INPUTS] if src.get("kind") == "user_input" else [])
    linked = [rel for rel in files if rel and proj.path(rel).is_symlink()]
    if linked:  # запись по ссылке ушла бы за папку проекта
        raise CliError(f"Файл источника — символическая ссылка: {', '.join(linked)}. Ничего не изменено.",
                       "Верните настоящий файл слепка или загрузите источник заново под новым ID", code=3)
    snapshot = snapshot_text(proj, src)  # подменённый слепок -> exit 3 до записи
    clean, total = pii.redact_terms(snapshot, words)
    snap_n = total
    if is_synthetic(clean) != bool(src.get("synthetic")):
        raise CliError("Замена изменила бы пометку «# SYNTHETIC» в слепке", "Уберите этот термин из --terms")
    redact = lambda t: pii.redact_terms(t, words)
    writes = [] if not total else [(src["text_path"], wrap(id, clean).encode("utf-8"))]
    for key in ("html_path", "copy_path"):
        rel = src.get(key)
        if not rel or not proj.path(rel).is_file():
            continue
        if Path(rel).suffix.lower() in DOC_EXT | {".xlsx"}:  # двоичную копию не очистить (как в C-025): удаляем
            if total:
                writes.append((rel, None))
            continue
        data, n = redact(proj.path(rel).read_bytes().decode("utf-8", errors="replace"))
        if n and key == "html_path":  # термин мог быть в атрибутах и скриптах: как при загрузке, копия — очищенный текст
            data = f"<pre>{escape(clean)}</pre>\n"
        if n:
            writes.append((rel, data.encode("utf-8")))
            total += n
    if src.get("kind") == "user_input" and proj.path(USER_INPUTS).is_file():
        data, n = _section(proj.path(USER_INPUTS).read_text(encoding="utf-8"), id, redact)
        if n:
            writes.append((USER_INPUTS, data.encode("utf-8")))
            total += n
    title, n_title = redact(src.get("title") or "")
    if not total and not n_title:
        return {"ok": True, "id": id, "redacted_terms": 0, "replaced_in_files": 0}  # повтор: всё уже обезличено
    for rel, data in writes:
        if data is None:
            proj.path(rel).unlink()
        else:
            write_bytes(proj.path(rel), data)
    db = proj.load("sources.json")
    rec = next(s for s in db["sources"] if s.get("id") == id)
    rec.update(title=title, terms_redacted=rec.get("terms_redacted", 0) + total + n_title)
    if clean != snapshot:
        rec["text_sha256"] = sha256_text(wrap(id, clean))
    for rel, data in writes:
        if data is None:
            rec["raw_copy"] = False
            rec.pop("copy_path" if rec.get("copy_path") == rel else "html_path", None)
    proj.save("sources.json", db)
    proj.commit("redact-source", {"id": id, "replaced": total + n_title, "reason": reason}, id,
                extra={"id": id, "replaced": total + n_title, "reason": reason})
    return {"ok": True, "id": id, "redacted_terms": snap_n, "replaced_in_files": total + n_title}
