"""C-040: чистая копия репозитория для жюри. Репозиторий разработки только читается.

Имена инфраструктуры команды собраны из частей: сам этот файл попадает в копию и проходит ту же проверку.
"""
import json
import re
import shutil
from pathlib import Path

from . import pii, rules_builder
from .common import REPO_ROOT, CliError, write_text

T = "te" + "am"
TEAM_AGENTS = ("tripolsky-pm", "debussy-backend", "makelele-qa", "vandamme-ux", "monet-deliverables")
WHITELIST = ("README.md", "CLAUDE.md", "AGENTS.md", "requirements.txt", "prompts_src", ".claude", ".cursor", "config",
             "knowledge_base", "skills", "tools", "tests", "demo", "docs/diagrams", "docs/report", "benchmarks")
SKIP_DIRS = {"workspace", "__pycache__", ".pytest_cache", ".ingest_update_backup", ".git"}
SKIP_FILES = {".DS_Store", ".lock", ".ingest_update_journal.json"}
TEAM_FILES = {f"tools/{T}"} | {f".claude/agents/{a}.md" for a in TEAM_AGENTS} | {f".claude/commands/{T}.md"}
FORBIDDEN = ("tools/" + T, "do" + "cs/" + T, "claude-" + "setup", "README_" + T.upper(), "ga" + "te.py",
             "CLAUDE_CODE_EXPERIMENTAL_AGENT_" + T.upper())
SLASH_CMD = re.compile(r"(?<![\w./-])/" + T + r"\b")
KEY = re.compile(r"sk-[A-Za-z0-9_-]{20,}|\b(?:api_key|token)=[\"']?[^\s\"'<>]", re.I)  # значение сразу после «=»
PII_FREE = ("tests/",)  # Литералы ПДн нужны атакам на детекторы; уточнение C-040 п.6 от 22.11.2026
HEX = re.compile(r"\b[0-9a-f]{32,}\b")  # SHA-256 в журналах состояния: цифры хеша не телефон
HINT = "python3 tools/package.py --out <пустая папка вне репозитория> [--zip]"


def _skip(rel):
    """-> причина исключения или None. rel — путь относительно корня репозитория (posix)."""
    parts = rel.split("/")
    name = parts[-1]
    if rel in TEAM_FILES:
        return "команда"
    if any(p in SKIP_DIRS for p in parts):
        return "служебное"
    if name in SKIP_FILES or name.endswith(".pyc"):
        return "служебное"
    if name.startswith(".env") and rel != "config/.env.example":
        return "секреты"
    if parts[0] == "demo" and "raw_materials" in parts and name.lower().endswith(".html"):
        return "копия страницы"
    return None


def _collect(root):
    """-> ([(rel, path)], [исключённые rel]). Симлинки не копируются: они могут вести за пределы репозитория."""
    files, excluded = [], []
    for top in WHITELIST:
        start = root / top
        if start.is_symlink():
            excluded.append(top)
            continue
        if start.is_file():
            files.append((top, start))
            continue
        if not start.is_dir():
            continue
        stack = [start]
        while stack:
            d = stack.pop()
            for p in sorted(d.iterdir()):
                rel = p.relative_to(root).as_posix()
                if p.is_symlink() or _skip(rel):
                    excluded.append(rel)
                elif p.is_dir():
                    stack.append(p)
                elif p.is_file():
                    files.append((rel, p))
    return sorted(files), sorted(excluded)


def _settings(text):
    """Без env команды и хуков TaskCompleted/TeammateIdle; остаются только хуки продукта (tools/cli.py)."""
    cfg = json.loads(text)
    env = {k: v for k, v in (cfg.get("env") or {}).items() if T.upper() not in k}
    cfg.pop("env", None)
    if env:
        cfg["env"] = env
    hooks = {}
    for event, groups in (cfg.get("hooks") or {}).items():
        kept = [{**g, "hooks": [h for h in g.get("hooks", []) if "tools/cli.py" in h.get("command", "")]} for g in groups]
        kept = [g for g in kept if g["hooks"]]
        if kept:
            hooks[event] = kept
    cfg.pop("hooks", None)
    if hooks:
        cfg["hooks"] = hooks
    return json.dumps(cfg, ensure_ascii=False, indent=2) + "\n"


def _claude_md(text):
    """Только сгенерированный блок правил продукта, вместе с маркерами: build-rules --check в копии сходится."""
    i, j = text.find(rules_builder.BEGIN), text.find(rules_builder.END)
    if i < 0 or j < i:
        raise CliError("В CLAUDE.md нет блока правил продукта между маркерами", "python3 tools/cli.py build-rules")
    return text[i:j + len(rules_builder.END)] + "\n"


def _violations(out):
    found = []
    for p in sorted(out.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(out).as_posix()
        try:
            text = p.read_bytes().decode("utf-8")
        except UnicodeDecodeError:
            continue  # двоичный файл (pdf, xlsx, шрифт)
        bad = [f for f in FORBIDDEN if f in text] + (["/" + T] if SLASH_CMD.search(text) else [])
        found += [f"{rel}: строка инфраструктуры команды «{b}»" for b in bad]
        if rel.startswith(PII_FREE):
            continue
        if rel != "config/.env.example" and KEY.search(text):
            found.append(f"{rel}: строка похожа на ключ доступа")
        phones, emails = pii.find(HEX.sub("#", text))
        if phones or emails:
            found.append(f"{rel}: персональные данные ({', '.join(pii.masks(phones, emails))})")
    return found


def build(out, zip_=False, root=None):
    root = Path(root or REPO_ROOT).resolve()
    out = Path(out).resolve()
    archive = Path(str(out) + ".zip")
    if out == root or out.is_relative_to(root):
        raise CliError(f"Папка копии {out} внутри репозитория: сборка изменила бы его", HINT)
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise CliError(f"Папка {out} не пуста: копия собирается только в пустую папку", HINT)
    if zip_ and archive.exists():
        raise CliError(f"Архив {archive} уже есть", "Удалите его или выберите другую --out")
    existed = out.exists()
    files, excluded = _collect(root)
    try:
        for rel, src in files:
            dst = out / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if rel == ".claude/settings.json":
                write_text(dst, _settings(src.read_text(encoding="utf-8")))
            elif rel == "CLAUDE.md":
                write_text(dst, _claude_md(src.read_text(encoding="utf-8")))
            else:
                shutil.copy2(src, dst)
        violations = _violations(out)
        try:
            rules_builder.build(check=True, root=out)
        except CliError as e:
            violations.append(f"build-rules --check в копии: {e.error}")
        if violations:
            raise CliError(f"Копия не прошла проверку: нарушений {len(violations)}. Копия удалена.",
                           "Уберите найденное из репозитория и повторите: " + HINT, violations=violations)
        if zip_:
            shutil.make_archive(str(out), "zip", root_dir=out.parent, base_dir=out.name)
    except BaseException:
        shutil.rmtree(out, ignore_errors=True)
        archive.unlink(missing_ok=True)
        if existed:
            out.mkdir()
        raise
    return {"ok": True, "out": str(out), "files": len(files), "excluded": excluded,
            "zip": str(archive) if zip_ else None}
