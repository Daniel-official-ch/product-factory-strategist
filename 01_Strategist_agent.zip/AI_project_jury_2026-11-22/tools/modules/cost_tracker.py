"""Учёт расхода (C-009 log-cost, C-011 п.7 parse-transcript). cost_ledger.json не входит в хеш."""
import json
from pathlib import Path

from .common import REPO_ROOT, CliError, now_iso

SOURCES = ("ide_exact", "ide_estimated", "api_exact")
PRICING = REPO_ROOT / "config" / "pricing.yaml"
H_COST = "python3 tools/cli.py log-cost --stage 1 --tokens-in 1000 --tokens-out 200 --source ide_estimated --note step-1"


def _prices():
    try:
        import yaml
        data = yaml.safe_load(PRICING.read_text(encoding="utf-8")) or {}
        return data.get("models") or {}
    except (OSError, ValueError, AttributeError):
        return {}


def usd(model, tokens_in, tokens_out, cache_read=0, cache_write=0, prices=None):
    """$ по config/pricing.yaml; ключ таблицы — подстрока ID модели, побеждает самый длинный. Нет цены -> None."""
    prices = _prices() if prices is None else prices
    keys = [k for k in prices if model and str(k) in model]
    if not keys:
        return None
    p = prices[max(keys, key=len)]
    total = (tokens_in * p.get("input", 0) + tokens_out * p.get("output", 0)
             + cache_read * p.get("cache_read", 0) + cache_write * p.get("cache_write", 0)) / 1_000_000
    return round(total, 6)


def _append(proj, entry):
    ledger = proj.load("cost_ledger.json")
    if entry.get("note") and any(e.get("stage") == entry["stage"] and e.get("note") == entry["note"]
                                 for e in ledger["entries"]):
        return False
    ledger["entries"].append(entry)
    proj.save("cost_ledger.json", ledger)
    return True


def log_cost(proj, stage, tokens_in, tokens_out, source, cache_read=0, model=None, note=None):
    if source not in SOURCES:
        raise CliError(f"Источник учёта «{source}» неизвестен, допустимо: {', '.join(SOURCES)}", H_COST)
    if stage not in range(1, 7) or min(tokens_in, tokens_out, cache_read or 0) < 0:
        raise CliError("Этап должен быть 1–6, токены — неотрицательные числа", H_COST)
    entry = {"stage": stage, "tokens_in": tokens_in, "tokens_out": tokens_out, "cache_read": cache_read or 0,
             "source": source, "model": model or "", "note": note or "", "ts": now_iso(),
             "usd": usd(model, tokens_in, tokens_out, cache_read or 0)}
    if _append(proj, entry):
        proj.commit("log-cost", {k: v for k, v in entry.items() if k != "ts"}, note or "cost")
    return {"stage": stage, "note": entry["note"], "usd": entry["usd"]}


def parse_transcript(proj, transcript, stage=None):
    """Суммирует usage сообщений ассистента после последнего учтённого uuid этой сессии."""
    path = Path(transcript)
    if not path.is_file():
        raise CliError(f"Транскрипт не найден: {transcript}", "python3 tools/cli.py parse-transcript --transcript <path.jsonl>")
    msgs, order, session, last_uuid = {}, [], "", ""
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(rec, dict):
            continue
        session = rec.get("sessionId") or session
        msg = rec.get("message") if isinstance(rec.get("message"), dict) else {}
        if rec.get("type") != "assistant" or not isinstance(msg.get("usage"), dict):
            continue
        key = msg.get("id") or rec.get("uuid")
        if key not in msgs:
            order.append(key)
        # одно сообщение пишется несколькими строками с тем же id; берём последнюю (итоговый usage)
        msgs[key] = (rec.get("uuid") or key, msg.get("model") or "", msg["usage"])
        last_uuid = rec.get("uuid") or last_uuid
    if not order:
        return {"entries": 0, "note": "", "tokens_in": 0, "tokens_out": 0}
    session = session or path.stem
    done = {e.get("last_uuid") for e in proj.load("cost_ledger.json")["entries"]
            if str(e.get("note", "")).startswith(session + ":")}
    start = 0
    for i, key in enumerate(order):  # продолжаем после последнего учтённого сообщения
        if msgs[key][0] in done:
            start = i + 1
    fresh = [msgs[k] for k in order[start:]]
    note = f"{session}:{last_uuid}"
    if not fresh:
        return {"entries": 0, "note": note, "tokens_in": 0, "tokens_out": 0}
    prices = _prices()
    tot = {"in": 0, "out": 0, "cr": 0, "cw": 0}
    models, total_usd = {}, 0.0
    for _, model, u in fresh:
        vals = [int(u.get(k) or 0) for k in ("input_tokens", "output_tokens", "cache_read_input_tokens",
                                               "cache_creation_input_tokens")]
        for k, v in zip(tot, vals):
            tot[k] += v
        models[model] = models.get(model, 0) + vals[1]
        total_usd += usd(model, *vals, prices=prices) or 0
    if stage is None:
        stage = proj.load("state.json").get("stage", 1)
    entry = {"stage": stage, "tokens_in": tot["in"], "tokens_out": tot["out"], "cache_read": tot["cr"],
             "cache_write": tot["cw"], "source": "ide_exact", "model": max(models, key=models.get),
             "note": note, "last_uuid": fresh[-1][0], "messages": len(fresh), "ts": now_iso(),
             "usd": round(total_usd, 6)}
    if _append(proj, entry):
        proj.commit("parse-transcript", {"note": note}, note)
    return {"entries": 1, "note": note, "tokens_in": tot["in"], "tokens_out": tot["out"], "usd": entry["usd"]}


def read_hook_input(stdin_text):
    """Хук Stop передаёт JSON с transcript_path на stdin."""
    try:
        data = json.loads(stdin_text or "{}")
    except json.JSONDecodeError:
        data = {}
    if not isinstance(data, dict) or not data.get("transcript_path"):
        raise CliError("Хук не передал transcript_path", "Хук Stop должен передавать JSON с transcript_path на stdin")
    return data["transcript_path"]


def summary(proj):
    zero = {"tokens_in": 0, "tokens_out": 0, "cache_read": 0, "usd": 0.0}
    total, by_stage = dict(zero), {}
    for e in proj.load("cost_ledger.json").get("entries", []):
        bucket = by_stage.setdefault(str(e.get("stage", "?")), dict(zero))
        for agg in (total, bucket):
            for k in ("tokens_in", "tokens_out", "cache_read"):
                agg[k] += int(e.get(k) or 0)
            agg["usd"] = round(agg["usd"] + float(e.get("usd") or 0), 6)
    return {"total": total, "by_stage": dict(sorted(by_stage.items()))}
