"""Общие примитивы: ошибка CLI, канонический JSON, атомарная запись, проверка ID."""
import hashlib
import json
import os
import re
import tempfile
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
LOCK_TIMEOUT = 30
UPDATE_JOURNAL = ".ingest_update_journal.json"  # C-038 п.1, C-039 п.2: отметка {key, base_hash} незавершённой ingest-update
UPDATE_BACKUP = ".ingest_update_backup"  # реестры до начала записи: откат сверяется с base_hash

try:
    import fcntl

    def _try_lock(f):
        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock(f):
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
except ImportError:  # Windows
    import msvcrt

    def _try_lock(f):
        f.seek(0)
        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)

    def _unlock(f):
        f.seek(0)
        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)


class CliError(Exception):
    """Ошибка для пользователя: exit `code`, JSON {"error", "hint", ...extra} в stderr."""

    def __init__(self, error, hint, code=1, **extra):
        super().__init__(error)
        self.error, self.hint, self.code, self.extra = error, hint, code, extra

    def payload(self):
        return {"error": self.error, "hint": self.hint, **self.extra}


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def canonical(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_text(text):
    return sha256_bytes(text.encode("utf-8"))


def write_bytes(path, data):
    """Атомарно: обрыв посреди записи не оставляет полуфайл."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".tmp_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def write_text(path, text):
    write_bytes(path, text.encode("utf-8"))


def write_json(path, data):
    write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def check_id(value, prefix):
    """ID идёт в имена файлов, поэтому только [A-Za-z0-9_-] — без путей и точек."""
    if not isinstance(value, str) or not re.fullmatch(rf"{prefix}-[A-Za-z0-9_-]+", value):
        raise CliError(f"Неверный ID «{value}»: нужен вид {prefix}-01 (латиница, цифры, «-», «_»)",
                       f"Повторите команду с ID вида {prefix}-01, например: python3 tools/cli.py status — список занятых ID")
    return value


def split_list(value, sep=","):
    """'A, B,,A' -> ['A', 'B']: без пустых и дублей, порядок сохраняется."""
    out = []
    for part in (value or "").split(sep):
        part = part.strip()
        if part and part not in out:
            out.append(part)
    return out


def normalize_ws(text):
    return re.sub(r"\s+", " ", text or "").strip()


@contextmanager
def project_lock(project_dir, timeout=LOCK_TIMEOUT):
    """C-015: эксклюзивная блокировка <project>/.lock на всё время команды; параллельные вызовы идут по очереди."""
    Path(project_dir).mkdir(parents=True, exist_ok=True)
    with open(Path(project_dir) / ".lock", "a+") as f:
        deadline = time.monotonic() + timeout
        while True:
            try:
                _try_lock(f)
                break
            except OSError:
                if time.monotonic() > deadline:
                    raise CliError(f"Проект занят другой командой дольше {timeout} с",
                                   "Повторите команду: python3 tools/cli.py <та же команда>")
                time.sleep(0.05)
        try:
            yield
        finally:
            _unlock(f)
