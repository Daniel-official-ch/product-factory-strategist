"""Решения человека (C-009): decisions.json входит в validation_hash."""
from .common import CliError, check_id, now_iso, split_list

KINDS = ("brief", "option", "strategy", "other")
CONTENT = ("kind", "text", "option", "claims", "owner", "metric", "review_if")


def _hint(proj):
    """Подсказка со свободным ID и существующим вариантом."""
    nums = [int(d["id"][4:]) for d in proj.load("decisions.json")["decisions"] if str(d.get("id", ""))[4:].isdigit()]
    opts = [o.get("id") for o in proj.load("options.json")["options"]]
    return (f"python3 tools/cli.py record-decision --id DEC-{max(nums, default=0) + 1:02d} --kind option "
            f'--option {opts[0] if opts else "OPT-XX"} --text "..."' + (f" (варианты: {', '.join(opts)})" if opts else ""))


def problems(proj, d):
    did = d.get("id") or "решение"
    out = []
    if d.get("kind") not in KINDS:
        out.append(f"{did}: вид «{d.get('kind')}» неизвестен, допустимо: {', '.join(KINDS)}")
    if not str(d.get("text") or "").strip():
        out.append(f"{did}: пустой --text")
    opts = {o.get("id") for o in proj.load("options.json")["options"]}
    if d.get("kind") == "option" and not d.get("option"):
        out.append(f"{did}: решение о выборе варианта требует --option OPT-XX")
    if d.get("option") and d["option"] not in opts:
        out.append(f"{did}: вариант {d['option']} не найден")
    claims = {c.get("id") for c in proj.load("evidence_db.json")["claims"]}
    out += [f"{did}: утверждение {c} не найдено" for c in d.get("claims") or [] if c not in claims]
    return out


def all_violations(proj):
    out = []
    for d in proj.load("decisions.json")["decisions"]:
        out += problems(proj, d)
    return out


def record_decision(proj, id, kind, text, option=None, claims=None, owner=None, metric=None, review_if=None):
    check_id(id, "DEC")
    new = {"id": id, "kind": kind, "text": text, "option": option or None, "claims": split_list(claims),
           "owner": owner or "", "metric": metric or "", "review_if": review_if or ""}
    probs = problems(proj, new)
    if probs:
        raise CliError(probs[0], _hint(proj), violations=probs)
    db = proj.load("decisions.json")
    old = next((d for d in db["decisions"] if d.get("id") == id), None)
    if old:
        if any(old.get(k) != new[k] for k in CONTENT):
            raise CliError(f"Решение {id} уже записано с другим содержимым; журнал решений не переписывается",
                           "Запишите новое решение под новым ID: " + _hint(proj))
        return {"id": id, "kind": kind}
    # C-031 п.5: только для новых записей; в problems нельзя — старое решение легально ссылается на отозванное позже
    by_id = {c.get("id"): c for c in proj.load("evidence_db.json")["claims"]}
    retired = [c for c in new["claims"] if by_id[c].get("status") != "active" or by_id[c].get("needs_revision")]  # C-036 п.1
    if retired:
        why = "отозванном основании" if any(by_id[c].get("status") != "active" for c in retired) else "основании, которое требует пересмотра"
        raise CliError(f"{id}: решение нельзя принять на {why}: {', '.join(retired)}",
                       "Укажите в --claims актуальные активные утверждения вместо устаревших: python3 tools/cli.py record-decision "
                       f"--id {id} --kind {kind} --text \"...\" --claims CLM-XX")
    db["decisions"].append({**new, "created_at": now_iso()})
    proj.save("decisions.json", db)
    state = proj.load("state.json")
    state["pending_human_decision"] = None  # C-013: любое решение человека снимает ожидание
    proj.commit("record-decision", new, id, state)
    return {"id": id, "kind": kind}


def mark_stale(db, revoked, dependents, options):
    """C-031 п.1: решения на отозванном основании или на затронутом варианте. Журнал не переписывается: только пометка.
    Меняет переданный реестр в памяти, запись на диск делает вызывающий."""
    hit = []
    for d in db["decisions"]:
        direct = set(d.get("claims") or []) & (set(dependents) | {revoked})
        if direct or d.get("option") in options:
            d["needs_revision"] = True
            d["stale_claims"] = sorted(set(d.get("stale_claims") or []) | direct | {revoked})
            hit.append(d["id"])
    return hit


def replaced_by(log):
    """C-045 п.1: {id заменённого решения: ID следующего решения того же kind}. Вычисляется, в файл не пишется."""
    out = {}
    for i, d in enumerate(log):
        later = next((x for x in log[i + 1:] if x.get("kind") == d.get("kind")), None)
        if later:
            out[d.get("id")] = later.get("id")
    return out


def current(log):
    """C-045 п.1: текущие решения — последние по порядку записи в каждом kind."""
    gone = replaced_by(log)
    return [d for d in log if d.get("id") not in gone]


def stale(proj):
    """C-045 п.2: основания проверяются только у текущих решений."""
    return [d for d in current(proj.load("decisions.json")["decisions"]) if d.get("needs_revision")]


def history(proj):
    """C-045 п.2: заменённые решения для status, с пометкой, чем заменены."""
    log = proj.load("decisions.json")["decisions"]
    gone = replaced_by(log)
    return [{"id": d.get("id"), "kind": d.get("kind"), "superseded_by": gone[d.get("id")],
             "needs_revision": bool(d.get("needs_revision"))} for d in log if d.get("id") in gone]


def human_problems(proj, kind):
    """C-044: этап 1 закрывает подтверждённый человеком бриф, этап 4 — выбранный человеком вариант."""
    log = proj.load("decisions.json")["decisions"]
    if kind == "brief":
        if any(d.get("kind") == "brief" for d in log):
            return []
        return ["Бриф не подтверждён человеком: после его ответа выполните python3 tools/cli.py record-decision "
                '--id DEC-01 --kind brief --text "Бриф подтверждён"']
    opts = {o.get("id") for o in proj.load("options.json")["options"]}
    if any(d.get("kind") == "option" and d.get("option") in opts for d in log):
        return []
    return ["Вариант не выбран человеком: покажите варианты, после выбора выполните " + _hint(proj)]


def stage6_problems(proj):
    out = []
    chosen = [d for d in proj.load("decisions.json")["decisions"] if d.get("kind") == "option"]
    if not chosen:
        out.append("Нет решения человека о выборе варианта (record-decision --kind option --option OPT-XX)")
    for d in chosen[-1:]:  # C-015 (OBJ-tripolsky-pm-016): у действующего выбора — ответственный, метрика, условие пересмотра
        if d.get("needs_revision"):  # C-031 п.3
            out.append(f"{d.get('id')}: решение опирается на отозванное основание "
                       f"({', '.join(d.get('stale_claims') or [])}); запишите новое решение с новым ID")
        for field, flag in (("owner", "--owner"), ("metric", "--metric"), ("review_if", "--review-if")):
            if not str(d.get(field) or "").strip():
                out.append(f"{d.get('id')}: у решения о варианте пусто поле {field} ({flag}); "
                           f"запишите новое решение с ним")
    if not proj.path("deliverables/05_decision_log.md").is_file():
        out.append("Нет файла deliverables/05_decision_log.md")
    return out
