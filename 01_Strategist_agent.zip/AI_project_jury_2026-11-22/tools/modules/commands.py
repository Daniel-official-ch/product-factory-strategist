"""Реестр команд: имя -> (функция, нужна ли сверка хеша). Общий вход для cli.py и будущего mcp_server.py."""
from . import (calculations, cost_tracker, decision_graph, decisions, evidence_registry, options, pdf_export,
               rules_builder, sources, state_manager, table_analysis, updates, verify_run)
from .common import project_lock
from .state_manager import Project

# (функция, проверять validation_hash перед работой). C-002: без проверки только init, status, accept-edit.
COMMANDS = {
    "init": (state_manager.init, False),
    "status": (state_manager.status, False),
    "accept-edit": (state_manager.accept_edit, False),
    "resume": (state_manager.resume, True),
    "set-brief": (state_manager.set_brief, True),
    "add-question": (state_manager.add_question, True),
    "add-gap": (state_manager.add_gap, True),
    "set-pending": (state_manager.set_pending, True),
    "clear-pending": (state_manager.clear_pending, True),
    "validate-step": (state_manager.validate_step, True),
    "ingest-source": (sources.ingest_source, True),
    "ingest-url": (sources.ingest_url, True),
    "add-user-input": (sources.add_user_input, True),
    "redact-source": (sources.redact_source, True),
    "register-calc": (calculations.register_calc, True),
    "register-claim": (evidence_registry.register_claim, True),
    "revoke-claim": (evidence_registry.revoke_claim, True),
    "verify-quotes": (evidence_registry.verify_quotes, True),
    "register-option": (options.register_option, True),
    "record-decision": (decisions.record_decision, True),
    "log-cost": (cost_tracker.log_cost, True),
    "parse-transcript": (cost_tracker.parse_transcript, True),
    "verify-run": (verify_run.verify_run, False),  # C-016: сверку хеша делает сама, чтобы отчитаться по check=integrity
    "analyze-table": (table_analysis.analyze_table, True),
    "impact": (decision_graph.impact, True),
    "ingest-update": (updates.ingest_update, False),  # C-038 п.1: после обрыва хеш законно не сходится, сверку делает сама
    "export-pdf": (pdf_export.export_pdf, False),  # C-043: читает только deliverables/*.md
}
READ_ONLY = {"status", "verify-run", "impact", "export-pdf"}  # не пишут реестров проекта и .active_project
UNLOCKED = {"status", "verify-run", "export-pdf"}  # impact сверяет хеш, поэтому под блокировкой: чужая запись не даст ложный exit 3


def execute(command, kwargs, workspace=None, project=None, hook=False):
    """project=None — флаг --project не передан. hook=True — вызов из хука Stop (проект по C-015)."""
    if command == "build-rules":  # C-010 п.3: --workspace и --project не используются
        return rules_builder.build(**kwargs)
    if command == "export-pdf" and (kwargs.get("md") or kwargs.get("out")):  # C-043 п.1: любой Markdown, проект не нужен
        return pdf_export.export_file(**kwargs)
    fn, check_hash = COMMANDS[command]
    name = project or (state_manager.hook_project(workspace) if hook else "current_project")
    proj = Project(workspace, name)
    if command != "init":
        proj.require()
    if command in UNLOCKED:
        result = fn(proj, **kwargs)
    else:
        with project_lock(proj.dir):  # C-015: сверка хеша -> изменение -> новый хеш под одной блокировкой
            if check_hash:
                proj.verify()
            result = fn(proj, **kwargs)
    if (project or command == "init") and command not in READ_ONLY and not kwargs.get("dry_run"):  # C-016 уточнение, C-034 п.7
        state_manager.set_active_project(workspace, name)
    return result
