"""Реестр утверждений (C-001, C-009, C-011 п.5): происхождение, цитаты, отзыв с пометкой зависимых."""
from . import calculations, decisions, sources
from .common import CliError, normalize_ws, now_iso, split_list

TYPES = ("FACT", "HYPOTHESIS", "FORECAST")
ORIGINS = ("PRIMARY_SOURCE", "USER_INPUT", "CALCULATION", "SYNTHETIC", "AGENT_INFERENCE")
NEEDS_SOURCE = {"PRIMARY_SOURCE", "USER_INPUT", "CALCULATION"}
NEEDS_QUOTE = {"PRIMARY_SOURCE", "USER_INPUT"}
MIN_QUOTE = 12
KEY = ("type", "origin_type", "source_id", "verbatim_quote", "calc_id", "text", "depends_on")
H_CLAIM = "python3 tools/cli.py register-claim --type ... --origin ... --source SRC-XX --quote \"...\" --text \"...\""


def _p(msg, hint=H_CLAIM, code=1):
    return (msg, hint, code)


def demo_data(proj, c):
    """C-021 п.2: утверждение опирается на синтетический источник напрямую или через CALC-XX."""
    calc = calculations.get(proj, c.get("calc_id")) if c.get("calc_id") else None
    sids = {c.get("source_id"), (calc or {}).get("source_id")} - {None}
    return any((sources.get(proj, sid) or {}).get("synthetic") for sid in sids)


def problems(proj, c, claims_by_id):
    """Все нарушения C-001 для одной записи: [(сообщение, hint, код)]. Пусто — запись валидна."""
    cid = c.get("id") or "новое утверждение"
    t, o = c.get("type"), c.get("origin_type")
    if t not in TYPES:
        return [_p(f"{cid}: тип «{t}» неизвестен, допустимо: {', '.join(TYPES)}")]
    if o not in ORIGINS:
        return [_p(f"{cid}: происхождение «{o}» неизвестно, допустимо: {', '.join(ORIGINS)}")]
    if t == "FACT" and o in ("SYNTHETIC", "AGENT_INFERENCE"):
        return [_p(f"{cid}: вывод агента или синтетические данные нельзя записать как FACT ({o})",
                   f"Запишите как гипотезу: python3 tools/cli.py register-claim --type HYPOTHESIS --origin {o} --text \"...\"")]
    if o == "SYNTHETIC" and t != "HYPOTHESIS":
        return [_p(f"{cid}: синтетические данные дают только гипотезу, не {t}", "python3 tools/cli.py register-claim --type HYPOTHESIS --origin SYNTHETIC --text \"...\"")]
    if not str(c.get("text") or "").strip():
        return [_p(f"{cid}: пустой --text")]
    out = []
    sid, quote = c.get("source_id"), c.get("verbatim_quote")
    src = sources.get(proj, sid) if sid else None
    if o in NEEDS_SOURCE and not sid:
        out.append(_p(f"{cid}: для {o} обязателен --source SRC-XX"))
    if sid and src is None:
        out.append(_p(f"{cid}: источник {sid} не найден",
                      f"Сначала загрузите его: python3 tools/cli.py ingest-source --file ... --id {sid}"))
    if o == "USER_INPUT" and src is not None and src.get("kind") != "user_input" \
            and src.get("origin_path") != "user_inputs.md":
        out.append(_p(f"{cid}: USER_INPUT должен ссылаться на ввод пользователя, а {sid} — {src.get('kind')}",
                      'python3 tools/cli.py add-user-input --id SRC-XX --text "..."'))
    if o in NEEDS_QUOTE and not quote:
        out.append(_p(f"{cid}: для {o} обязательна дословная цитата --quote"))
    if quote:
        out += quote_problems(proj, cid, quote, src, sid)
    if o == "CALCULATION":
        calc = calculations.get(proj, c.get("calc_id")) if c.get("calc_id") else None
        if calc is None:
            out.append(_p(f"{cid}: для CALCULATION нужен существующий расчёт --calc CALC-XX",
                          'python3 tools/cli.py register-calc --id CALC-01 --formula "a / b" --inputs \'{"a": 1, "b": 2}\' --source SRC-01'))
        else:
            out += [_p(f"{cid}: {m}", "Пересчитайте: python3 tools/cli.py register-calc с новым ID") for m in calculations.recheck(calc)]
            if sid and calc.get("source_id") and calc["source_id"] != sid:  # C-021 п.7: демо-флаг не «отмыть» сменой --source
                out.append(_p(f"{cid}: источник утверждения не совпадает с источником расчёта ({sid} ≠ {calc['source_id']})",
                              f"python3 tools/cli.py register-claim --origin CALCULATION --source {calc['source_id']} --calc {c.get('calc_id')} --text \"...\""))
    if bool(c.get("demo_data")) != demo_data(proj, c):  # C-021 п.5: флаг не снимается и не ставится руками
        out.append(_p(f"{cid}: demo_data={bool(c.get('demo_data'))}, а источник "
                      f"{'синтетический' if demo_data(proj, c) else 'не синтетический'} (C-021)",
                      "Верните demo_data как у источника, затем: python3 tools/cli.py accept-edit --reason \"...\""))
    for dep in c.get("depends_on") or []:
        d = claims_by_id.get(dep)
        if d is None:
            out.append(_p(f"{cid}: зависит от несуществующего {dep}", "Проверьте ID: python3 tools/cli.py status"))
        elif d.get("status") != "active" and not c.get("needs_revision"):
            out.append(_p(f"{cid}: зависит от отозванного {dep}", "Повторите без отозванного: python3 tools/cli.py register-claim ... --depends-on CLM-XXX"))
    return out


def quote_problems(proj, cid, quote, src, sid):
    q = normalize_ws(quote)
    if len(q) < MIN_QUOTE:
        return [_p(f"{cid}: цитата короче {MIN_QUOTE} символов — по ней нельзя проверить источник",
                   "Возьмите фрагмент длиннее, дословно: python3 tools/cli.py register-claim ... --quote \"...\"")]
    if src is None:
        return [] if sid else [_p(f"{cid}: цитата без источника — укажите --source SRC-XX")]
    try:
        text = sources.snapshot_text(proj, src)
    except CliError as e:
        return [(f"{cid}: {e.error}", e.hint, e.code)]
    if q not in normalize_ws(text):
        return [_p(f"{cid}: цитаты нет дословно в {sid}: «{q[:80]}»",
                   f"Скопируйте фрагмент из {src['text_path']} без изменений (регистр, ё, кавычки, тире важны) и повторите: python3 tools/cli.py register-claim ... --quote \"...\"")]
    return []


def _raise_first(probs):
    msg, hint, code = sorted(probs, key=lambda p: -p[2])[0]  # нарушение целостности (3) важнее
    raise CliError(msg, hint, code=code)


def register_claim(proj, type, origin, text, source=None, quote=None, calc=None, depends_on=None):
    db = proj.load("evidence_db.json")
    by_id = {c.get("id"): c for c in db["claims"]}
    new = {"type": type, "origin_type": origin, "source_id": source or None, "verbatim_quote": quote or None,
           "calc_id": calc or None, "text": text, "depends_on": split_list(depends_on)}
    new["demo_data"] = demo_data(proj, new)
    for c in db["claims"]:
        if all(c.get(k) == new[k] for k in KEY):
            return {"id": c["id"], "status": c["status"], "demo_data": bool(c.get("demo_data"))}
    sources.refuse_superseded(sources.get(proj, new["source_id"]))
    probs = problems(proj, new, by_id)
    if probs:
        _raise_first(probs)
    nums = [int(c["id"][4:]) for c in db["claims"] if str(c.get("id", "")).startswith("CLM-") and c["id"][4:].isdigit()]
    cid = f"CLM-{max(nums, default=0) + 1:03d}"
    db["claims"].append({"id": cid, **new, "status": "active", "needs_revision": False, "created_at": now_iso()})
    proj.save("evidence_db.json", db)
    proj.commit("register-claim", new, cid)
    return {"id": cid, "status": "active", "demo_data": new["demo_data"]}


def mark_dependents(db, opts, decs, claim_id):
    """Общая пометка зависимых для revoke-claim и ingest-update (C-031 п.1, C-034 п.5). Меняет реестры только в памяти.
    -> (утверждения, варианты, решения)."""
    hit, frontier = set(), {claim_id}
    while frontier:  # зависимые утверждения транзитивно
        nxt = {c["id"] for c in db["claims"] if set(c.get("depends_on") or []) & frontier} - hit - {claim_id}
        hit |= nxt
        frontier = nxt
    hit_opts = [o["id"] for o in opts["options"] if set(o.get("claims") or []) & (hit | {claim_id})]
    for c in db["claims"]:
        if c["id"] in hit:
            c["needs_revision"] = True
    for o in opts["options"]:
        if o["id"] in hit_opts:
            o["needs_revision"] = True
    return hit, hit_opts, decisions.mark_stale(decs, claim_id, hit, hit_opts)


def revoke_claim(proj, id, reason, redact_pii=False):
    if not reason.strip():
        raise CliError("Нужна причина отзыва", f'python3 tools/cli.py revoke-claim --id {id} --reason "почему устарело"')
    reason = sources.check_field(reason, redact_pii, f'python3 tools/cli.py revoke-claim --id {id} --reason "..."')  # C-038 п.7
    db = proj.load("evidence_db.json")
    target = next((c for c in db["claims"] if c.get("id") == id), None)
    if target is None:
        raise CliError(f"Утверждение {id} не найдено", "Список утверждений: python3 tools/cli.py status")
    if target.get("status") in ("revoked", "superseded"):  # C-034 п.6: заменённое ведёт себя как отозванное
        return {"id": id, "status": target["status"], "affected": target.get("affected", [])}
    opts, decs = proj.load("options.json"), proj.load("decisions.json")
    hit, hit_opts, hit_decs = mark_dependents(db, opts, decs, id)
    affected = sorted(hit) + hit_opts + hit_decs
    target.update(status="revoked", revoked_reason=reason, revoked_at=now_iso(), affected=affected)
    proj.save("evidence_db.json", db)
    proj.save("options.json", opts)
    if hit_decs:
        proj.save("decisions.json", decs)
    if hit_opts:
        from . import renderer
        renderer.render_options(proj)
    proj.commit("revoke-claim", {"id": id, "reason": reason}, id)
    return {"id": id, "status": "revoked", "affected": affected}


def all_violations(proj):
    claims = proj.load("evidence_db.json")["claims"]
    by_id = {c.get("id"): c for c in claims}
    out = []
    for c in claims:
        if c.get("status") == "active":
            out += [p[0] for p in problems(proj, c, by_id)]
    return out


def verify_quotes(proj):
    claims = [c for c in proj.load("evidence_db.json")["claims"] if c.get("status") == "active"]
    checked, failed, code = 0, [], 1
    for c in claims:
        if not c.get("verbatim_quote"):
            continue
        checked += 1
        sid = c.get("source_id")
        probs = quote_problems(proj, c["id"], c["verbatim_quote"], sources.get(proj, sid) if sid else None, sid)
        if sid and sources.get(proj, sid) is None:
            probs.append(_p(f"{c['id']}: источник {sid} не найден"))
        for msg, _, pcode in probs:
            failed.append({"id": c["id"], "error": msg})
            code = max(code, pcode)
    if failed:
        raise CliError(f"Цитаты не подтвердились: {len(failed)} из {checked}",
                       "Отзовите или исправьте утверждения: python3 tools/cli.py revoke-claim --id CLM-XX --reason \"...\"",
                       code=code, checked=checked, failed=failed, violations=[f["error"] for f in failed])
    return {"checked": checked, "failed": []}
