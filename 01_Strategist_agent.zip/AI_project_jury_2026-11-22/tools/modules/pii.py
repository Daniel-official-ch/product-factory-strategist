"""C-025, C-029, C-030: поиск и скрытие телефонов и адресов почты. Полные значения наружу не отдаёт: только маски."""
import re
import unicodedata

# Пробелы Unicode без переносов строк, дефис и тире, скобки (C-025, C-029 п.2, C-030 п.2).
SEP = r" \t\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000\-\u2010-\u2015()"
# С точкой и косой — только группировка 1-3-3-2-2 (C-030 п.4): иначе номером становятся даты и версии.
_DOT = rf"[{SEP}./]*"
PHONE = re.compile(rf"(?<!\d)(?:\+7|[78])(?:(?:[{SEP}]*\d){{10}}|{_DOT}\d{{3}}{_DOT}\d{{3}}{_DOT}\d{{2}}{_DOT}\d{{2}})(?!\d)")
# Lookbehind держит поиск линейным на длинных токенах; файлы вида logo@2x.png — не почта.
EMAIL = re.compile(r"(?<![\w.+%-])[\w.+%-]+@[\w-]+(?:\.[\w-]+)*\.(?!(?:png|jpe?g|gif|svg|webp|ico|css|js)\b)[^\W\d_]{2,}")
PHONE_MASK, EMAIL_MASK = "[телефон скрыт]", "[почта скрыта]"
MAX_EXAMPLES = 5
MAX_EMAIL_EXAMPLES = 2  # чтобы длинный список телефонов не вытеснял почту из примеров


def _normalized(text):
    """NFKC посимвольно и карта «позиция результата -> позиция исходника»: ищем по нормальной форме,
    а заменяем в исходнике, потому что остальной слепок обязан остаться дословным (цитаты, C-001)."""
    parts, index = [], []
    for i, ch in enumerate(text):
        norm = unicodedata.normalize("NFKC", ch)
        parts.append(norm)
        index += [i] * len(norm)
    return "".join(parts), index


def find(text):
    """-> (телефоны, почта). Почта первой: иначе адрес из 11 цифр до «@» сработает как телефон."""
    norm = _normalized(text)[0]
    return PHONE.findall(EMAIL.sub(EMAIL_MASK, norm)), EMAIL.findall(norm)


def _replace(pattern, mask, text):
    norm, index = _normalized(text)
    parts, pos = [], 0
    for m in pattern.finditer(norm):
        parts += [text[pos:index[m.start()]], mask]
        pos = index[m.end() - 1] + 1
    return "".join(parts) + text[pos:]


def redact(text):
    return _replace(PHONE, PHONE_MASK, _replace(EMAIL, EMAIL_MASK, text))


def _key(value):
    return value.lower() if "@" in value else re.sub(r"\D", "", value)[-10:]


def has_new_values(markup, text):
    """Есть ли в разметке значения, которых нет в тексте слепка (скрипты, атрибуты, комментарии)."""
    phones, emails = find(text)
    seen = {_key(v) for v in phones + emails}
    phones, emails = find(markup)
    return any(_key(v) not in seen for v in phones + emails)


def masks(phones, emails):
    shown = [f"+7 *** ***-**-{re.sub(r'[^0-9]', '', v)[-2:]}" for v in phones[:MAX_EXAMPLES - min(len(emails), MAX_EMAIL_EXAMPLES)]]
    shown += [f"{v[0]}***@{v.split('@', 1)[1]}" for v in emails]
    return shown[:MAX_EXAMPLES]


# ------------------------------------------------------------------ C-046: возможные имена людей (предупреждение)
_UP, _LO = "A-ZА-ЯЁ", "a-zа-яё"
_WORD = rf"[{_UP}][{_LO}]+(?:-[{_UP}][{_LO}]+)?"
_PATRONYMIC = r"[А-ЯЁ][а-яё]+(?:ович|евич|ична|овна|евна)"
FULL_NAME = re.compile(rf"(?<![\w-])(?:(?:{_WORD}\s+){{1,2}}{_PATRONYMIC}(?:\s+{_WORD})?|{_PATRONYMIC}\s+{_WORD})(?![\w-])")
INITIALS = re.compile(rf"(?<![\w.])(?!(?:U\.S|U\.K|U\.N|E\.U|D\.C)\.)(?:[{_UP}]\.\s?[{_UP}]\.\s?{_WORD}|{_WORD}\s[{_UP}]\.\s?[{_UP}]\.)(?![\w-])")
SIGNATURE = re.compile(rf"(?:{_WORD})(?:\s+{_WORD})?,?")
# Рядом с подписью — отзыв: слово «отзыв»/review, звёзды или оценка. Подпись с запятой («Allison,») — ещё и речь
# от первого лица или цитата в кавычках: так подписаны отзывы на лендингах без слова «отзыв».
REVIEW = re.compile(r"(?i)отзыв|review|testimonial|[★☆⭐]|\b\d(?:[.,]\d)?\s*(?:/|из|out of)\s*5\b|оценк|rating")
SPEECH = re.compile(r"(?i)\b(?:I|I[’']m|me|my|we|we[’']re|our|я|мне|меня|мой|моя|мы|нам|наш|наша)\b|[«“„]")
MAX_NAMES = 20
NAME_WINDOW = 3


def _signature(lines, i, low):
    s = lines[i].strip()
    if not SIGNATURE.fullmatch(s) or _common(s, low) or REVIEW.search(s):  # «Review» над отзывом — не подпись
        return False
    near = lines[max(0, i - NAME_WINDOW):i] + lines[i + 1:i + 1 + NAME_WINDOW]
    return any(REVIEW.search(ln) or (s.endswith(",") and SPEECH.search(ln)) for ln in near)


def _common(s, low):
    """Слово встречается в тексте со строчной буквы — обычное слово (меню, термин), а не имя."""
    return any(w.lower() in low for w in re.findall(rf"[{_LO}{_UP}]{{2,}}", s))


def _lower_words(text):
    return {w for w in re.findall(rf"[{_LO}{_UP}]+", text) if w[0].islower()}


def find_names(text, first_line=1):
    """C-046 п.1 -> [{line, text}] не больше MAX_NAMES: ФИО с отчеством, инициалы, подписи под отзывами."""
    lines = text.split("\n")
    low = _lower_words(text)
    out = []
    for i, ln in enumerate(lines):
        hits = [m.group(0) for rx in (FULL_NAME, INITIALS) for m in rx.finditer(ln) if not _common(m.group(0), low)]
        if not hits and _signature(lines, i, low):
            hits = [ln.strip()]
        out += [{"line": i + first_line, "text": h} for h in hits]
    return out[:MAX_NAMES]


def redact_terms(text, terms):
    """C-046 п.2: каждый термин целым словом, с учётом регистра -> (текст, число замен).

    Длинные термины идут первыми, чтобы короткий не оставил хвост длинного.
    Уже поставленные маски не разбираются повторно.
    """
    terms = sorted({term for term in terms if term and term.strip()}, key=len, reverse=True)
    terms = [term for term in terms
             if not re.search(rf"(?<!\w){re.escape(term)}(?!\w)", NAME_MASK)]
    if not terms:
        return text, 0
    pattern = re.compile(rf"(?<!\w)(?:{'|'.join(re.escape(term) for term in terms)})(?!\w)")
    total = 0
    parts = []
    for part in text.split(NAME_MASK):
        clean, n = pattern.subn(NAME_MASK, part)
        parts.append(clean)
        total += n
    return NAME_MASK.join(parts), total


NAME_MASK = "[имя скрыто]"
