"""analyze-table (C-032): проверка таблицы-источника. Читает проверенный слепок как текст, ячейки ничего не исполняют."""
import csv
import io
import math
import re
import statistics
from collections import Counter
from datetime import date, timedelta
from pathlib import Path

from . import sources
from .common import CliError, normalize_ws, sha256_bytes, sha256_text, write_json

MAX_VALUE = 80  # C-032 п.6
MAX_ROWS = 100  # длинный список строк съел бы контекст модели; полное число — в detail
MISSING = {"", "na", "n/a", "nan", "-", "–", "—", "н/д"}
SP = " \u00a0\u2009\u202f"
NUM = rf"[+\-−]?(?:\d{{1,3}}(?:[{SP}]\d{{3}})+|\d+(?:[.,]\d{{3}})*)(?:[.,]\d+)?(?:[eE][+\-]?\d+)?"
CELL = re.compile(rf"([$€₽]?)\s*({NUM})\s*(\S.*)?", re.S)
SCALE = {"тыс": "тыс.", "т": "тыс.", "млн": "млн", "млрд": "млрд"}
CURRENCY = {"руб": "руб", "рублей": "руб", "рубля": "руб", "р": "руб", "₽": "руб", "rub": "руб", "usd": "$", "$": "$",
            "долл": "$", "eur": "€", "€": "€"}
COUNT = {"шт", "чел", "ед"}
L = "а-яёa-z"
MONEY_NAME = re.compile(rf"(?<![{L}])(?:(тыс|млн|млрд)[.\s]*)?(руб|долл|rub\b|usd\b|eur\b|[₽$€])")
OTHER_NAME = re.compile(rf"(?<![{L}])(шт|штук|чел|человек|ед|мин|минут|сек|час|часов|дн|дней|мес|месяцев|гб|мб|кб|кг|км|"
                        rf"pcs|ms|sec|min|hours|days|gb|mb|kg|km|count|кол-?во|количество)(?![{L}])")
SHARE_NAME = re.compile(rf"(?<![{L}])(дол[яиейю]+|конверси|удержани|отток|share|rate|conversion|retention|churn|ctr)")
PERCENT_NAME = re.compile(rf"%|(?<![{L}])(процент|percent|pct)")
DELTA_NAME = re.compile("изменен|рост|прибыл|марж|delta|change")  # C-037 п.5
YEAR_NAME = re.compile("год|year|период|period")
MONTHS = {p: i for i, ps in enumerate((("янв", "jan"), ("фев", "feb"), ("мар", "mar"), ("апр", "apr"), ("май", "мая", "may"),
                                       ("июн", "jun"), ("июл", "jul"), ("авг", "aug"), ("сен", "sep"), ("окт", "oct"),
                                       ("ноя", "nov"), ("дек", "dec")), 1) for p in ps}
HINT_TABLE = "Загрузите таблицу как .csv или .xlsx: python3 tools/cli.py ingest-source --file <таблица.csv> --id SRC-XX"
HINT_FIX = "Сохраните таблицу заново в CSV с одной строкой заголовка и повторите: python3 tools/cli.py ingest-source --file <таблица.csv> --id SRC-XX"


def _clip(value):
    return normalize_ws(str(value))[:MAX_VALUE]


def _number(text):
    """-> float или None. Десятичный разделитель — последний из запятой и точки; одна запятая всегда десятичная."""
    s = re.sub(f"[{SP}]", "", text).replace("−", "-")
    if "," in s and "." in s:
        s = s.replace("," if s.rfind(".") > s.rfind(",") else ".", "")
    elif s.count(",") > 1:
        s = s.replace(",", "")
    elif s.count(".") > 1:
        s = s.replace(".", "")
    value = float(s.replace(",", "."))
    return value if math.isfinite(value) else None


def _unit_label(raw):
    """Единица из ячейки: метка, None (её нет) или False (не единица, значит ячейка не число)."""
    if not raw:
        return None
    if raw == "%":
        return "%"
    words = re.sub(r"[₽$€]", r" \g<0> ", raw.lower().replace(".", " ")).split()
    scale = SCALE[words.pop(0)] if words and words[0] in SCALE else ""
    if len(words) > 1:
        return False
    if words and words[0] in COUNT and not scale:
        return words[0]
    if words and words[0] not in CURRENCY:
        return False
    return " ".join(x for x in (scale, CURRENCY[words[0]] if words else "") if x)


def _cell(text):
    """-> (значение, единица) или None, если ячейка не число."""
    m = CELL.fullmatch(text)
    if not m:
        return None
    unit = _unit_label(m.group(1) or m.group(3))
    value = _number(m.group(2))
    return None if unit is False or value is None else (value, unit)


def _name_unit(name):
    s = name.lower().replace("_", " ")
    if PERCENT_NAME.search(s):
        return "%"
    m = MONEY_NAME.search(s)
    if m:
        cur = next(v for k, v in CURRENCY.items() if m.group(2).rstrip().startswith(k))
        return f"{SCALE[m.group(1)]} {cur}" if m.group(1) else cur
    m = OTHER_NAME.search(s)
    if m:
        return "шт" if m.group(1) in ("count", "кол-во", "колво", "количество") else m.group(1)
    return "доля" if SHARE_NAME.search(s) else None


def _period(text, name):
    """-> (гранулярность, ключ для порядка, каноническая запись) или None."""
    s = text.strip().lower()

    def day(y, m, d):
        try:
            v = date(int(y), int(m), int(d))
        except ValueError:
            return None
        return ("day", v.toordinal(), v.isoformat()) if 1900 <= v.year <= 2100 else None

    def month(y, m):
        y, m = int(y), int(m)
        return ("month", y * 12 + m - 1, f"{y}-{m:02d}") if 1900 <= y <= 2100 and 1 <= m <= 12 else None

    def quarter(y, q):
        y, q = int(y), int(q)
        return ("quarter", y * 4 + q - 1, f"{y}-Q{q}") if 1900 <= y <= 2100 and 1 <= q <= 4 else None

    for pat, build in ((r"(\d{4})-(\d{2})-(\d{2})(?:[ t]\d\d:\d\d(?::\d\d(?:\.\d+)?)?)?", day),
                       (r"(\d{2})[./](\d{2})[./](\d{4})", lambda d, m, y: day(y, m, d)),
                       (r"(\d{4})[-/](\d{1,2})", month), (r"(\d{1,2})[./](\d{4})", lambda m, y: month(y, m)),
                       (r"(\d{4})[- ]?[qк]([1-4])", quarter), (r"[qк]([1-4])[- ]?(\d{4})", lambda q, y: quarter(y, q)),
                       (r"([1-4])\s*кв\.?(?:артал)?\s*(\d{4})(?:\s*г\.?)?", lambda q, y: quarter(y, q))):
        m = re.fullmatch(pat, s)
        if m:
            return build(*m.groups())
    m = re.fullmatch(r"(\d{4})-?w(\d{2})", s)
    if m:
        try:
            v = date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)
        except ValueError:
            return None
        return ("week", v.toordinal() // 7, f"{m.group(1)}-W{m.group(2)}")
    m = re.fullmatch(r"([а-яёa-z]+)\.?\s+(\d{4})(?:\s*г\.?)?", s) or re.fullmatch(r"(\d{4})\s+([а-яёa-z]+)\.?", s)
    if m:
        word, year = m.groups() if m.group(1)[0].isalpha() else m.groups()[::-1]
        num = MONTHS.get(word[:3])
        return month(year, num) if num else None
    if re.fullmatch(r"\d{4}", s) and YEAR_NAME.search(name.lower()) and 1900 <= int(s) <= 2100:
        return ("year", int(s), s)
    return None


def _key_label(granularity, key):
    if granularity == "month":
        return f"{key // 12}-{key % 12 + 1:02d}"
    if granularity == "quarter":
        return f"{key // 4}-Q{key % 4 + 1}"
    if granularity == "week":
        iso = date.fromordinal(key * 7 + 1).isocalendar()  # ключ недели — порядковый номер понедельника // 7
        return f"{iso[0]}-W{iso[1]:02d}"
    if granularity == "day":
        return date.fromordinal(key).isoformat()
    return str(key)


def _cell_text(v):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return ""
    return str(v).strip()


def _book_sheets(proj, src):
    """C-038 п.5: листы из самой книги (копия в raw_materials/), а не из строк «# Лист:» слепка: ячейка с таким текстом
    в слепке неотличима от заголовка листа. -> {имя: строки ячеек}."""
    if not src.get("copy_path"):
        raise CliError(f"Книга {src['id']} не сохранена: при загрузке в ней нашлись персональные данные",
                       "Обезличьте книгу, сохраните как .csv или .xlsx и загрузите под новым ID: "
                       "python3 tools/cli.py ingest-source --file <таблица.xlsx> --id SRC-XX")
    path = proj.path(src["copy_path"])
    if not path.is_file() or sha256_bytes(path.read_bytes()) != src.get("sha256"):
        raise CliError(f"Копия книги {src['copy_path']} изменена или удалена после загрузки",
                       "Загрузите таблицу заново под новым ID: python3 tools/cli.py ingest-source --file <таблица.xlsx> --id SRC-XX",
                       code=3)
    import pandas as pd  # тяжёлый импорт только для xlsx
    try:
        book = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    except Exception:
        raise CliError(f"Книгу {src['id']} нельзя прочитать", HINT_FIX)
    return {str(name): [[_cell_text(v) for v in row] for row in df.itertuples(index=False)] for name, df in book.items()}


def _load_rows(proj, src, sheet):
    """-> строки ячеек вместе с заголовком."""
    suffix = Path(src.get("copy_path") or src.get("origin_path") or "").suffix.lower()
    if src.get("kind") != "file" or suffix not in sources.TABLE_EXT:
        raise CliError(f"Источник {src['id']} не таблица: проверяются только .csv и .xlsx", HINT_TABLE)
    if suffix != ".xlsx":
        if sheet:
            raise CliError(f"В CSV нет листов, а указан --sheet «{_clip(sheet)}»",
                           "Листы бывают только у таблиц .xlsx; для CSV повторите без --sheet: "
                           f"python3 tools/cli.py analyze-table --source {src['id']}")
        return _csv_rows(sources.snapshot_text(proj, src), src["id"])
    sheets = _book_sheets(proj, src)
    names = ", ".join(_clip(n) for n in sheets)
    if sheet is None and len(sheets) > 1:  # молча разобрать первый лист значило бы скрыть остальные
        raise CliError(f"В книге несколько листов: {names}. Какой проверить?",
                       f"Укажите лист: python3 tools/cli.py analyze-table --source {src['id']} --sheet <имя>")
    if sheet is not None and sheet not in sheets:
        raise CliError(f"Листа «{_clip(sheet)}» нет, есть: {names}",
                       f"python3 tools/cli.py analyze-table --source {src['id']} --sheet <имя>")
    rows = [r for r in (sheets[sheet] if sheet is not None else next(iter(sheets.values()), [])) if any(r)]
    used = [i for i in range(max(map(len, rows), default=0)) if any(i < len(r) and r[i] for r in rows)]
    rows = [[r[i] for i in used] for r in rows]  # пустые столбцы из оформленного диапазона — не данные
    if rows and next(c for c in rows[0] if c).startswith("# SYNTHETIC"):  # C-038 п.6
        rows = rows[1:]
    return rows


def _csv_rows(text, sid):
    """Разделитель выбирается по лучшей согласованности длины строк."""
    if "\x00" in text:  # C-038 п.3: так выглядит UTF-16, прочитанный как однобайтная кодировка
        raise CliError(f"Таблицу {sid} нельзя разобрать: кодировка файла не распознана (в тексте есть NUL-символы)",
                       "Пересохраните файл в UTF-8 и загрузите под новым ID: python3 tools/cli.py ingest-source --file <таблица.csv> --id SRC-XX")
    if sources.is_synthetic(text):  # C-032 п.1: метка не данные
        text = re.sub(r"\A\s*# SYNTHETIC[^\n]*\n?", "", text)
    best, score = None, (0, 0)
    for delim in ",;\t":
        try:
            rows = [[c.strip() for c in r] for r in csv.reader(io.StringIO(text), delimiter=delim) if any(c.strip() for c in r)]
        except csv.Error:
            continue
        if rows and len(rows[0]) > 1 and (s := (sum(len(r) == len(rows[0]) for r in rows), len(rows[0]))) > score:
            best, score = rows, s
    return best or []


def _table(best, sid):
    """-> (заголовок, строки данных)."""
    if len(best) < 2 or len(best[0]) < 2:
        raise CliError(f"Таблицу {sid} нельзя разобрать: нужны строка заголовка, минимум два столбца и строки данных", HINT_FIX)
    width = len(best[0])
    data = []
    for n, row in enumerate(best[1:], 1):
        if any(row[width:]):
            raise CliError(f"Таблицу {sid} нельзя разобрать: в строке данных {n} ячеек больше, чем столбцов в заголовке", HINT_FIX)
        data.append((row + [""] * width)[:width])
    return [h or f"столбец {i}" for i, h in enumerate(best[0], 1)], data


def _issue(out, check, column, rows, detail, severity="error"):
    rows = sorted(rows)
    if len(rows) > MAX_ROWS:
        detail += f" Показаны первые {MAX_ROWS} из {len(rows)} строк."
    out.append({"check": check, "severity": severity, "column": _clip(column) if column is not None else None,
                "rows": rows[:MAX_ROWS], "detail": detail})


def _num_out(v):
    return int(v) if v == int(v) and abs(v) < 1e15 else round(v, 6)


def _check_numeric(name, kind, name_unit, nums, texts, issues):
    """nums: [(строка, значение, единица)], texts: [(строка, ячейка)]."""
    bare = name_unit if name_unit not in ("%", "доля") else None  # «%» в названии не отменяет смесь «12%» и «0,12»
    labels = {u or bare for _, _, u in nums}
    if len(labels) > 1:
        odd = Counter(u or bare for _, _, u in nums).most_common()[-1][0]
        _issue(issues, "mixed_units", name, [r for r, _, u in nums if (u or bare) == odd],
               "В столбце разные единицы: " + ", ".join(sorted(x or "без единицы" for x in labels)) + ".")
    delta = DELTA_NAME.search(name.lower())
    if kind == "percent" and not delta:
        out = [r for r, v, _ in nums if v < 0 or v > 100]
        small = [r for r, v, u in nums if 0 < v < 1 and u != "%"]
        big = [r for r, v, _ in nums if 1 < v <= 100]
        mix = min(small, big, key=len) if small and big else []
        if out or mix:
            parts = ["значения вне 0–100"] * bool(out) + ["смесь шкал 0–1 и 0–100"] * bool(mix)
            _issue(issues, "percent_range", name, set(out) | set(mix), "Доля: " + ", ".join(parts) + ".")
    if texts:
        _issue(issues, "non_numeric", name, [r for r, _ in texts], f"Текст в числовом столбце, например «{_clip(texts[0][1])}».")
    if not delta:
        neg = [r for r, v, _ in nums if v < 0]
        if neg:
            _issue(issues, "negative", name, neg, f"Отрицательных значений: {len(neg)}.")
    if len(nums) >= 4:
        q1, _, q3 = statistics.quantiles([v for _, v, _ in nums], n=4, method="inclusive")
        far = [r for r, v, _ in nums if v < q1 - 3 * (q3 - q1) or v > q3 + 3 * (q3 - q1)]
        if far:
            _issue(issues, "outlier", name, far, "Значения дальше 3×IQR от квартилей.", "warning")
    if name_unit is None:
        _issue(issues, "unit_unknown", name, [], "В названии столбца нет единицы измерения.", "warning")


def _column(name, cells, total, issues):
    """cells: [(строка, ячейка)]. -> (описание столбца, данные периода или None)."""
    present = [(r, s) for r, s in cells if s.lower() not in MISSING]
    gaps = [r for r, s in cells if s.lower() in MISSING]
    if gaps:
        _issue(issues, "missing", name, gaps, f"Пропусков: {len(gaps)} из {total}.")
    desc = {"name": _clip(name), "type": "text", "unit": None, "missing": len(gaps),
            "missing_share": round(len(gaps) / total, 4), "min": None, "max": None}
    parsed = [(r, p) for r, s in present if (p := _period(s, name))]
    if parsed and len(parsed) * 2 > len(present):
        granularity = Counter(p[0] for _, p in parsed).most_common(1)[0][0]
        points = [(r, p[1], p[2]) for r, p in parsed if p[0] == granularity]
        desc.update(type="date" if granularity == "day" else "period", min=min(points, key=lambda x: x[1])[2],
                    max=max(points, key=lambda x: x[1])[2])
        return desc, (granularity, points)
    nums, texts = [], []
    for r, s in present:
        c = _cell(s)
        if c:
            nums.append((r, *c))
        else:
            texts.append((r, s))
    unit = _name_unit(name)
    if not nums or (len(nums) * 2 < len(present) and not unit):
        return desc, None
    common = Counter(u for _, _, u in nums if u).most_common(1)
    cell_unit = common[0][0] if common else None
    is_percent = unit in ("%", "доля") or sum(u == "%" for _, _, u in nums) * 2 > len(nums)
    money_unit = next((u for u in (unit, cell_unit) if u and any(m in u for m in ("руб", "$", "€"))), None)
    kind = "percent" if is_percent else "money" if money_unit else "number"
    desc.update(type=kind, unit=unit or cell_unit, min=_num_out(min(v for _, v, _ in nums)), max=_num_out(max(v for _, v, _ in nums)))
    _check_numeric(name, kind, unit, nums, texts, issues)
    return desc, None


def _periods(name, granularity, points, rows, columns, issues):
    keys = sorted({k for _, k, _ in points})
    step, label = 1, lambda k: _key_label(granularity, k)
    if granularity == "day" and all(date.fromordinal(k).day == 1 for k in keys) and len(keys) > 1:  # месяц записан датой
        granularity = "month"
        to_month = {k: date.fromordinal(k).year * 12 + date.fromordinal(k).month - 1 for k in keys}
        points = [(r, to_month[k], _key_label("month", to_month[k])) for r, k, _ in points]
        keys = sorted(set(to_month.values()))
    elif granularity == "day" and len(keys) > 2 and all((b - a) % 7 == 0 for a, b in zip(keys, keys[1:])):
        granularity, step = "week", 7
        label = lambda k: date.fromordinal(k).isoformat()
    have = set(keys)
    miss = [k for k in range(keys[0], keys[-1], step) if k not in have]
    if granularity == "day" and len(miss) > len(keys):  # редкие события, а не ряд: дыры ничего не значат
        miss = []
    # Длинная таблица (месяц × тариф): период повторяется законно, ключ — период и текстовые разрезы
    dims = [i for i, c in enumerate(columns) if c["type"] == "text" and 1 < len({row[i] for row in rows}) <= len(rows) / 2]
    groups = {}
    for r, k, _ in points:
        groups.setdefault((k, *(rows[r - 1][i] for i in dims)), []).append(r)
    repeated = {key: rs for key, rs in groups.items() if len(rs) > 1}
    dup_keys = sorted({key[0] for key in repeated})
    if miss:
        _issue(issues, "period_gap", name, [], f"Пропущено периодов: {len(miss)}: " + ", ".join(label(k) for k in miss[:MAX_ROWS]) + ".")  # C-037 п.4, C-038 п.4
    if repeated:
        _issue(issues, "period_duplicate", name, [r for rs in repeated.values() for r in rs],
               f"Повторяются периоды: {len(dup_keys)}.")
    return {"column": _clip(name), "granularity": granularity, "first": label(keys[0]), "last": label(keys[-1]),
            "gaps": [label(k) for k in miss[:MAX_ROWS]], "duplicates": [label(k) for k in dup_keys]}


def _sheet_suffix(sheet):
    """C-037 п.2, п.16: имя листа недоверенное и в путь идёт очищенным; при замене символов хеш разводит «A B» и «A_B»."""
    if sheet is None:
        return ""
    safe = re.sub(r"[^\w-]", "_", sheet)
    return f".{safe}" if safe == sheet else f".{safe}-{sha256_text(sheet)[:8]}"


def analyze_table(proj, source, sheet=None):
    src = sources.get(proj, source)
    if src is None:
        raise CliError(f"Источник {_clip(source)} не найден", HINT_TABLE)
    header, rows = _table(_load_rows(proj, src, sheet), source)
    issues, columns, series = [], [], []
    for i, name in enumerate(header):
        desc, found = _column(name, [(n, row[i]) for n, row in enumerate(rows, 1)], len(rows), issues)
        columns.append(desc)
        if found:
            series.append((name, *found))
    groups = {}
    for n, row in enumerate(rows, 1):
        groups.setdefault(tuple(row), []).append(n)
    dup = [n for ns in groups.values() if len(ns) > 1 for n in ns]
    if dup:
        _issue(issues, "duplicate_rows", None, dup, "Полностью одинаковые строки.")
    periods = None
    if series:
        name, granularity, points = min(series, key=lambda s: s[1] == "day")  # period важнее date, при равенстве — первый столбец
        periods = _periods(name, granularity, points, rows, columns, issues)
    report_path = f"analysis/{source}{_sheet_suffix(sheet)}.json"
    out = {"ok": True, "source": source, "sheet": None if sheet is None else sheet[:MAX_VALUE],  # C-037 п.15
           "synthetic": bool(src.get("synthetic")), "rows": len(rows), "columns": columns,
           "periods": periods, "issues": issues, "issues_count": len(issues), "report_path": report_path, "untrusted_values": True}
    write_json(proj.path(report_path), out)
    return out
