"""Бизнес-логика CLI. cli.py и mcp_server.py — только адаптеры."""
