"""Граф решений и impact (C-033). Источник правды — реестры: файл графа производный, impact его не читает."""
import re

from .common import CliError, write_json

FILE = "decision_graph.json"
AFFECTED = ("CLM", "OPT", "DEC")


def _items(proj, fname, key):
    return [x for x in proj.load(fname)[key] if isinstance(x.get("id"), str)]  # после accept-edit запись может быть без id


def build(proj):
    srcs = _items(proj, "sources.json", "sources")
    calcs = _items(proj, "calculations.json", "calculations")
    claims = _items(proj, "evidence_db.json", "claims")
    opts = _items(proj, "options.json", "options")
    decs = _items(proj, "decisions.json", "decisions")
    nodes = [{"id": x["id"], "type": kind, "status": x.get("status") or ("superseded" if x.get("superseded_by") else "active"),
              "needs_revision": bool(x.get("needs_revision"))}
             for kind, group in (("SRC", srcs), ("CALC", calcs), ("CLM", claims), ("OPT", opts), ("DEC", decs)) for x in group]
    edges = {(c.get("source_id"), c["id"], "quotes") for c in claims if c.get("verbatim_quote") or not c.get("calc_id")}
    edges |= {(sid, c["id"], "quotes") for c in claims for sid in c.get("confirmed_by") or []}  # цитата есть и в новом источнике
    edges |= {(c.get("source_id"), c["id"], "input") for c in calcs}
    edges |= {(c.get("calc_id"), c["id"], "calc") for c in claims}
    edges |= {(dep, c["id"], "depends_on") for c in claims for dep in c.get("depends_on") or []}
    edges |= {(cid, o["id"], "supports") for o in opts for cid in o.get("claims") or []}
    edges |= {(cid, d["id"], "based_on") for d in decs for cid in d.get("claims") or []}
    edges |= {(d.get("option"), d["id"], "chosen") for d in decs}
    known = {n["id"] for n in nodes}
    return {"nodes": sorted(nodes, key=lambda n: n["id"]),
            "edges": [{"from": a, "to": b, "kind": k} for a, b, k in sorted(e for e in edges if e[0] in known and e[1] in known)]}


def write(proj):
    write_json(proj.path(FILE), build(proj))


def _named_lines(proj, ids):
    """Строки deliverables/*.md, где названы ids: граница ID, чтобы CLM-001 не совпал с CLM-0011."""
    if not ids:
        return []
    named = re.compile(r"(?<![\w-])(?:" + "|".join(re.escape(i) for i in sorted(ids)) + r")(?![\w-])")
    out = []
    for f in sorted(proj.path("deliverables").glob("*.md")):
        lines = [n for n, ln in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1) if named.search(ln)]
        if lines:
            out.append({"file": f"deliverables/{f.name}", "lines": lines})
    return out


def impact(proj, id):
    graph = build(proj)  # C-033 п.4: всегда из реестров
    if id not in {n["id"] for n in graph["nodes"]}:
        raise CliError(f"{id or 'Пустой ID'}: такой записи нет среди источников, расчётов, утверждений и вариантов",
                       "Нужен ID вида SRC-01, CALC-01, CLM-001, OPT-01 или DEC-01: его называют команды register-* и ingest-*")
    down = {}
    for e in graph["edges"]:
        down.setdefault(e["from"], set()).add(e["to"])
    direct = down.get(id, set()) - {id}
    seen, frontier = set(direct), direct
    while frontier:
        frontier = {t for f in frontier for t in down.get(f, ())} - seen - {id}
        seen |= frontier
    by_type = {t: sorted(x for x in seen if x.startswith(t + "-")) for t in AFFECTED}
    named = {x for x in seen | {id} if x.split("-")[0] in AFFECTED}  # сам CLM или OPT тоже затронут в документах
    return {"ok": True, "id": id, "direct": sorted(direct), "transitive": sorted(seen - direct), "by_type": by_type,
            "deliverables": _named_lines(proj, named)}
