"""verify-run (C-016): сквозная проверка проекта. Только читает: ни файлов, ни хеша не меняет."""
import re
import unicodedata

from . import calculations, evidence_registry, options, sources
from .common import CliError

PLACEHOLDER = re.compile(r"<[^>]*>")  # C-012
CLM = re.compile(r"\bCLM-\d+\b")
FOOTNOTE = re.compile(r"\[\^(SRC-\d+)\]")
UNIT_START = re.compile(r"^\s*([-*+]\s|\d+[.)]\s|\||#)")  # пункт списка, строка таблицы, заголовок
INVISIBLE = re.compile("[\u00ad\u200b-\u200f\u2060\ufeff]")
TAG = re.compile(r"\[\s*([A-Za-zА-Яа-яЁё-]+)\s*\]")
RETIRED = "[ОТОЗВАНО]"  # C-026


def _canon(unit):
    """Метки [FACT]/[DEMO-DATA]/[SYNTHETIC]/[ОТОЗВАНО] в любом регистре, с пробелами, NBSP, полноширинными скобками
    и невидимыми символами внутри считаются метками (атаки T-212): человек читает их одинаково."""
    unit = INVISIBLE.sub("", unicodedata.normalize("NFKC", unit))
    return TAG.sub(lambda m: f"[{m.group(1).upper()}]", unit)


HINT = "Исправьте нарушения из violations и повторите: python3 tools/cli.py verify-run"


def _v(check, where, detail):
    return {"check": check, "where": where, "detail": detail}


def _units(text):
    """Строки документа -> единицы проверки с номером первой строки: строка таблицы и заголовок — сами по себе,
    абзац и пункт списка продолжаются следующими строками до пустой строки или новой единицы."""
    text = re.sub(r"<!--.*?-->", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    units, cur = [], None
    for n, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s or PLACEHOLDER.fullmatch(s):
            cur = None
            continue
        if cur is not None and not UNIT_START.match(line):
            cur[1] += " " + s  # продолжение абзаца или пункта списка
            continue
        units.append([n, s])
        cur = None if s.startswith(("|", "#")) else units[-1]
    return units


SEG_TAG = re.compile(r"\[(?:FACT|HYPOTHESIS|FORECAST)\]")


def _segments(unit):
    """C-022: сегменты [FACT] строки — от метки до следующей метки; текст до первой метки — к первому сегменту."""
    starts = [m.start() for m in SEG_TAG.finditer(unit)]
    if not starts:
        return []
    bounds = [0] + starts[1:] + [len(unit)]
    return [seg for seg in (unit[a:b] for a, b in zip(bounds, bounds[1:])) if "[FACT]" in seg]


def _retired(unit, claims):
    """C-029 п.5: [ОТОЗВАНО] освобождает единицу, только если в ней есть ссылка на отозванное утверждение."""
    return RETIRED in unit and any(r in claims and claims[r].get("status") != "active" for r in CLM.findall(unit))


def live_refs(text, claims):
    """CLM-ссылки документа, требующие активного утверждения: всё, кроме отозванных в единицах с [ОТОЗВАНО] (C-026)."""
    out = set()
    for _, unit in _units(text):
        unit = _canon(unit)
        retired = _retired(unit, claims)
        out |= {r for r in CLM.findall(unit) if not (retired and r in claims and claims[r].get("status") != "active")}
    return out


def _check_fact(seg, claims, where, viol, stats):
    refs = CLM.findall(seg)
    known = [claims[r] for r in refs if r in claims]
    stats["fact_lines_total"] += 1
    if not refs:
        viol.append(_v("deliverables", where, "[FACT] без ссылки на утверждение CLM-NNN"))
    elif any(c.get("status") == "active" and c.get("type") == "FACT" and not c.get("demo_data") for c in known):
        stats["fact_lines_verified"] += 1
    elif any(c.get("status") == "active" and c.get("type") == "FACT" for c in known):  # C-021 п.3–4
        stats["fact_lines_demo_data"] += 1
        if "[DEMO-DATA]" not in seg:
            viol.append(_v("deliverables", where, "демо-данные выданы за реальные"))
    elif known and all(c.get("type") in ("HYPOTHESIS", "FORECAST") for c in known):
        viol.append(_v("deliverables", where, "гипотеза выдана за факт"))
    else:
        viol.append(_v("deliverables", where, "[FACT] не опирается ни на одно активное утверждение FACT"))


def _check_deliverables(proj, claims, src_ids, viol, stats):
    files = sorted(proj.path("deliverables").glob("*.md"))
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            viol.append(_v("deliverables", f"deliverables/{f.name}", "файл не в кодировке UTF-8: пересохраните его в UTF-8"))
            continue
        for n, unit in _units(text):
            where = f"deliverables/{f.name}:{n}"
            unit = _canon(unit)
            refs = CLM.findall(unit)
            retired = _retired(unit, claims)
            for ref in dict.fromkeys(refs):
                c = claims.get(ref)
                if c is None:
                    viol.append(_v("deliverables", where, f"ссылка на несуществующее {ref}"))
                elif c.get("status") != "active" and not retired:  # C-026
                    viol.append(_v("deliverables", where, f"ссылка на {c.get('status')} утверждение {ref}"))
            for sid in dict.fromkeys(FOOTNOTE.findall(unit)):
                if sid not in src_ids:
                    viol.append(_v("deliverables", where, f"сноска на несуществующий источник {sid}"))
            if "[SYNTHETIC]" in unit and "[FACT]" in unit:
                viol.append(_v("deliverables", where, "синтетические данные помечены как [FACT]"))
            for seg in [] if retired else _segments(unit):  # C-022, C-026
                _check_fact(seg, claims, where, viol, stats)
    return bool(files)


def verify_run(proj):
    from . import state_manager  # state_manager импортирует этот модуль через commands; здесь — без цикла
    # 1. integrity: дальше не проверяем (C-016 п.1)
    try:
        state = proj.verify()
        broken = sources.all_violations(proj)
    except CliError as e:
        raise CliError(e.error, e.hint, code=3, ok=False,
                       violations=[_v("integrity", "state.json", e.error)])
    if broken:
        raise CliError("Слепки источников изменены после загрузки", sources_hint(), code=3, ok=False,
                       violations=[_v("integrity", v.split(":")[0], v) for v in broken])
    claims_list = proj.load("evidence_db.json")["claims"]
    claims = {c.get("id"): c for c in claims_list}
    active = [c for c in claims_list if c.get("status") == "active"]
    src_ids = {s.get("id") for s in proj.load("sources.json")["sources"]}
    done = [int(k) for k, v in (state.get("stage_status") or {}).items() if v == "done"]
    viol, checks = [], {"integrity": "ok"}
    stats = {"fact_lines_total": 0, "fact_lines_verified": 0, "fact_lines_demo_data": 0}

    def run(name, found, applicable=True):
        if not applicable:
            checks[name] = "skip"
            return
        checks[name] = "fail" if found else "ok"
        viol.extend(found)

    # 2. quotes
    quoted = [c for c in active if c.get("verbatim_quote")]
    run("quotes", [_v("quotes", c["id"], p[0]) for c in quoted for p in evidence_registry.quote_problems(
        proj, c["id"], c["verbatim_quote"], sources.get(proj, c.get("source_id")) if c.get("source_id") else None,
        c.get("source_id"))], bool(quoted))
    # 3. epistemics
    ep = []
    for c in active:
        t, o = c.get("type"), c.get("origin_type")
        if t == "FACT" and o in ("SYNTHETIC", "AGENT_INFERENCE"):
            ep.append(_v("epistemics", c["id"], f"FACT с происхождением {o}"))
        if o == "SYNTHETIC" and t != "HYPOTHESIS":
            ep.append(_v("epistemics", c["id"], f"SYNTHETIC допускается только для HYPOTHESIS, а не {t}"))
        if o == "CALCULATION":
            calc = calculations.get(proj, c.get("calc_id")) if c.get("calc_id") else None
            msgs = calculations.recheck(calc) if calc else [f"расчёт {c.get('calc_id')} не найден"]
            ep += [_v("epistemics", c["id"], m) for m in msgs]
        if bool(c.get("demo_data")) != evidence_registry.demo_data(proj, c):  # C-021 п.5
            ep.append(_v("epistemics", c["id"], f"флаг demo_data={bool(c.get('demo_data'))} не совпадает с synthetic источника"))
    run("epistemics", ep, bool(active))
    # 4. stages: закрытый этап должен оставаться выполненным
    run("stages", [_v("stages", f"этап {n}", f"этап {n} закрыт, но условие больше не выполняется: {p}")
                   for n in sorted(done) for p in state_manager.stage_problems(proj, n, state)], bool(done))
    # 5. deliverables
    found = []
    has_docs = _check_deliverables(proj, claims, src_ids, found, stats)
    run("deliverables", found, has_docs)
    # 6. options
    opts = proj.load("options.json")["options"]
    op = [_v("options", o["id"], "вариант требует пересмотра после отзыва утверждения") for o in opts if o.get("needs_revision")]
    if 4 in done:
        op += [_v("options", "options.json", p) for p in options.stage4_problems(proj) if "требует пересмотра" not in p]
    run("options", op, bool(opts) or 4 in done)
    # 7. cost
    entries = proj.load("cost_ledger.json").get("entries", [])
    run("cost", [] if entries else [_v("cost", "cost_ledger.json", "расходы не учтены: в cost_ledger.json нет записей")],
        2 in done)

    total = stats["fact_lines_total"]
    summary = {"stage": state.get("stage"), "sources": len(src_ids),
               "claims": {t: sum(1 for c in active if c.get("type") == t) for t in ("FACT", "HYPOTHESIS", "FORECAST")},
               **stats, "verified_share": round(stats["fact_lines_verified"] / total, 4) if total else 1.0,
               "demo_data_share": round(stats["fact_lines_demo_data"] / total, 4) if total else 0.0}
    if viol:
        hint = HINT
        if any(v["check"] == "cost" for v in viol):
            hint += "; расходы: python3 tools/cli.py log-cost --stage N --tokens-in X --tokens-out Y --source ide_estimated"
        raise CliError(f"Проверка проекта не пройдена: нарушений {len(viol)} "
                       f"({', '.join(k for k, v in checks.items() if v == 'fail')})",
                       hint, ok=False, checks=checks, summary=summary, violations=viol)
    return {"ok": True, "checks": checks, "summary": summary}


def sources_hint():
    return ("Загрузите материал заново под новым ID: python3 tools/cli.py ingest-source --file <путь> --id SRC-NN; "
            "слепки неизменяемы")
