"""export-pdf (C-043): Markdown -> PDF на reportlab со шрифтом DejaVu из tools/fonts/. Реестры и хеш не трогает."""
import re
from html import escape
from pathlib import Path

from .common import CliError

FONTS = Path(__file__).resolve().parents[1] / "fonts"
SANS, MONO = "DejaVuSans", "DejaVuSansMono"
HINT_INSTALL = "pip install -r requirements.txt"
HINT_MD = "python3 tools/cli.py export-pdf --md <файл.md> --out <файл.pdf>"
IMAGE = re.compile(r"!\[([^\]]*)\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)")
LIST_ITEM = re.compile(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$")
HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
RULE = re.compile(r"^\s*([-*_])(\s*\1){2,}\s*$")
TABLE_SEP = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
CODE_WRAP = 92  # символов в строке блока кода: длинные строки переносятся, а не обрезаются


def _lib():
    """Ленивый импорт: без reportlab остальные команды работают (C-043 п.2)."""
    try:
        from reportlab import platypus  # noqa: F401
    except ModuleNotFoundError:
        raise CliError("Не установлена библиотека reportlab: PDF не собрать", HINT_INSTALL)
    from reportlab.lib.fonts import addMapping
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    if SANS not in pdfmetrics.getRegisteredFontNames():
        files = {SANS: "DejaVuSans.ttf", SANS + "-Bold": "DejaVuSans-Bold.ttf",
                 SANS + "-Oblique": "DejaVuSans-Oblique.ttf", MONO: "DejaVuSansMono.ttf"}
        missing = [f for f in files.values() if not (FONTS / f).is_file()]
        if missing:
            raise CliError(f"Нет файла шрифта в tools/fonts/: {', '.join(missing)}", "Восстановите папку tools/fonts/ из репозитория")
        for name, f in files.items():
            pdfmetrics.registerFont(TTFont(name, str(FONTS / f)))
        addMapping(SANS, 0, 0, SANS)
        addMapping(SANS, 1, 0, SANS + "-Bold")
        addMapping(SANS, 0, 1, SANS + "-Oblique")
        addMapping(SANS, 1, 1, SANS + "-Bold")
        for b in (0, 1):
            for i in (0, 1):
                addMapping(MONO, b, i, MONO)


def _styles():
    from reportlab.lib.styles import ParagraphStyle
    base = ParagraphStyle("body", fontName=SANS, fontSize=10, leading=14, spaceAfter=5)
    return {
        "body": base,
        "h1": ParagraphStyle("h1", base, fontName=SANS + "-Bold", fontSize=17, leading=22, spaceBefore=8, spaceAfter=8),
        "h2": ParagraphStyle("h2", base, fontName=SANS + "-Bold", fontSize=14, leading=18, spaceBefore=10, spaceAfter=6),
        "h3": ParagraphStyle("h3", base, fontName=SANS + "-Bold", fontSize=11.5, leading=15, spaceBefore=8, spaceAfter=4),
        "cell": ParagraphStyle("cell", base, fontSize=8.5, leading=11, spaceAfter=0),
        "quote": ParagraphStyle("quote", base, leftIndent=14, textColor="#444444"),
        "code": ParagraphStyle("code", base, fontName=MONO, fontSize=8, leading=10, backColor="#f3f3f3",
                               borderPadding=4, spaceBefore=4, spaceAfter=8),
    }


def _inline(text):
    """Жирный, курсив, `код`, ссылки -> разметка reportlab. Метки [FACT] и сноски [^SRC-01] остаются текстом."""
    out = []
    for part in re.split(r"(`[^`]+`)", text):
        if len(part) > 1 and part.startswith("`") and part.endswith("`"):
            out.append(f'<font name="{MONO}">{escape(part[1:-1], quote=False)}</font>')
            continue
        s = escape(part, quote=False)
        s = re.sub(r"(?<!\[)\[([^\]^][^\]]*)\]\(([^)\s]+)\)", r"\1 (\2)", s)  # ссылка -> «текст (адрес)»
        s = re.sub(r"\*\*(.+?)\*\*|__(.+?)__", lambda m: f"<b>{m.group(1) or m.group(2)}</b>", s)
        s = re.sub(r"(?<![\w*])\*(?![\s*])(.+?)(?<![\s*])\*(?![\w*])", r"<i>\1</i>", s)
        s = re.sub(r"(?<!\w)_(?![\s_])(.+?)(?<![\s_])_(?!\w)", r"<i>\1</i>", s)
        out.append(s)
    return "".join(out)


def _para(text, style, bullet=None):
    from reportlab.platypus import Paragraph
    try:
        return Paragraph(_inline(text), style, bulletText=bullet)
    except ValueError:  # несбалансированная разметка: текст важнее оформления
        return Paragraph(escape(text, quote=False), style, bulletText=bullet)


def _cells(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|") and not line.endswith("\\|"):
        line = line[:-1]
    return [c.strip().replace("\\|", "|") for c in re.split(r"(?<!\\)\|", line)]


def _table(rows, st, width):
    from reportlab.lib import colors
    from reportlab.platypus import Table, TableStyle
    n = max(len(r) for r in rows)
    data = [[_para(c, st["cell"]) for c in r + [""] * (n - len(r))] for r in rows]
    t = Table(data, colWidths=[width / n] * n, repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eeeeee"))]))
    return t


def _image(alt, ref, base, st, width, warnings):
    from reportlab.lib import colors
    from reportlab.platypus import Image, Table, TableStyle
    path = (base / ref) if not Path(ref).is_absolute() else Path(ref)
    if path.suffix.lower() in (".png", ".jpg", ".jpeg") and path.is_file():
        try:
            img = Image(str(path))
            scale = min(1.0, width / img.drawWidth)
            img.drawWidth, img.drawHeight = img.drawWidth * scale, img.drawHeight * scale
            return img
        except Exception:  # битая картинка — как отсутствующая
            pass
    warnings.append(f"Нет картинки {ref} ({alt or 'без подписи'}): вместо неё рамка")
    box = Table([[_para(f"Скриншот: {alt or ref} — будет добавлен", st["body"])]], colWidths=[width])
    box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, colors.grey), ("TOPPADDING", (0, 0), (-1, -1), 18),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 18)]))
    return box


def _flowables(text, base, warnings, width):
    from reportlab.platypus import HRFlowable, Preformatted, Spacer
    st = _styles()
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    lines = text.splitlines()
    out, para, i = [], [], 0

    def flush():
        if para:
            out.append(_para(" ".join(para), st["body"]))
            para.clear()

    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if s.startswith("```") or s.startswith("~~~"):
            flush()
            fence, code = s[:3], []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith(fence):
                code.append(lines[i].expandtabs(4))
                i += 1
            out.append(Preformatted("\n".join(code) or " ", st["code"], maxLineLength=CODE_WRAP, newLineChars=""))
            i += 1
            continue
        if not s:
            flush()
        elif HEADING.match(s):
            flush()
            level, title = HEADING.match(s).groups()
            out.append(_para(title, st[f"h{min(len(level), 3)}"]))
        elif RULE.match(s):
            flush()
            out.append(HRFlowable(width="100%", color="#999999", spaceBefore=4, spaceAfter=6))
        elif s.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                if not TABLE_SEP.match(lines[i]):
                    rows.append(_cells(lines[i]))
                i += 1
            out += [_table(rows, st, width), Spacer(1, 6)]
            continue
        elif IMAGE.fullmatch(s):
            flush()
            alt, ref = IMAGE.fullmatch(s).groups()
            out.append(_image(alt, ref, base, st, width, warnings))
        elif LIST_ITEM.match(line):
            flush()
            indent, mark, body = LIST_ITEM.match(line).groups()
            level = 1 if len(indent.expandtabs(4)) >= 2 else 0
            while i + 1 < len(lines) and lines[i + 1].strip() and not LIST_ITEM.match(lines[i + 1]) \
                    and lines[i + 1].startswith(" ") and not lines[i + 1].strip().startswith(("|", "#", "```")):
                i += 1
                body += " " + lines[i].strip()
            bullet = "•" if mark in "-*+" else mark
            style = st["body"].clone("li", leftIndent=18 + 16 * level, bulletIndent=2 + 16 * level, spaceAfter=2,
                                     bulletFontName=SANS)
            out.append(_para(body, style, bullet))
        elif s.startswith(">"):
            flush()
            out.append(_para(s.lstrip("> "), st["quote"]))
        else:
            para.append(s)
        i += 1
    flush()
    return out


def render(md_path, pdf_path):
    """Один Markdown -> один PDF. -> предупреждения."""
    _lib()
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.platypus import SimpleDocTemplate
    try:
        text = Path(md_path).read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise CliError(f"Файл {md_path} не в кодировке UTF-8", "Пересохраните файл в UTF-8 и повторите: " + HINT_MD)
    warnings = []
    title = next((m.group(2) for m in map(HEADING.match, text.splitlines()) if m), Path(md_path).stem)
    pdf_path = Path(pdf_path)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(pdf_path), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm,
                            bottomMargin=1.8 * cm, title=title)

    def footer(canvas, d):
        canvas.setFont(SANS, 8)
        canvas.drawRightString(A4[0] - 2 * cm, 1 * cm, str(d.page))

    story = _flowables(text, Path(md_path).parent, warnings, doc.width) or [_para(" ", _styles()["body"])]
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return [f"{Path(md_path).name}: {w}" for w in warnings]


def export_file(md, out):
    """--md/--out: любой Markdown, проект не нужен."""
    if not md or not out:
        raise CliError("Для одного файла нужны оба флага --md и --out", HINT_MD)
    if not Path(md).is_file():
        raise CliError(f"Файл не найден: {md}", HINT_MD)
    if Path(out).suffix.lower() != ".pdf":
        raise CliError(f"--out должен оканчиваться на .pdf: {out}", HINT_MD)
    warnings = render(md, out)
    return {"ok": True, "files": [str(out)], "warnings": warnings}


def export_pdf(proj, md=None, out=None):
    """Без флагов: все deliverables/*.md проекта -> deliverables/pdf/<имя>.pdf."""
    if md or out:
        return export_file(md, out)
    docs = sorted(proj.path("deliverables").glob("*.md"))
    if not docs:
        raise CliError("В deliverables/ нет ни одного документа .md: собирать нечего",
                       "Сначала подготовьте документы этапов, затем: python3 tools/cli.py export-pdf")
    files, warnings = [], []
    for f in docs:
        target = proj.path(f"deliverables/pdf/{f.stem}.pdf")
        warnings += render(f, target)
        files.append(str(target.relative_to(proj.dir)))
    return {"ok": True, "files": files, "warnings": warnings}
