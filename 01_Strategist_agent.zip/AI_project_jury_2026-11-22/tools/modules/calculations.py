"""Воспроизводимые расчёты (C-008): формула разбирается через ast, eval не используется."""
import ast
import json
import math
import operator

from .common import CliError, check_id, now_iso

OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}
HINT = ('python3 tools/cli.py register-calc ... Разрешены только + - * / ** ( ), sqrt(x), числа и имена из --inputs, '
        'например --formula "a / b * 100"')
MAX_LEN = 500
MAX_POWER = 10  # C-047 п.1


def evaluate(formula, inputs):
    if not isinstance(formula, str) or not formula.strip() or len(formula) > MAX_LEN:
        raise CliError(f"Формула пустая или длиннее {MAX_LEN} символов", HINT)
    try:
        tree = ast.parse(formula, mode="eval")
    except SyntaxError:
        raise CliError(f"Формула «{formula}» не разбирается", HINT)

    def ev(n):
        if isinstance(n, ast.BinOp) and type(n.op) in OPS:
            return OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Pow):
            base, power = ev(n.left), ev(n.right)
            if abs(power) > MAX_POWER:
                raise CliError(f"В формуле «{formula}» показатель степени {power:g} больше {MAX_POWER} по модулю", HINT)
            if base < 0 and power != int(power):
                raise CliError(f"В формуле «{formula}» дробная степень отрицательного числа", HINT)
            return base ** power
        if (isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "sqrt" and len(n.args) == 1
                and not n.keywords):
            v = ev(n.args[0])
            if v < 0:
                raise CliError(f"В формуле «{formula}» корень из отрицательного числа", HINT)
            return math.sqrt(v)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            v = ev(n.operand)
            return -v if isinstance(n.op, ast.USub) else v
        if isinstance(n, ast.Constant) and type(n.value) in (int, float):
            return float(n.value)
        if isinstance(n, ast.Name):
            if n.id not in inputs:
                raise CliError(f"В формуле имя «{n.id}», которого нет в --inputs", HINT)
            return float(inputs[n.id])
        raise CliError(f"В формуле «{formula}» неразрешённая конструкция ({type(n).__name__})", HINT)

    try:
        result = ev(tree.body)
    except ZeroDivisionError:
        raise CliError(f"В формуле «{formula}» деление на ноль", 'python3 tools/cli.py register-calc --id CALC-XX --formula "..." --inputs \'{...}\' --source SRC-XX (знаменатель не ноль)')
    except (RecursionError, OverflowError):
        raise CliError("Формула слишком сложная", HINT)
    if not math.isfinite(result):
        raise CliError("Результат расчёта не конечное число", "Проверьте значения и повторите: python3 tools/cli.py register-calc ...")
    return result


def parse_inputs(raw):
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
    except json.JSONDecodeError:
        data = None
    if not isinstance(data, dict) or not all(
            isinstance(k, str) and type(v) in (int, float) and math.isfinite(v) for k, v in data.items()):
        raise CliError("--inputs должен быть JSON-объектом с числами", """python3 tools/cli.py register-calc --id CALC-01 --formula "a / b * 100" --inputs '{"a": 120, "b": 1000}' --source SRC-01""")
    return data


def get(proj, calc_id):
    return next((c for c in proj.load("calculations.json")["calculations"] if c.get("id") == calc_id), None)


def recheck(calc):
    """Пустой список, если сохранённый result воспроизводится пересчётом."""
    try:
        value = evaluate(calc.get("formula"), parse_inputs(calc.get("inputs")))
    except CliError as e:
        return [f"{calc.get('id')}: расчёт не воспроизводится ({e.error})"]
    stored = calc.get("result")
    if type(stored) not in (int, float) or not math.isclose(value, stored, rel_tol=1e-9, abs_tol=1e-12):
        return [f"{calc.get('id')}: сохранённый результат {stored} не совпадает с пересчётом {value}"]
    return []


def all_violations(proj):
    out = []
    for c in proj.load("calculations.json")["calculations"]:
        out += recheck(c)
    return out


def register_calc(proj, id, formula, inputs, source, unit=""):
    from . import sources
    check_id(id, "CALC")
    data = parse_inputs(inputs)
    if sources.get(proj, source) is None:
        raise CliError(f"Источник {source} не найден", "Сначала загрузите его: python3 tools/cli.py ingest-source --file ... --id " + source)
    result = evaluate(formula, data)
    record = {"id": id, "formula": formula, "inputs": data, "result": result, "unit": unit or "", "source_id": source}
    old = get(proj, id)
    if old:
        if {k: old.get(k) for k in record} != record:
            raise CliError(f"Расчёт {id} уже записан с другими данными", "Запишите под новым ID: python3 tools/cli.py register-calc --id CALC-02 ...")
        return {"id": id, "result": old["result"], "unit": old["unit"]}
    sources.refuse_superseded(sources.get(proj, source))
    db = proj.load("calculations.json")
    db["calculations"].append({**record, "created_at": now_iso()})
    proj.save("calculations.json", db)
    proj.commit("register-calc", record, id)
    return {"id": id, "result": result, "unit": record["unit"]}
