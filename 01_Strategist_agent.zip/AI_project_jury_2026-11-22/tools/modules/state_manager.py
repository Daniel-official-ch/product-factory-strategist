"""Проект, state.json, validation_hash (C-002, C-010 п.1), этапы и журнал операций."""
import json
import os
import re
import shutil
from pathlib import Path

from . import calculations, cost_tracker, decision_graph, decisions, evidence_registry, options, sources, verify_run
from .common import (REPO_ROOT, UPDATE_BACKUP, UPDATE_JOURNAL, CliError, canonical, now_iso, sha256_text, write_json,
                     write_text)

STAGES = {1: "Постановка задачи", 2: "Сбор материалов", 3: "Исследование и пробелы",
          4: "Варианты и возражения", 5: "Стратегия и план проверки", 6: "Сопровождение решения"}
# имя файла -> ключ в объекте хеша (C-010 п.1)
HASHED = {"evidence_db.json": "evidence_db", "options.json": "options", "sources.json": "sources",
          "calculations.json": "calculations", "decisions.json": "decisions"}
EMPTY = {"evidence_db.json": {"claims": []}, "sources.json": {"sources": []},
         "options.json": {"options": []}, "calculations.json": {"calculations": []},
         "decisions.json": {"decisions": []}, "cost_ledger.json": {"entries": []}}
BRIEF_FIELDS = ("question", "goal", "recipient", "audience", "constraints", "data")  # C-011 п.1
STRATEGY_HEADINGS = ("## Продуктовая стратегия", "## Коммуникационная стратегия", "## План проверки")
STRATEGY_H3 = ("Аудитория и её задача", "Альтернативы", "Выбранное направление", "Осознанные отказы",
               "Польза, затраты и доходы", "Аудитория и ситуация", "Барьер понимания или выбора",
               "Ключевое сообщение и его подтверждение", "Роль каналов", "Обещания соответствуют продукту",
               "Ожидаемое изменение", "С чем сравниваем", "Срок наблюдения", "Нежелательные последствия",
               "Kill-criteria")  # C-011 п.4
NEXT_ACTION = {
    1: "Заполнить бриф (set-brief: вопрос, цель, получатель, аудитория, ограничения, данные), показать человеку, "
       "записать подтверждение record-decision --kind brief, затем validate-step --stage 1",
    2: "Собрать материалы (ingest-source, ingest-url, add-user-input), затем validate-step --stage 2",
    3: "Записать вопросы исследования (add-question), утверждения с цитатами (register-claim) "
       "и пробелы (add-gap), затем validate-step --stage 3",
    4: "Сформировать не меньше 3 вариантов, включая keep_as_is и close_direction (register-option), "
       "найти возражения через субагента red-team, записать выбор человека record-decision --kind option --option OPT-XX, "
       "затем validate-step --stage 4",
    5: "Написать deliverables/04_product_and_comm_strategy.md (продуктовая, коммуникационная стратегия, "
       "план проверки), проверить verify-run, показать человеку, записать приёмку record-decision --kind strategy, "
       "затем validate-step --stage 5",
    6: "Записать решение человека (record-decision --kind option) и журнал deliverables/05_decision_log.md; "
       "при новых данных — revoke-claim и пересмотр вариантов с needs_revision",
}
HINT_ACCEPT = 'python3 tools/cli.py accept-edit --reason "..."'
HINT_RESUME_UPDATE = "Повторите ту же команду ingest-update с теми же аргументами: она доведёт запись до конца"


def resolve_workspace(value=None):
    return Path(value or os.environ.get("STRATEGIST_WORKSPACE") or REPO_ROOT / "workspace")


def hook_project(workspace=None):
    """C-015: проект для хука Stop: STRATEGIST_PROJECT -> <workspace>/.active_project -> current_project."""
    if os.environ.get("STRATEGIST_PROJECT"):
        return os.environ["STRATEGIST_PROJECT"].strip()
    try:
        name = (resolve_workspace(workspace) / ".active_project").read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        name = ""
    return name or "current_project"


def set_active_project(workspace, name):
    path = resolve_workspace(workspace) / ".active_project"
    try:
        if not path.is_file() or path.read_text(encoding="utf-8").strip() != name:
            write_text(path, name + "\n")
    except OSError:
        pass  # активный проект — удобство для хука, не повод ронять команду


class Project:
    def __init__(self, workspace, name):
        if not name or not re.fullmatch(r"[\w-][\w.-]*", name) or ".." in name:
            raise CliError(f"Недопустимое имя проекта «{name}»: только буквы, цифры, «-», «_», «.»",
                           "python3 tools/cli.py --project current_project status")
        self.name = name
        self.dir = resolve_workspace(workspace) / name

    def path(self, rel):
        return self.dir / rel

    def exists(self):
        return self.path("state.json").is_file()

    def require(self):
        if not self.exists():
            raise CliError(f"Проект «{self.name}» не найден в {self.dir.parent}",
                           f'python3 tools/cli.py --project {self.name} init --name "Название проекта"')

    def load(self, fname, code=1):
        try:
            return json.loads(self.path(fname).read_text(encoding="utf-8"))
        except FileNotFoundError:
            data = EMPTY.get(fname)
            if data is not None and fname not in HASHED:
                return json.loads(json.dumps(data))
            raise CliError(f"Нет файла проекта {fname}", HINT_ACCEPT, code=code)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise CliError(f"Файл {fname} повреждён (не JSON: {e.msg if hasattr(e, 'msg') else e})",
                           "Исправьте JSON вручную, затем: " + HINT_ACCEPT, code=code)

    def save(self, fname, data):
        write_json(self.path(fname), data)

    def compute_hash(self, state, code=1, registries=None):
        """registries — {имя файла: данные} вместо файлов на диске (сверка копии реестров при откате ingest-update)."""
        st = {k: v for k, v in state.items() if k != "validation_hash"}
        obj = {"state": st, **{key: registries[f] if registries else self.load(f, code) for f, key in HASHED.items()}}
        return sha256_text(canonical(obj))

    def drop_update_journal(self):
        self.path(UPDATE_JOURNAL).unlink(missing_ok=True)
        shutil.rmtree(self.path(UPDATE_BACKUP), ignore_errors=True)

    def verify(self):
        """Ручная правка любого файла из хеша -> exit 3."""
        state = self.load("state.json", code=3)
        if state.get("validation_hash") != self.compute_hash(state, code=3):
            if self.path(UPDATE_JOURNAL).is_file():  # C-038 п.1
                raise CliError("Команда ingest-update оборвалась посреди записи. Работа остановлена, пока запись не доведена.",
                               HINT_RESUME_UPDATE, code=3)
            raise CliError("Файлы проекта изменены в обход CLI (validation_hash не совпадает) или предыдущая "
                           "команда оборвалась посреди записи. Работа остановлена, пока изменения не проверят.",
                           HINT_ACCEPT, code=3)
        return state

    def commit(self, op, args, result_id, state=None, extra=None):
        """Журнал операции + новый хеш. Вызывать только если что-то реально изменилось. extra — открытые поля записи."""
        state = state if state is not None else self.load("state.json")
        state.setdefault("completed_operations_log", []).append(
            {"op": op, "args_sha256": sha256_text(canonical(args)), "result_id": result_id, "ts": now_iso(), **(extra or {})})
        state["validation_hash"] = self.compute_hash(state)
        self.save("state.json", state)
        decision_graph.write(self)  # C-033: производный файл, вне HASHED


# ------------------------------------------------------------------ команды

def init(proj, name, question=None):
    if proj.exists():
        st = proj.load("state.json")
        return {"project": proj.name, "stage": st.get("stage", 1)}
    for d in ("raw_materials", "deliverables"):
        proj.path(d).mkdir(parents=True, exist_ok=True)
    for fname, data in EMPTY.items():
        if not proj.path(fname).exists():
            proj.save(fname, data)
    state = {"project": proj.name, "name": name, "stage": 1,
             "stage_status": {str(i): ("in_progress" if i == 1 else "todo") for i in STAGES},
             "pending_human_decision": None, "brief": {f: "" for f in BRIEF_FIELDS}, "brief_revision": 0,
             "research_questions": [], "gaps": [],
             "completed_operations_log": []}
    if question:
        state["brief"]["question"] = question
    proj.commit("init", {"name": name, "question": question}, proj.name, state)
    _write_handoff(proj, _summary(proj, proj.load("state.json")))
    return {"project": proj.name, "stage": 1}


def status(proj):
    state = proj.load("state.json")
    out = _summary(proj, state)
    try:
        intact = state.get("validation_hash") == proj.compute_hash(state)
    except CliError:
        intact = False
    out["integrity"] = "ok" if intact else "manual_edit_detected"
    if not intact:
        out["warning"] = ("Файлы проекта изменены в обход CLI: изменяющие команды и resume остановлены (exit 3). "
                          "Проверьте правку и примите её: " + HINT_ACCEPT)
        out["next_action"] = "Принять или откатить ручную правку: " + HINT_ACCEPT
        if proj.path(UPDATE_JOURNAL).is_file():  # C-038 п.1: это обрыв, а не правка
            out["warning"] = "Команда ingest-update оборвалась посреди записи."
            out["next_action"] = HINT_RESUME_UPDATE
    return out


def resume(proj):
    out = _summary(proj, proj.load("state.json"))
    _write_handoff(proj, out)
    return out


def set_brief(proj, **fields):
    given = {k: v for k, v in fields.items() if v is not None}
    if not given:
        raise CliError("Не передано ни одного поля брифа",
                       'python3 tools/cli.py set-brief --question "..." --goal "..." --recipient "..." '
                       '--audience "..." --constraints "..." --data "..."')
    state = proj.load("state.json")
    brief = state.setdefault("brief", {})
    changed = [k for k, v in given.items() if brief.get(k) != v]
    if changed:
        # бриф уже задавали через set-brief -> это пересмотр (C-011 п.1); --question из init не в счёт
        update = any(r.get("op") in ("set-brief", "brief_updated") for r in state.get("completed_operations_log", []))
        brief.update(given)
        if update:
            state["brief_revision"] = state.get("brief_revision", 0) + 1
        proj.commit("brief_updated" if update else "set-brief", given, "brief", state)
    return {"ok": True, "brief": brief}


def add_question(proj, text, why):
    if not text.strip() or not why.strip():
        raise CliError("У вопроса исследования нужны текст и объяснение, как ответ может изменить решение",
                       'python3 tools/cli.py add-question --text "что узнать" --why "что изменит ответ"')
    return _append_item(proj, "research_questions", "RQ", "add-question", {"text": text, "why": why})


def add_gap(proj, text, why, question=None):
    if not text.strip() or not why.strip():
        raise CliError("Пробел должен иметь текст и объяснение, зачем он важен",
                       'python3 tools/cli.py add-gap --text "чего не знаем" --why "на что влияет"')
    item = {"text": text, "why": why}
    if question:
        rqs = {q["id"] for q in proj.load("state.json").get("research_questions") or []}
        if question not in rqs:
            raise CliError(f"Вопрос исследования {question} не найден",
                           'python3 tools/cli.py add-question --text "..." --why "..."')
        item["question"] = question
    return _append_item(proj, "gaps", "GAP", "add-gap", item)


def _append_item(proj, key, prefix, op, item):
    state = proj.load("state.json")
    items = state.setdefault(key, [])
    for it in items:
        if all(it.get(k) == v for k, v in item.items()) and set(it) - {"id", "created_at"} == set(item):
            return {"id": it["id"]}
    iid = f"{prefix}-{len(items) + 1:03d}"
    items.append({"id": iid, **item, "created_at": now_iso()})
    proj.commit(op, item, iid, state)
    return {"id": iid}


def set_pending(proj, text):
    if not text.strip():
        raise CliError("Пустой текст решения", 'python3 tools/cli.py set-pending --text "Что выбрать человеку"')
    return _set_pending(proj, text)


def clear_pending(proj):
    return _set_pending(proj, None)


def _set_pending(proj, value):
    state = proj.load("state.json")
    if state.get("pending_human_decision") != value:
        state["pending_human_decision"] = value
        proj.commit("set-pending" if value else "clear-pending", {"text": value}, "pending", state)
    return {"pending_human_decision": value}


def stage_problems(proj, stage, state):
    if stage == 1:
        brief = state.get("brief") or {}
        miss = [f for f in BRIEF_FIELDS if not str(brief.get(f) or "").strip()]
        return [f"В брифе не заполнено поле «{f}» (set-brief --{f})" for f in miss] + decisions.human_problems(proj, "brief")
    if stage == 2:
        return [] if proj.load("sources.json")["sources"] else ["Нет ни одного источника (ingest-source, ingest-url, add-user-input)"]
    if stage == 3:
        probs = [] if state.get("research_questions") else ["Не записан ни один вопрос исследования (add-question)"]
        if not any(c.get("status") == "active" for c in proj.load("evidence_db.json")["claims"]):
            probs.append("Нет ни одного активного утверждения (register-claim)")
        if not state.get("gaps"):
            probs.append("Не записан ни один пробел в знаниях (add-gap)")
        return probs
    if stage == 4:
        return options.stage4_problems(proj) + decisions.human_problems(proj, "option")
    if stage == 5:
        return strategy_problems(proj)
    return decisions.stage6_problems(proj)


def strategy_problems(proj):
    """C-011 п.4, C-027: три H2, 15 заполненных H3, все CLM-ссылки — активные утверждения, есть приёмка человека."""
    f = proj.path("deliverables/04_product_and_comm_strategy.md")
    if not f.is_file():
        return ["Нет файла deliverables/04_product_and_comm_strategy.md"]
    text = f.read_text(encoding="utf-8")
    lines = [ln.rstrip() for ln in re.sub(r"<!--.*?-->", "", text, flags=re.S).splitlines()]  # C-012
    probs = [f"В 04_product_and_comm_strategy.md нет раздела «{h}»" for h in STRATEGY_HEADINGS if h not in lines]
    sections, cur = {}, None
    for ln in lines:
        if ln.startswith("#"):
            cur = ln.lstrip("#").strip() if ln.startswith("### ") else None
            if cur is not None:
                sections.setdefault(cur, [])
        elif cur is not None:
            sections[cur].append(ln)
    for h in STRATEGY_H3:
        filled = [ln for ln in sections.get(h, []) if ln.strip() and not re.fullmatch(r"<[^>]*>", ln.strip())]
        if h not in sections:
            probs.append(f"В 04 нет подраздела «### {h}»")
        elif not filled:  # C-012: только строки-заглушки <...> = не заполнено
            probs.append(f"Подраздел «### {h}» в 04 не заполнен")
    claims = {c["id"]: c for c in proj.load("evidence_db.json")["claims"]}
    active = {cid for cid, c in claims.items() if c.get("status") == "active"}
    for ref in sorted(verify_run.live_refs(text, claims) - active):  # та же логика C-026, что в verify-run
        probs.append(f"В 04 ссылка на {ref}, но такого активного утверждения нет")
    if not any(d.get("kind") == "strategy" for d in proj.load("decisions.json")["decisions"]):  # C-027
        probs.append("Стратегия не принята человеком (record-decision --kind strategy)")
    return probs


def validate_step(proj, stage):
    if stage not in STAGES:
        raise CliError(f"Этапа {stage} нет: этапы 1–6", "python3 tools/cli.py validate-step --stage 1")
    state = proj.load("state.json")
    probs = stage_problems(proj, stage, state)
    if probs:
        raise CliError(f"Этап {stage} «{STAGES[stage]}» не готов: " + "; ".join(probs),
                       "Исправьте перечисленное и повторите: python3 tools/cli.py validate-step "
                       f"--stage {stage}", violations=probs)
    changed = state["stage_status"].get(str(stage)) != "done"
    state["stage_status"][str(stage)] = "done"
    if stage >= state.get("stage", 1):  # C-010 п.2: назад не откатываем
        new_stage = min(stage + 1, 6)
        changed |= state.get("stage") != new_stage
        state["stage"] = new_stage
        if state["stage_status"].get(str(new_stage)) == "todo":
            state["stage_status"][str(new_stage)] = "in_progress"
    if changed:
        proj.commit("validate-step", {"stage": stage}, f"stage-{stage}", state)
    return {"stage": stage, "ok": True}


def invariant_violations(proj):
    viol = sources.all_violations(proj)  # C-015: слепки неизменяемы, их правку не «принять»
    viol += evidence_registry.all_violations(proj)
    viol += calculations.all_violations(proj)
    viol += options.all_violations(proj)
    viol += decisions.all_violations(proj)
    return viol


def accept_edit(proj, reason):
    if not reason.strip():
        raise CliError("Нужна причина правки", HINT_ACCEPT)
    state = proj.load("state.json")
    for fname in HASHED:
        proj.load(fname)  # битый JSON -> exit 1 с понятной ошибкой
    viol = invariant_violations(proj)
    if viol:
        hint = "Исправьте нарушения в файлах проекта и повторите: " + HINT_ACCEPT
        if any("слепок" in v.lower() for v in viol):
            hint = ("Слепок источника не принимается после правки: загрузите материал заново под новым ID "
                    "(python3 tools/cli.py ingest-source --file <путь> --id SRC-NN), верните исходный слепок "
                    "или отзовите зависящие утверждения; затем " + HINT_ACCEPT)
        raise CliError(f"Ручная правка не принята, нарушений: {len(viol)}. " + "; ".join(viol[:5]), hint,
                       violations=viol)
    prev = state.get("validation_hash")
    proj.drop_update_journal()  # C-039 п.3: человек принял состояние как есть, недописанной замены больше нет
    if prev == proj.compute_hash(state):
        return {"ok": True, "validation_hash": prev}
    proj.commit("manual_edit_accepted", {"reason": reason, "previous_hash": prev}, "state", state)
    return {"ok": True, "validation_hash": proj.load("state.json")["validation_hash"]}


# ------------------------------------------------------------------ сводка

def _summary(proj, state):
    stage = state.get("stage", 1)
    st = state.get("stage_status") or {}
    claims = proj.load("evidence_db.json")["claims"]
    opts = proj.load("options.json")["options"]
    pending = state.get("pending_human_decision")
    revise = [c["id"] for c in claims if c.get("needs_revision") and c.get("status") == "active"]
    revise += [o["id"] for o in opts if o.get("needs_revision")]
    stale_decisions = decisions.stale(proj)  # C-045: заменённые новым решением не напоминаем
    revise += [d["id"] for d in stale_decisions]  # C-031 п.2
    open_items = revise
    next_action = NEXT_ACTION.get(stage, "")
    if stage == 6:
        if st.get("6") == "done":
            next_action = "Сопровождение: при новых данных — /update (revoke-claim, пересмотр вариантов с needs_revision)"
        elif not decisions.stage6_problems(proj):
            next_action = "Всё для этапа 6 есть: validate-step --stage 6"
        elif any(d.get("kind") == "option" for d in proj.load("decisions.json")["decisions"]):
            next_action = "Написать deliverables/05_decision_log.md, затем validate-step --stage 6"
    if pending:
        next_action = f"Дождаться решения человека: {pending}"
    elif open_items:
        next_action = "Пересмотреть записи, затронутые отзывом или заменой: " + ", ".join(open_items)
    return {
        "project": proj.name, "name": state.get("name"), "stage": stage, "stage_title": STAGES.get(stage, ""),
        "done": [int(k) for k, v in sorted(st.items(), key=lambda kv: int(kv[0])) if v == "done"],
        "next_action": next_action, "pending_human_decision": pending,
        "counts": {"sources": len(proj.load("sources.json")["sources"]),
                   "claims_active": sum(1 for c in claims if c.get("status") == "active"),
                   "options": len(opts), "gaps": len(state.get("gaps") or []),
                   "research_questions": len(state.get("research_questions") or []),
                   "decisions": len(proj.load("decisions.json")["decisions"])},
        "needs_revision": revise,
        "stale_decisions": [{"id": d["id"], "stale_claims": d.get("stale_claims") or []} for d in stale_decisions],
        "decision_history": decisions.history(proj),
        "cost": cost_tracker.summary(proj),
    }


def _review_lines(s, replaced):
    """C-036 п.2: у решения названы устаревшие основания; у заменённых — чем заменены."""
    stale = {d["id"]: d["stale_claims"] for d in s["stale_decisions"]}
    plain = [x for x in s["needs_revision"] if x not in stale]
    lines = [f"- {', '.join(plain)}"] if plain else []
    name = lambda cid: f"{cid} (заменено источником {replaced[cid]})" if cid in replaced else cid
    lines += [f"- {did}: устаревшие основания: {', '.join(map(name, claims))}" for did, claims in stale.items()]
    return lines or ["- Ничего."]


def _write_handoff(proj, s):
    total = s["cost"]["total"]
    replaced = {c["id"]: c.get("superseded_by") for c in proj.load("evidence_db.json")["claims"] if c.get("status") == "superseded"}
    lines = [
        f"# Точка продолжения: {s['name'] or s['project']}", "",
        f"Этап {s['stage']} из 6: {s['stage_title']}.", "",
        "## Сделано",
        *([f"- Этап {n}: {STAGES[n]}" for n in s["done"]] or ["- Пока ни один этап не закрыт."]),
        f"- Источников: {s['counts']['sources']}, активных утверждений: {s['counts']['claims_active']}, "
        f"вариантов: {s['counts']['options']}, пробелов: {s['counts']['gaps']}, решений: {s['counts']['decisions']}.",
        "", "## Что дальше", f"- {s['next_action']}", "",
        "## Ждёт решения человека", f"- {s['pending_human_decision'] or 'Ничего.'}", "",
        "## Требует пересмотра", *_review_lines(s, replaced), "",
        "## Расход токенов (cost_ledger.json)",
        f"- Всего: вход {total['tokens_in']}, выход {total['tokens_out']}, из кэша {total['cache_read']}, "
        f"стоимость ${total['usd']}.",
        *[f"- Этап {k}: вход {v['tokens_in']}, выход {v['tokens_out']}, из кэша {v['cache_read']}, ${v['usd']}."
          for k, v in s["cost"]["by_stage"].items()],
        "", "Продолжить: `/resume` или `python3 tools/cli.py resume`.", "",
    ]
    write_text(proj.path("HANDOFF_CONTEXT.md"), "\n".join(lines))
