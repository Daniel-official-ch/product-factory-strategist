"""build-rules (C-005): prompts_src/ -> CLAUDE.md (только блок между маркерами), AGENTS.md, .claude/, .cursor/.

Пишет ровно перечисленные файлы. Агентов и команды разработки (.claude/agents/*, team.md) не трогает.
"""
from pathlib import Path

from .common import REPO_ROOT, CliError, write_text

BEGIN = "<!-- BEGIN product-rules (generated) -->"
END = "<!-- END product-rules -->"
AGENTS = ("reader", "red-team", "synth-resp")  # C-014: имя субагента — строчные буквы и дефисы
COMMANDS = ("start", "resume", "options", "strategy", "update")
RULES = (("00_orchestrator.md", "00_orchestrator.mdc", "Оркестратор: 6 этапов и точки остановки для человека"),
         ("01_security_and_epistemics.md", "01_security.mdc", "Безопасность и достоверность: метки, происхождение, цитаты"))
HINT = "Создайте недостающие файлы в prompts_src/ (контракт C-005) и повторите: python3 tools/cli.py build-rules"


def _note(src):
    return f"<!-- Сгенерировано build-rules из {src}. Правьте исходник и запустите: python3 tools/cli.py build-rules -->"


def _split(text, rel, required=()):
    """-> (frontmatter dict, сырой текст frontmatter, тело)."""
    if not text.startswith("---\n"):
        if required:
            raise CliError(f"{rel}: нет YAML-frontmatter (нужны поля {', '.join(required)})", HINT)
        return {}, "", text
    end = text.find("\n---\n", 4)
    if end < 0:
        raise CliError(f"{rel}: frontmatter не закрыт строкой ---", HINT)
    raw = text[4:end + 1]
    import yaml  # лениво: без pip install остальные команды работают
    try:
        fm = yaml.safe_load(raw) or {}
    except yaml.YAMLError as e:
        raise CliError(f"{rel}: frontmatter не разбирается как YAML ({e})", HINT)
    missing = [k for k in required if not str(fm.get(k) or "").strip()] if isinstance(fm, dict) else list(required)
    if missing:
        raise CliError(f"{rel}: во frontmatter нет полей {', '.join(missing)}", HINT)
    return fm, raw, text[end + 5:]


def _mdc(description, always, body):
    desc = " ".join(str(description).split()).replace('"', "'")
    return f'---\ndescription: "{desc}"\nglobs:\nalwaysApply: {"true" if always else "false"}\n---\n\n{body.strip()}\n'


def _merge_claude(existing, rules):
    block = f"{BEGIN}\n{rules.rstrip()}\n{END}"
    nb, ne = existing.count(BEGIN), existing.count(END)
    if nb == 0 and ne == 0:
        return (existing.rstrip("\n") + "\n\n" + block + "\n") if existing.strip() else block + "\n"
    i, j = existing.find(BEGIN), existing.find(END)
    if nb != 1 or ne != 1 or j < i:
        raise CliError("В CLAUDE.md маркеры блока правил повреждены (должна быть ровно одна пара BEGIN…END)",
                       f"Исправьте маркеры вручную: {BEGIN} … {END}, затем повторите build-rules")
    return existing[:i] + block + existing[j + len(END):]


def plan(root):
    src = root / "prompts_src"
    names = [r[0] for r in RULES] + [f"agents/{a}.md" for a in AGENTS] + [f"commands/{c}.md" for c in COMMANDS]
    missing = [f"prompts_src/{n}" for n in names if not (src / n).is_file()]
    if missing:
        raise CliError("Нет исходников правил: " + ", ".join(missing), HINT, violations=missing)
    read = {n: (src / n).read_text(encoding="utf-8").replace("\r\n", "\n") for n in names}
    files = {}
    bodies = [_split(read[n], f"prompts_src/{n}")[2].strip() for n, _, _ in RULES]
    rules = "\n\n".join(bodies) + "\n"
    claude = root / "CLAUDE.md"
    files["CLAUDE.md"] = _merge_claude(claude.read_text(encoding="utf-8") if claude.is_file() else "", rules)
    files["AGENTS.md"] = f"{_note('prompts_src/00_orchestrator.md и 01_security_and_epistemics.md')}\n\n{rules}"
    for (name, mdc, desc), body in zip(RULES, bodies):
        files[f".cursor/rules/{mdc}"] = _mdc(desc, True, body)
    for kind, items, required in (("agents", AGENTS, ("name", "description", "tools", "model")),
                                  ("commands", COMMANDS, ("name", "description"))):
        for item in items:
            rel = f"prompts_src/{kind}/{item}.md"
            fm, raw, body = _split(read[f"{kind}/{item}.md"], rel, required)
            if str(fm.get("name")) != item:  # C-014: name совпадает с именем файла
                raise CliError(f"{rel}: во frontmatter name: {fm.get('name')}, а должно быть name: {item}", HINT)
            files[f".claude/{kind}/{item}.md"] = f"---\n{raw}---\n{_note(rel)}\n\n{body.strip()}\n"
            if kind == "commands":
                files[f".cursor/rules/cmd_{item}.mdc"] = _mdc(fm["description"], False, body)
    return files


def build(check=False, root=None):
    root = Path(root or REPO_ROOT)
    files = plan(root)
    stale = [rel for rel, text in files.items()
             if not (root / rel).is_file() or (root / rel).read_text(encoding="utf-8") != text]
    if check:
        if stale:
            raise CliError("Сгенерированные правила устарели: " + ", ".join(stale),
                           "python3 tools/cli.py build-rules", violations=stale)
        return {"ok": True, "stale": []}
    for rel in stale:
        write_text(root / rel, files[rel])
    return {"ok": True, "files": sorted(files), "changed": stale}
