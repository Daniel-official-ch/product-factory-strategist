"""Простой рендер шаблонов (C-006 + поправка 1): {{ key }}, {{#each list}}…{{/each}}, {{#if key}}…{{/if}}, {{ this }}.

Один проход по дереву: значения из данных повторно как шаблон не разбираются,
поэтому «{{ ... }}» в тексте варианта не подставляется.
"""
import re
from datetime import date

from .common import REPO_ROOT, CliError, write_text

TEMPLATES = REPO_ROOT / "knowledge_base" / "templates"
TAG = re.compile(r"\{\{\s*(#each|#if|/each|/if)?\s*([\w.]*)\s*\}\}")
STANDALONE = re.compile(r"(?m)^[ \t]*(\{\{\s*[#/](?:each|if)\b[^}]*\}\})[ \t]*\r?\n")
TYPE_LABEL = {"keep_as_is": "Оставить как есть", "close_direction": "Закрыть направление", "custom": "Вариант"}

FALLBACK_03 = """# 03. Варианты и возражения

## Коротко

- Проект: {{ project_name }}. Рассмотрено вариантов: {{ options_count }}, среди них обязательно «Оставить как есть» и «Закрыть направление».
- У каждого варианта есть сильные возражения, они записаны до рекомендации.
- От вас: выбрать вариант или попросить пересмотреть возражения.

{{#each options}}
## {{ id }}. {{ type_label }}: {{ title }}

{{ summary }}

**Сильные возражения**

{{#each objections}}
- {{ this }}
{{/each}}

{{#if claim_items}}
**Опирается на утверждения**

{{#each claim_items}}
- {{ type_tag }} {{ text }} ({{ id }}){{#if source_id}}[^{{ source_id }}]{{/if}}
{{/each}}
{{/if}}

{{#if costs}}
**Затраты:** {{ costs }}
{{/if}}

{{#if risks}}
**Риски:** {{ risks }}
{{/if}}

---

{{/each}}
{{#each sources_used}}
[^{{ id }}]: {{ title }}{{#if url}} — {{ url }}{{/if}}
{{/each}}
"""


def _parse(tokens, i, until=None):
    nodes = []
    while i < len(tokens):
        kind, val = tokens[i]
        if kind in ("/each", "/if"):
            if until != kind:
                raise CliError(f"В шаблоне лишний {{{{{kind}}}}}", "Исправьте парность блоков в knowledge_base/templates/ и повторите: python3 tools/cli.py register-option ...")
            return nodes, i + 1
        if kind in ("#each", "#if"):
            body, i = _parse(tokens, i + 1, "/" + kind[1:])
            nodes.append((kind, val, body))
            continue
        nodes.append((kind, val, None))
        i += 1
    if until:
        raise CliError(f"В шаблоне не закрыт блок {until}", "Исправьте парность блоков в knowledge_base/templates/ и повторите: python3 tools/cli.py register-option ...")
    return nodes, i


def _tokens(template):
    template = STANDALONE.sub(r"\1", template)  # строка из одного блочного тега не оставляет пустой строки
    out, pos = [], 0
    for m in TAG.finditer(template):
        out.append(("text", template[pos:m.start()]))
        out.append((m.group(1) or "var", m.group(2)))
        pos = m.end()
    out.append(("text", template[pos:]))
    return out


def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        return ", ".join(str(x) for x in v)
    return str(v)


def _render(nodes, scopes):
    def look(key):
        for s in reversed(scopes):
            if isinstance(s, dict) and key in s:
                return s[key]
        return None

    out = []
    for kind, val, body in nodes:
        if kind == "text":
            out.append(val)
        elif kind == "var":
            out.append(_fmt(look(val)))
        elif kind == "#if":
            if look(val) not in (None, "", [], {}, False, 0):
                out.append(_render(body, scopes))
        else:  # #each
            items = look(val)
            for item in items if isinstance(items, list) else []:
                out.append(_render(body, scopes + [item if isinstance(item, dict) else {"this": item}]))
    return "".join(out)


def render(template, ctx):
    nodes, _ = _parse(_tokens(template), 0)
    return re.sub(r"\n{3,}", "\n\n", _render(nodes, [ctx])).strip() + "\n"


def load_template(name, fallback):
    p = TEMPLATES / name
    return p.read_text(encoding="utf-8") if p.is_file() else fallback


def render_options(proj):
    state = proj.load("state.json")
    opts = proj.load("options.json")["options"]
    claims = {c.get("id"): c for c in proj.load("evidence_db.json")["claims"]}
    srcs = {s.get("id"): s for s in proj.load("sources.json")["sources"]}
    used, items = [], []
    for o in opts:
        # C-018: тип, текст и источник каждого активного утверждения; отозванные не выводятся
        ci = [{"id": cid, "type": c.get("type"), "type_tag": f"[{c.get('type')}]" + (" [DEMO-DATA]" if c.get("demo_data") and c.get("type") == "FACT" else ""), "text": c.get("text", ""),
               "source_id": c.get("source_id") or "", "status": c.get("status")}
              for cid in o.get("claims") or [] if (c := claims.get(cid)) and c.get("status") == "active"]
        used += [x["source_id"] for x in ci if x["source_id"]]
        items.append({**o, "type_label": TYPE_LABEL.get(o.get("type"), "Вариант"), "claim_items": ci,
                      "title": o.get("title", "") + (" (требует пересмотра)" if o.get("needs_revision") else "")})
    sources_used = [{"id": sid, "title": srcs.get(sid, {}).get("title") or sid, "url": srcs.get(sid, {}).get("url") or ""}
                    for sid in dict.fromkeys(used)]  # каждая сноска определяется один раз
    ctx = {"project_name": state.get("name") or proj.name, "options_count": len(opts),
           "generated_at": date.today().isoformat(), "question": (state.get("brief") or {}).get("question", ""),
           "options": items, "sources_used": sources_used}
    md = render(load_template("03_options_and_objections.md", FALLBACK_03), ctx)
    write_text(proj.path("deliverables/03_options_and_objections.md"), md)
    return "deliverables/03_options_and_objections.md"
