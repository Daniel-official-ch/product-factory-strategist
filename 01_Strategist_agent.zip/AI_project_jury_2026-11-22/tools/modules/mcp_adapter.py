"""C-028: инструменты MCP из argparse-парсера cli.py. Вызов — тем же cli.py подпроцессом, без оболочки."""
import argparse
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

CLI_PATH = Path(__file__).resolve().parents[1] / "cli.py"
HIDDEN = {"accept-edit", "build-rules", "parse-transcript", "redact-source"}  # C-028, C-046 п.3: только человек или служебные
GLOBAL_DESTS = {"help", "workspace", "project"}
PATH_PARAMS = {"file", "from_file", "md", "out"}  # C-030 п.3: через MCP файлы выбирает модель, а не человек
# Запас поверх таймаута сети (30 с) и ожидания блокировки проекта (30 с)
CALL_TIMEOUT = 120
PROJECT_SCHEMA = {"type": "string", "description": "Папка проекта; по умолчанию current_project"}


def _commands():
    """{имя команды: подпарсер}. cli.py грузим по пути: и tools/, и корень репозитория могут быть не в sys.path."""
    spec = importlib.util.spec_from_file_location("strategist_cli", CLI_PATH)
    cli = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cli)
    sub = next(a for a in cli.build_parser()._actions if isinstance(a, argparse._SubParsersAction))
    return {name: sp for name, sp in sub.choices.items() if name not in HIDDEN}


def _params(parser):
    return {a.dest: a for a in parser._actions if a.dest not in GLOBAL_DESTS}


def _json_type(action):
    if isinstance(action, argparse._StoreTrueAction):
        return "boolean"
    return "integer" if action.type is int else "string"


def list_tools():
    tools = []
    for name, parser in _commands().items():
        params = _params(parser)
        schema = {"type": "object",
                  "properties": {"project": PROJECT_SCHEMA, **{d: {"type": _json_type(a)} for d, a in params.items()}},
                  "required": [d for d, a in params.items() if a.required]}
        tools.append({"name": name.replace("-", "_"), "description": parser.description, "parameters": schema})
    return tools


def _fail(error, hint="Список инструментов и параметров: tools/list", exit_code=1, **extra):
    return {"ok": False, "exit_code": exit_code, "error": error, "hint": hint, "violations": [], **extra}


def _type_ok(value, kind):
    if kind == "boolean":
        return isinstance(value, bool)
    if kind == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    return isinstance(value, str)


def _path_allowed(value):
    roots = [CLI_PATH.parents[1], *([Path(os.environ["STRATEGIST_ALLOWED_DIR"])] if os.environ.get("STRATEGIST_ALLOWED_DIR") else [])]
    try:
        target = Path(value).resolve()  # resolve раскрывает симлинки: ссылка наружу не пройдёт
        return any(target.is_relative_to(root.resolve()) for root in roots)
    except (OSError, ValueError, RuntimeError):  # нулевой байт, петля симлинков
        return False


def _argv(command, parser, args):
    """-> (argv, None) или (None, ошибка). Форма --flag=value: значение «--force» не станет флагом."""
    params = _params(parser)
    argv, project = [], args.get("project")
    for key, value in args.items():
        if key != "project" and key not in params:
            return None, _fail(f"Неизвестный параметр «{key}» у инструмента {command.replace('-', '_')}")
        if value is None:  # клиенты MCP шлют null вместо пропущенного необязательного параметра
            continue
        kind = "string" if key == "project" else _json_type(params[key])
        if not _type_ok(value, kind):
            return None, _fail(f"Параметр «{key}» должен иметь тип {kind}")
        if key == "project":
            if not value.strip():
                return None, _fail("Параметр «project» не может быть пустым", "Не передавайте project или укажите имя папки проекта")
            continue
        if key in PATH_PARAMS and not _path_allowed(value):
            return None, _fail(f"Путь в параметре «{key}» вне разрешённых папок",
                               "Положите файл в папку репозитория или укажите его папку в STRATEGIST_ALLOWED_DIR")
        flag = params[key].option_strings[0]
        if kind != "boolean":
            argv.append(f"{flag}={value}")
        elif value:
            argv.append(flag)
    return [*([f"--project={project}"] if project is not None else []), command, *argv], None


def call_tool(name, args=None):
    args = {} if args is None else args
    if not isinstance(args, dict):
        return _fail("Аргументы инструмента должны быть объектом")
    commands = _commands()
    command = next((c for c in commands if c.replace("-", "_") == name), None)
    if command is None:
        return _fail(f"Неизвестный инструмент «{name}»")
    argv, error = _argv(command, commands[command], args)
    if error:
        return error
    try:
        done = subprocess.run([sys.executable, str(CLI_PATH), *argv], capture_output=True, text=True, encoding="utf-8",
                              env={**os.environ, "PYTHONUTF8": "1"}, timeout=CALL_TIMEOUT)
    except subprocess.TimeoutExpired:
        return _fail(f"Команда не завершилась за {CALL_TIMEOUT} с", "Повторите вызов: все команды идемпотентны")
    except (OSError, ValueError):  # например, нулевой байт в значении
        return _fail("Не удалось запустить команду с такими значениями", "Проверьте значения параметров")
    return _result(done)


def _result(done):
    try:
        payload = json.loads(done.stdout if done.returncode == 0 else done.stderr)
    except ValueError:
        return _fail("Команда вернула ответ не в формате JSON", "Проверьте установку: pip install -r requirements.txt",
                     exit_code=done.returncode or 1)
    if done.returncode == 0:
        return {"ok": True, "exit_code": 0, "data": payload}
    return {"violations": [], **payload, "ok": False, "exit_code": done.returncode}
