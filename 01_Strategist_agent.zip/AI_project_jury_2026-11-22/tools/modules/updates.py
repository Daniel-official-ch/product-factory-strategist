"""ingest-update (C-034): новые данные вместо старых. Источник, реестры и журнал пишутся одной транзакцией."""
import json
import re
from pathlib import Path

from . import calculations, decision_graph, evidence_registry, renderer, sources, state_manager
from .common import (UPDATE_BACKUP, UPDATE_JOURNAL, CliError, canonical, check_id, normalize_ws, now_iso, sha256_bytes,
                     sha256_text, split_list, write_bytes)

HINT = 'python3 tools/cli.py ingest-update --file <путь> --id SRC-NEW --title "..." --reason "..." --replaces SRC-OLD'


def _plan(proj, id, title, file, url, from_file, text, force, redact_pii, redact_terms):
    """Загрузка без записи. Подсказки обычной загрузки переводятся на эту же команду, иначе человек потеряет замену."""
    try:
        if file is not None:
            return sources.plan_file(proj, file, id, title, redact_pii, redact_terms)
        if url is not None:
            return sources.plan_url(proj, url, id, title, from_file, force, redact_pii, redact_terms)
        return sources.plan_text(proj, id, text, title, redact_pii, redact_terms)
    except CliError as e:
        e.hint, n = re.subn(r"ingest-source|ingest-url|add-user-input", "ingest-update", e.hint)
        if n:
            e.hint += " (с теми же --title, --reason и --replaces или --claims)"
        raise


def _check_args(proj, id, reason, file, url, from_file, text, replaces, named):
    check_id(id, "SRC")
    if sum(x is not None for x in (file, url, text)) != 1:
        raise CliError("Новые данные задаются ровно одним из --file, --url, --text", HINT)
    if from_file is not None and url is None:
        raise CliError("--from-file работает только вместе с --url", HINT)
    if not reason.strip():
        raise CliError("Нужна причина обновления", HINT)
    if not replaces and not named:
        raise CliError("Не указано, что заменяют новые данные: нужен --replaces или --claims",
                       "Если заменять нечего, это обычная загрузка: python3 tools/cli.py ingest-source --file <путь> --id SRC-XX")
    if id == replaces:
        raise CliError(f"Новый источник {id} совпадает с заменяемым", "Выберите другой --id: python3 tools/cli.py status")
    if replaces:
        old = sources.get(proj, replaces)
        if old is None:
            raise CliError(f"Заменяемый источник {replaces} не найден", "Проверьте ID: python3 tools/cli.py status")
        if old.get("superseded_by") not in (None, id):
            raise CliError(f"Источник {replaces} уже заменён на {old['superseded_by']}",
                           f"Замените актуальный источник: --replaces {old['superseded_by']}")


def _check_claims(claims, named):
    by_id = {c.get("id"): c for c in claims}
    bad = [cid for cid in named if by_id.get(cid, {}).get("status") != "active"]
    if bad:
        raise CliError(f"В --claims нет активного утверждения с таким ID: {', '.join(bad)}",
                       "Активные утверждения: python3 tools/cli.py status")


def _sort_replaced(proj, claims, replaces, new_text, synthetic):
    """C-034 п.3 -> (confirmed, superseded, recalc_needed). Подтверждённое ранее через replaces тоже проверяется заново."""
    confirmed, superseded, recalc = [], [], set()
    for c in claims:
        if c.get("status") != "active":
            continue
        calc = calculations.get(proj, c.get("calc_id")) if c.get("origin_type") == "CALCULATION" and c.get("calc_id") else None
        if calc and calc.get("source_id") == replaces:
            superseded.append(c["id"])
            recalc.add(calc["id"])
        elif c.get("source_id") == replaces or replaces in (c.get("confirmed_by") or []):
            quote = normalize_ws(c.get("verbatim_quote"))  # «дословно» как в register-claim (C-010 п.7)
            ok = quote and quote in new_text and not (synthetic and not c.get("demo_data"))
            (confirmed if ok else superseded).append(c["id"])
    return confirmed, superseded, recalc


def _next_action(id, superseded, recalc, affected):
    steps = []
    if recalc:
        steps.append("пересчитать " + ", ".join(recalc) + " (register-calc с новым ID)")
    if superseded:
        steps.append(f"зарегистрировать новые сведения из {id} вместо " + ", ".join(superseded) + " (register-claim)")
    if affected:
        steps.append("пересмотреть затронутое: " + ", ".join(affected))
    return ("Нужно: " + "; ".join(steps)) if steps else "Старые утверждения подтверждены, пересматривать нечего"


def _broken_journal(why):
    return CliError(f"Журнал прерванной ingest-update {UPDATE_JOURNAL} {why}. Ничего не применено.",
                    'Проверьте файлы проекта и выполните python3 tools/cli.py accept-edit --reason "...": '
                    "он примет состояние как есть и снимет журнал", code=3)


RAW_NAME = re.compile(r"user_inputs\.md|SRC-[A-Za-z0-9_-]+(?:\.orig)?\.(?:txt|html|csv|xlsx|md|pdf|docx)")


def _guard_links(proj):
    """C-039 п.6: служебные журнал и папка копий не могут быть ссылками: запись по ним ушла бы за папку проекта."""
    for name in (UPDATE_JOURNAL, UPDATE_BACKUP):
        if proj.path(name).is_symlink():
            raise CliError(f"{name} в папке проекта — символическая ссылка; служебные файлы ingest-update ссылками быть не могут",
                           f"Удалите ссылку {proj.path(name)} и повторите команду", code=3)


def _read_journal(proj):
    try:
        journal = json.loads(proj.path(UPDATE_JOURNAL).read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeDecodeError):
        journal = None
    ok = (isinstance(journal, dict) and set(journal) == {"key", "base_hash", "files"}
          and isinstance(journal["key"], str) and isinstance(journal["base_hash"], str) and isinstance(journal["files"], dict)
          and all(isinstance(n, str) and RAW_NAME.fullmatch(n) and (h is None or isinstance(h, str))
                  for n, h in journal["files"].items()))
    if not ok:
        raise _broken_journal("повреждён")
    return journal


def _recover(proj, key, dry_run):
    """C-038 п.1, C-039 п.2–5: журнал — только отметка и хеши копий. До commit каждый файл, который пишет команда,
    возвращается к копии (копия сверяется с хешем, реестры — с base_hash), затем команда идёт заново из своих аргументов."""
    if not proj.path(UPDATE_JOURNAL).is_file():
        return
    journal = _read_journal(proj)
    state = proj.load("state.json", code=3)
    if journal["base_hash"] != state.get("validation_hash"):  # commit прошёл: откатывать нечего
        if not dry_run:
            proj.drop_update_journal()
            decision_graph.write(proj)  # обрыв мог прийтись между state.json и графом
        return
    applied = proj.compute_hash(state, code=3) != journal["base_hash"]
    if applied and journal["key"] != key:
        raise CliError("Предыдущая команда ingest-update оборвалась посреди записи, а эта команда другая",
                       "Повторите ту же команду ingest-update с теми же аргументами: она доведёт запись до конца", code=3)
    if dry_run:
        if applied:
            raise CliError("Предыдущая ingest-update оборвалась посреди записи", "Повторите ту же команду без --dry-run", code=3)
        return  # реестры не тронуты: результат считается из них, ничего не пишем
    backup = proj.path(UPDATE_BACKUP)
    for name, digest in journal["files"].items():  # сначала всё проверить, потом писать
        if digest is not None and not ((backup / name).is_file() and sha256_bytes((backup / name).read_bytes()) == digest):
            raise _broken_journal(f"не совпадает с копией {name}")
    saved = None
    if applied:
        try:
            saved = {f: json.loads((backup / f).read_text(encoding="utf-8")) for f in state_manager.HASHED}
        except (OSError, ValueError, UnicodeDecodeError):
            raise _broken_journal("без копии реестров")
        if proj.compute_hash(state, registries=saved) != journal["base_hash"]:
            raise _broken_journal("не совпадает с копией реестров")
    for name, digest in journal["files"].items():
        target = proj.path(f"raw_materials/{name}")
        if digest is not None:
            write_bytes(target, (backup / name).read_bytes())
        elif target.is_file():  # файла не было до команды
            target.unlink()
    for f in state_manager.HASHED if saved else ():
        write_bytes(proj.path(f), (backup / f).read_bytes())
    proj.drop_update_journal()


def _begin(proj, key, writes):
    """Копии реестров и всех файлов, которые запишет команда, затем отметка с их хешами."""
    proj.drop_update_journal()
    backup = proj.path(UPDATE_BACKUP)
    for f in state_manager.HASHED:
        write_bytes(backup / f, proj.path(f).read_bytes())
    files = {}
    for name in dict.fromkeys(["user_inputs.md", *(Path(rel).name for rel, _ in writes)]):
        src = proj.path(f"raw_materials/{name}")
        files[name] = None
        if src.is_file():
            data = src.read_bytes()
            write_bytes(backup / name, data)
            files[name] = sha256_bytes(data)
    proj.save(UPDATE_JOURNAL, {"key": key, "base_hash": proj.load("state.json")["validation_hash"], "files": files})


def ingest_update(proj, id, title, reason, file=None, url=None, from_file=None, text=None, replaces=None, claims=None,
                  dry_run=False, redact_pii=False, force=False, redact_terms=None):
    named = split_list(claims)
    # В журнале только хеш: --text до очистки ПДн и термины C-046 не должны попасть на диск (C-025)
    key = sha256_text(canonical([id, title, reason, file, url, from_file, text, replaces, named]
                                + ([redact_terms] if redact_terms else [])))
    _guard_links(proj)
    _recover(proj, key, dry_run)
    proj.verify()
    _check_args(proj, id, reason, file, url, from_file, text, replaces, named)
    reason = sources.check_field(reason, redact_pii, f'python3 tools/cli.py ingest-update ... --id {id} --reason "..."')  # C-038 п.7
    args = {"replaces": replaces, "claims": named, "reason": reason}
    done = (sources.get(proj, id) or {}).get("update")
    db = proj.load("evidence_db.json")
    if not done:  # до загрузки: неверный --claims не должен стоить сетевого запроса
        _check_claims(db["claims"], named)
    plan = _plan(proj, id, title, file, url, from_file, text, force, redact_pii, redact_terms)
    src = plan["src"]
    snapshot = sources.plan_snapshot(proj, plan)
    names = sources.names_report(id, snapshot, src.get("terms_redacted", 0))  # C-046: в sources.json не пишется
    if done:  # C-034 п.8: повтор ничего не меняет
        if done["args"] != args:
            raise CliError(f"Источник {id} уже загружен с другой заменой", "Выберите другой --id: python3 tools/cli.py status")
        return {**done["result"], "dry_run": dry_run, **names}

    confirmed, superseded, recalc = _sort_replaced(proj, db["claims"], replaces, normalize_ws(snapshot),
                                                   bool(src.get("synthetic"))) if replaces else ([], [], set())
    gone = sorted(set(superseded) | set(named))
    confirmed = sorted(set(confirmed) - set(gone))  # C-034 п.4: --claims важнее подтверждения
    by_id = {c["id"]: c for c in db["claims"]}
    opts, decs = proj.load("options.json"), proj.load("decisions.json")
    now, hit, hit_opts, hit_decs = now_iso(), set(), set(), set()
    for cid in gone:
        cs, os_, ds = evidence_registry.mark_dependents(db, opts, decs, cid)  # C-034 п.5: та же функция, что у revoke-claim
        hit |= cs
        hit_opts |= set(os_)
        hit_decs |= set(ds)
        by_id[cid].update(status="superseded", superseded_by=id, superseded_reason=reason, superseded_at=now,
                          affected=sorted(cs) + os_ + ds)
    for cid in confirmed:
        by_id[cid]["confirmed_by"] = [*(by_id[cid].get("confirmed_by") or []), id]
    affected = sorted(hit - set(gone)) + sorted(hit_opts) + sorted(hit_decs)
    result = {"ok": True, "id": id, "replaces": replaces, "dry_run": dry_run, "confirmed": confirmed, "superseded": gone,
              "recalc_needed": sorted(recalc), "affected": affected,
              "next_action": _next_action(id, gone, sorted(recalc), affected)}
    if dry_run:
        return {**result, **names}

    data = proj.load("sources.json")
    if plan["new"]:
        data["sources"].append(src)
    registry = {s["id"]: s for s in data["sources"]}
    registry[id]["update"] = {"args": args, "result": result}
    if replaces:
        registry[replaces]["superseded_by"] = id
    writes = plan.get("writes", [])
    if not all(rel.startswith("raw_materials/") and RAW_NAME.fullmatch(rel[len("raw_materials/"):]) for rel, _ in writes):
        raise CliError("Внутренняя ошибка: путь записи вне raw_materials/", "Сообщите разработчику, ничего не записано")
    _begin(proj, key, writes)
    for rel, blob in writes:  # пути строит загрузка из проверенного --id, а не журнал
        write_bytes(proj.path(rel), blob)
    for fname, reg in (("evidence_db.json", db), ("options.json", opts), ("decisions.json", decs), ("sources.json", data)):
        proj.save(fname, reg)  # sources.json с отметкой update — последним (C-038 п.1)
    if hit_opts:
        renderer.render_options(proj)
    proj.commit("ingest-update", {"id": id, **args}, id)
    proj.drop_update_journal()
    return {**result, **names}
