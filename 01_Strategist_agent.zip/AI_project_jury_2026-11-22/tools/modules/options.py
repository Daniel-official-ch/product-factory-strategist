"""Варианты решения (C-004, C-009, C-010 п.10, C-011 п.3)."""
from . import renderer
from .common import CliError, check_id, now_iso, split_list

TYPES = ("keep_as_is", "close_direction", "custom")
CONTENT = ("type", "title", "summary", "objections", "claims", "costs", "risks")
H_OPT = ('python3 tools/cli.py register-option --id OPT-01 --type keep_as_is --title "..." --summary "..." '
         '--objections "возражение 1;;возражение 2" --claims CLM-001')


def problems(o, claims_by_id):
    oid = o.get("id") or "вариант"
    out = []
    if o.get("type") not in TYPES:
        out.append(f"{oid}: тип «{o.get('type')}» неизвестен, допустимо: {', '.join(TYPES)}")
    for f in ("title", "summary"):
        if not str(o.get(f) or "").strip():
            out.append(f"{oid}: пустое поле {f}")
    objections = o.get("objections")
    if not isinstance(objections, list) or not [x for x in objections if str(x).strip()]:
        out.append(f"{oid}: нет ни одного сильного возражения (--objections \"в1;;в2\")")
    for cid in o.get("claims") or []:
        c = claims_by_id.get(cid)
        if c is None:
            out.append(f"{oid}: ссылается на несуществующее утверждение {cid}")
        elif c.get("status") != "active" and not o.get("needs_revision"):
            out.append(f"{oid}: ссылается на отозванное утверждение {cid}")
    return out


def _claims(proj):
    return {c.get("id"): c for c in proj.load("evidence_db.json")["claims"]}


def all_violations(proj):
    by_id = _claims(proj)
    out = []
    for o in proj.load("options.json")["options"]:
        out += problems(o, by_id)
    return out


def register_option(proj, id, type, title, summary, objections, claims=None, costs=None, risks=None):
    check_id(id, "OPT")
    new = {"id": id, "type": type, "title": title, "summary": summary,
           "objections": split_list(objections, ";;"), "claims": split_list(claims),
           "costs": costs or "", "risks": risks or ""}
    probs = problems(new, _claims(proj))
    if probs:
        raise CliError(probs[0], H_OPT, violations=probs)
    db = proj.load("options.json")
    old = next((o for o in db["options"] if o.get("id") == id), None)
    if old and all(old.get(k) == new[k] for k in CONTENT):
        return {"id": id, "revision": old.get("revision", 0)}
    if old:
        new.update(revision=old.get("revision", 0) + 1, needs_revision=False,
                   created_at=old.get("created_at"), updated_at=now_iso())
        db["options"][db["options"].index(old)] = new
        op = "option_updated"
    else:
        new.update(revision=0, needs_revision=False, created_at=now_iso())
        db["options"].append(new)
        op = "register-option"
    proj.save("options.json", db)
    renderer.render_options(proj)
    proj.commit(op, {k: new[k] for k in CONTENT}, id)
    return {"id": id, "revision": new["revision"]}


def stage4_problems(proj):
    opts = proj.load("options.json")["options"]
    by_id = _claims(proj)
    out = []
    if len(opts) < 3:
        out.append(f"Вариантов {len(opts)}, нужно не меньше 3")
    types = {o.get("type") for o in opts}
    if "keep_as_is" not in types:
        out.append("Нет варианта «Оставить как есть» (--type keep_as_is)")
    if "close_direction" not in types:
        out.append("Нет варианта «Закрыть направление» (--type close_direction)")
    for o in opts:
        out += problems(o, by_id)
        if not [c for c in o.get("claims") or [] if by_id.get(c, {}).get("status") == "active"]:
            out.append(f"{o.get('id')}: не опирается ни на одно активное утверждение (--claims CLM-XXX)")
        if o.get("needs_revision"):
            out.append(f"{o.get('id')}: требует пересмотра после отзыва утверждения (register-option с тем же ID)")
    return out
