#!/usr/bin/env python3
"""CLI «Стратега Фабрики продуктов». Тонкий адаптер: разбор аргументов -> modules.commands.execute -> JSON.

Успех: exit 0 и одна JSON-строка в stdout. Ошибка: exit 1 (ввод/проверка) или 3 (ручная правка),
JSON {"error", "hint"} в stderr, без трейсбека. Контракты C-000…C-011.
"""
import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from modules.commands import execute  # noqa: E402
from modules.common import CliError  # noqa: E402
from modules.cost_tracker import read_hook_input  # noqa: E402


class Parser(argparse.ArgumentParser):
    def error(self, message):
        cmd = self.prog.split(" ", 1)[1] if " " in self.prog else ""
        raise CliError(f"Неверные аргументы: {message}", f"python3 tools/cli.py {cmd} --help".replace("  ", " "))


R = {"required": True}
STAGE = {"type": int, "required": True}
FLAG = {"action": "store_true"}
SPEC = {
    "init": {"--name": R, "--question": {}},
    "status": {},
    "resume": {},
    "set-brief": {**{f"--{f}": {} for f in ("question", "goal", "recipient", "audience", "constraints")},
                  "--data": R},  # C-011 п.1
    "add-question": {"--text": R, "--why": R},
    "add-gap": {"--text": R, "--why": R, "--question": {}},
    "set-pending": {"--text": R},
    "clear-pending": {},
    "validate-step": {"--stage": STAGE},
    "accept-edit": {"--reason": R},
    "ingest-source": {"--file": R, "--id": R, "--title": {}, "--redact-pii": FLAG, "--redact-terms": {}},
    "ingest-url": {"--url": R, "--id": R, "--title": {}, "--from-file": {}, "--force": FLAG, "--redact-pii": FLAG,
                   "--redact-terms": {}},
    "add-user-input": {"--id": R, "--text": R, "--redact-pii": FLAG, "--redact-terms": {}},
    "redact-source": {"--id": R, "--terms": R, "--reason": R},
    "register-calc": {"--id": R, "--formula": R, "--inputs": R, "--source": R, "--unit": {"default": ""}},
    "register-claim": {"--type": R, "--origin": R, "--text": R, "--source": {}, "--quote": {}, "--calc": {},
                       "--depends-on": {}},
    "revoke-claim": {"--id": R, "--reason": R, "--redact-pii": FLAG},
    "verify-quotes": {},
    "register-option": {"--id": R, "--type": R, "--title": R, "--summary": R, "--objections": R,
                        "--claims": {}, "--costs": {}, "--risks": {}},
    "record-decision": {"--id": R, "--kind": R, "--text": R, "--option": {}, "--claims": {}, "--owner": {},
                        "--metric": {}, "--review-if": {}},
    "log-cost": {"--stage": STAGE, "--tokens-in": {"type": int, "required": True},
                 "--tokens-out": {"type": int, "required": True}, "--cache-read": {"type": int, "default": 0},
                 "--source": R, "--model": {}, "--note": {}},
    "parse-transcript": {"--transcript": {}, "--stage": {"type": int},
                         "--hook": {"action": "store_true", "help": "режим хука Stop: путь из stdin, всегда exit 0"}},
    "verify-run": {},
    "build-rules": {"--check": {"action": "store_true"}},
    "analyze-table": {"--source": R, "--sheet": {}},
    "impact": {"--id": R},
    "ingest-update": {"--file": {}, "--url": {}, "--from-file": {}, "--text": {}, "--id": R, "--title": R, "--reason": R,
                      "--replaces": {}, "--claims": {}, "--dry-run": FLAG, "--redact-pii": FLAG, "--force": FLAG,
                      "--redact-terms": {}},
    "export-pdf": {"--md": {}, "--out": {}},
}
GLOBAL = ("workspace", "project")
ABOUT = {
    "init": "Создать проект.",
    "status": "Показать этап, счётчики и расход. Только чтение.",
    "resume": "Показать точку продолжения и перезаписать HANDOFF_CONTEXT.md.",
    "set-brief": "Заполнить или обновить бриф (этап 1).",
    "add-question": "Записать исследовательский вопрос (этап 3).",
    "add-gap": "Записать пробел в знаниях (этап 3).",
    "set-pending": "Отметить вопрос, который ждёт решения человека.",
    "clear-pending": "Снять ожидание решения человека.",
    "validate-step": "Проверить условия этапа и закрыть его.",
    "accept-edit": "Принять ручную правку файлов проекта.",
    "ingest-source": "Загрузить файл как источник: md, txt, csv, xlsx, pdf, docx.",
    "ingest-url": "Загрузить открытую страницу как источник.",
    "add-user-input": "Записать слова человека как источник.",
    "redact-source": "Скрыть имена людей в уже загруженном источнике.",
    "register-calc": "Записать воспроизводимый расчёт.",
    "register-claim": "Зарегистрировать утверждение: FACT, HYPOTHESIS или FORECAST.",
    "revoke-claim": "Отозвать утверждение и пометить зависимые записи.",
    "verify-quotes": "Перепроверить цитаты всех активных утверждений.",
    "register-option": "Создать или обновить вариант решения и документ 03.",
    "record-decision": "Записать решение человека.",
    "log-cost": "Записать расход токенов.",
    "parse-transcript": "Учесть расход по транскрипту Claude Code.",
    "verify-run": "Сквозная проверка проекта. Только чтение.",
    "build-rules": "Сгенерировать правила для IDE из prompts_src.",
    "analyze-table": "Проверить таблицу-источник: единицы, пропуски, периоды, дубли, выбросы.",
    "impact": "Показать, что зависит от источника, расчёта, утверждения или варианта. Только чтение.",
    "ingest-update": "Загрузить новые данные вместо старых и пометить, что устарело.",
    "export-pdf": "Собрать PDF из документов deliverables/ или из одного Markdown-файла.",
}


def build_parser():
    p = Parser(prog="cli.py", description=__doc__.splitlines()[0])
    p.add_argument("--workspace", help="корень данных (или STRATEGIST_WORKSPACE); по умолчанию <repo>/workspace")
    p.add_argument("--project", help="папка проекта; по умолчанию current_project")
    sub = p.add_subparsers(dest="command", required=True, parser_class=Parser)
    for name, args in SPEC.items():
        sp = sub.add_parser(name, help=ABOUT[name], description=ABOUT[name])
        for flag in GLOBAL:  # глобальные флаги допустимы и после имени команды
            sp.add_argument(f"--{flag}", default=argparse.SUPPRESS)
        for flag, kw in args.items():
            sp.add_argument(flag, **kw)
    return p


def main(argv=None):
    hook = False
    try:
        ns = vars(build_parser().parse_args(argv))
        command = ns.pop("command")
        workspace, project = ns.pop("workspace", None), ns.pop("project", None)
        hook = ns.pop("hook", False)
        if command == "parse-transcript":
            if hook:
                ns["transcript"] = read_hook_input(sys.stdin.read())
            elif not ns.get("transcript"):
                raise CliError("Нужен --transcript <path.jsonl>", "python3 tools/cli.py parse-transcript --transcript <path.jsonl>")
        result = execute(command, ns, workspace=workspace, project=project, hook=hook)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except CliError as e:
        print(json.dumps(e.payload(), ensure_ascii=False), file=sys.stderr)
        code = e.code
    except ModuleNotFoundError as e:  # первый запуск без зависимостей
        print(json.dumps({"error": f"Не установлена библиотека {e.name}", "hint": "pip install -r requirements.txt"},
                         ensure_ascii=False), file=sys.stderr)
        code = 1
    except Exception as e:  # трейсбек пользователю не показываем (C-000)
        if os.environ.get("STRATEGIST_DEBUG"):
            raise
        print(json.dumps({"error": f"Внутренняя ошибка: {type(e).__name__}: {e}",
                          "hint": "Повторите с STRATEGIST_DEBUG=1 и сообщите разработчику"}, ensure_ascii=False),
              file=sys.stderr)
        code = 1
    return 0 if hook else code  # хук Stop не роняет сессию (C-011 п.7)


if __name__ == "__main__":
    sys.exit(main())
