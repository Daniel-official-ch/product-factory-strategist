#!/usr/bin/env python3
"""Чистая копия репозитория для жюри (C-040). Тонкий адаптер: логика в modules/packaging.py.

python3 tools/package.py --out <папка> [--zip]. Успех: exit 0 и JSON {ok, out, files, excluded, zip}.
Ошибка: exit 1 и JSON {error, hint, violations} в stderr; недособранная копия удаляется.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from modules.common import CliError  # noqa: E402
from modules.packaging import HINT, build  # noqa: E402


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise CliError(f"Неверные аргументы: {message}", HINT)


def main(argv=None):
    p = Parser(prog="package.py", description=__doc__.splitlines()[0])
    p.add_argument("--out", required=True, help="пустая папка для копии, вне репозитория")
    p.add_argument("--zip", action="store_true", help="положить рядом <out>.zip")
    try:
        ns = p.parse_args(argv)
        print(json.dumps(build(ns.out, ns.zip), ensure_ascii=False))
        return 0
    except CliError as e:
        print(json.dumps(e.payload(), ensure_ascii=False), file=sys.stderr)
        return e.code


if __name__ == "__main__":
    sys.exit(main())
