#!/usr/bin/env python3
"""MCP-сервер «Стратега» (stdio). Тонкая обёртка: инструменты и вызовы — в modules/mcp_adapter.py (C-028)."""
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from modules import mcp_adapter  # noqa: E402


def main():
    try:
        from fastmcp import FastMCP
        from fastmcp.tools import Tool, ToolResult
    except ImportError:
        print('Для MCP-сервера нужна необязательная библиотека fastmcp 4.1 или новее: pip install "fastmcp>=4.1" '
              "(обычный pip install fastmcp подойдёт, если поставит такую версию)", file=sys.stderr)
        return 1

    class CliTool(Tool):
        async def run(self, arguments):
            result = await asyncio.to_thread(mcp_adapter.call_tool, self.name, arguments)
            return ToolResult(content=json.dumps(result, ensure_ascii=False), structured_content=result)

    server = FastMCP("strategist")
    for spec in mcp_adapter.list_tools():
        server.add_tool(CliTool(**spec))
    server.run(show_banner=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
